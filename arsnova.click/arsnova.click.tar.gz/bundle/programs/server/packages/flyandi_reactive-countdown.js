(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

/* Package-scope variables */
var ReactiveCountdown;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages/flyandi_reactive-countdown/packages/flyandi_reactive-countdown.js                                   //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/flyandi:reactive-countdown/ReactiveCountdown.js                                              //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
/**                                                                                                      // 1
 * flyandi:reactivecountdown                                                                             // 2
 * A simple reactive countdown timer library                                                             // 3
 * @version: v0.0.1                                                                                      // 4
 * @author: Andy Schwarz                                                                                 // 5
 *                                                                                                       // 6
 * Created by Andy Schwarz. Please report any bug at http://github.com/flyandi/meteor-reactive-countdown // 7
 *                                                                                                       // 8
 * Copyright (c) 2015 Andy Schwarz http://github.com/flyandi                                             // 9
 *                                                                                                       // 10
 * The MIT License (http://www.opensource.org/licenses/mit-license.php)                                  // 11
 *                                                                                                       // 12
 * Permission is hereby granted, free of charge, to any person                                           // 13
 * obtaining a copy of this software and associated documentation                                        // 14
 * files (the "Software"), to deal in the Software without                                               // 15
 * restriction, including without limitation the rights to use,                                          // 16
 * copy, modify, merge, publish, distribute, sublicense, and/or sell                                     // 17
 * copies of the Software, and to permit persons to whom the                                             // 18
 * Software is furnished to do so, subject to the following                                              // 19
 * conditions:                                                                                           // 20
 *                                                                                                       // 21
 * The above copyright notice and this permission notice shall be                                        // 22
 * included in all copies or substantial portions of the Software.                                       // 23
 *                                                                                                       // 24
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,                                       // 25
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES                                       // 26
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND                                              // 27
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT                                           // 28
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,                                          // 29
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING                                          // 30
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR                                         // 31
 * OTHER DEALINGS IN THE SOFTWARE.                                                                       // 32
 */                                                                                                      // 33
                                                                                                         // 34
ReactiveCountdown = (function () {                                                                       // 35
                                                                                                         // 36
    // Constructor                                                                                       // 37
    function ReactiveCountdown(countdown, settings) {                                                    // 38
    	this._settings = settings || {};                                                                    // 39
    	this._dependency = new Tracker.Dependency;                                                          // 40
    	this._countdown = countdown;                                                                        // 41
    	this._interval = this._settings.interval || 1000;                                                   // 42
    	this._steps = this._settings.steps || 1;                                                            // 43
    	this._id = false;                                                                                   // 44
    };                                                                                                   // 45
                                                                                                         // 46
    ReactiveCountdown.prototype.start = function(completed, tick){                                       // 47
                                                                                                         // 48
    	if(completed) this._settings.completed = completed;                                                 // 49
    	if(tick) this._settings.tick = tick;                                                                // 50
                                                                                                         // 51
    	this._current = this._countdown;                                                                    // 52
                                                                                                         // 53
    	this._id = Meteor.setInterval(function(){                                                           // 54
                                                                                                         // 55
    		this._current = this._current - this._steps;                                                       // 56
                                                                                                         // 57
    		if(typeof(this._settings.tick) == "function") {                                                    // 58
    			this._settings.tick();                                                                            // 59
    		}                                                                                                  // 60
                                                                                                         // 61
            this._dependency.changed();                                                                  // 62
                                                                                                         // 63
    		if(this._current <= 0) {                                                                           // 64
                                                                                                         // 65
    			this.stop();                                                                                      // 66
                                                                                                         // 67
    			if(typeof(this._settings.completed) == "function") {                                              // 68
    				this._settings.completed();                                                                      // 69
    			}                                                                                                 // 70
    		}                                                                                                  // 71
                                                                                                         // 72
        }.bind(this), this._interval);                                                                   // 73
    };                                                                                                   // 74
                                                                                                         // 75
    ReactiveCountdown.prototype.stop = function(){                                                       // 76
        Meteor.clearInterval(this._id);                                                                  // 77
        this._id = false;                                                                                // 78
    };                                                                                                   // 79
                                                                                                         // 80
    ReactiveCountdown.prototype.add = function(unit) {                                                   // 81
    	this._current = this._current + (unit || 0);                                                        // 82
    };                                                                                                   // 83
                                                                                                         // 84
    ReactiveCountdown.prototype.remove = function(unit) {                                                // 85
    	this._current = this._current - (unit || 0);                                                        // 86
    };                                                                                                   // 87
                                                                                                         // 88
    ReactiveCountdown.prototype.get = function() {                                                       // 89
    	                                                                                                    // 90
    	this._dependency.depend();                                                                          // 91
                                                                                                         // 92
    	return this._current;                                                                               // 93
    };                                                                                                   // 94
                                                                                                         // 95
    return ReactiveCountdown;                                                                            // 96
})();                                                                                                    // 97
                                                                                                         // 98
                                                                                                         // 99
                                                                                                         // 100
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['flyandi:reactive-countdown'] = {}, {
  ReactiveCountdown: ReactiveCountdown
});

})();

//# sourceMappingURL=flyandi_reactive-countdown.js.map

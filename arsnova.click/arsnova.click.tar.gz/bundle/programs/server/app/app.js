var require = meteorInstall({"lib":{"answeroptions":{"answeroption_abstract.js":["babel-runtime/helpers/classCallCheck",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/answeroptions/answeroption_abstract.js                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
exports.AbstractAnswerOption = undefined;                                                                             //
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
var hashtag = Symbol("hashtag");                                                                                      // 1
var questionIndex = Symbol("questionIndex");                                                                          // 2
var answerText = Symbol("answerText");                                                                                // 3
var answerOptionNumber = Symbol("answerOptionNumber");                                                                // 4
var isCorrect = Symbol("isCorrect");                                                                                  // 5
                                                                                                                      //
var AbstractAnswerOption = exports.AbstractAnswerOption = function () {                                               //
                                                                                                                      //
	/**                                                                                                                  //
  * Constructor super method for creating a AnswerOption instance                                                     //
  * This method cannot be invoked directly.                                                                           //
  * @param {{hashtag:String,questionIndex:Number,answerText:String,answerOptionNumber:Number,isCorrect:Boolean,type:Number}} options An object containing the parameters for creating an AnswerOption instance. The type attribute is optional.
  * @throws {TypeError} If this method is invoked directly, the options Object is undefined or the optional type attribute is not matching the constructor name
  * @throws {Error} If the hashtag, the questionIndex, the answerText, the answerOptionNumber or the isCorrect attributes of the options Object are missing
  */                                                                                                                  //
                                                                                                                      //
	function AbstractAnswerOption(options) {                                                                             // 16
		(0, _classCallCheck3["default"])(this, AbstractAnswerOption);                                                       //
                                                                                                                      //
		if (this.constructor === AbstractAnswerOption) {                                                                    // 17
			throw new TypeError("Cannot construct Abstract instances directly");                                               // 18
		}                                                                                                                   //
		if (typeof options.hashtag === "undefined" || typeof options.questionIndex === "undefined" || typeof options.answerText === "undefined" || typeof options.answerOptionNumber === "undefined" || typeof options.isCorrect === "undefined") {
			throw new Error("Invalid argument list for AnswerOption instantiation");                                           // 21
		}                                                                                                                   //
		this[hashtag] = options.hashtag;                                                                                    // 23
		this[questionIndex] = options.questionIndex;                                                                        // 24
		this[answerText] = options.answerText;                                                                              // 25
		this[answerOptionNumber] = options.answerOptionNumber;                                                              // 26
		this[isCorrect] = options.isCorrect;                                                                                // 27
	}                                                                                                                    //
                                                                                                                      //
	/**                                                                                                                  //
  * Returns the hashtag identifying the corresponding session                                                         //
  * @returns {String} The hashtag of the session this AnswerOption instance belongs to                                //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractAnswerOption.prototype.getHashtag = function () {                                                            // 7
		function getHashtag() {                                                                                             //
			return this[hashtag];                                                                                              // 35
		}                                                                                                                   //
                                                                                                                      //
		return getHashtag;                                                                                                  //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Returns the questionIndex this AnswerOption belongs to                                                            //
  * @returns {Number} The question index                                                                              //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractAnswerOption.prototype.getQuestionIndex = function () {                                                      // 7
		function getQuestionIndex() {                                                                                       //
			return this[questionIndex];                                                                                        // 43
		}                                                                                                                   //
                                                                                                                      //
		return getQuestionIndex;                                                                                            //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Sets the questionIndex this AnswerOption belongs to                                                               //
  * @param {Number} index The new index of the question this AnswerOption belongs to                                  //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractAnswerOption.prototype.setQuestionIndex = function () {                                                      // 7
		function setQuestionIndex(index) {                                                                                  //
			this[questionIndex] = index;                                                                                       // 51
		}                                                                                                                   //
                                                                                                                      //
		return setQuestionIndex;                                                                                            //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Returns the currently set answer text displayed during a quiz                                                     //
  * @returns {String} The answer text which will be displayed during a quiz                                           //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractAnswerOption.prototype.getAnswerText = function () {                                                         // 7
		function getAnswerText() {                                                                                          //
			return this[answerText];                                                                                           // 59
		}                                                                                                                   //
                                                                                                                      //
		return getAnswerText;                                                                                               //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Sets the answer text for this AnswerOption instance                                                               //
  * @param {String} text The text which shall be displayed during a quiz                                              //
  * @throws {Error} If the text is not of type String                                                                 //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractAnswerOption.prototype.setAnswerText = function () {                                                         // 7
		function setAnswerText(text) {                                                                                      //
			if (typeof text !== "string") {                                                                                    // 68
				throw new Error("Invalid argument for AnswerOption.setAnswerText");                                               // 69
			}                                                                                                                  //
			this[answerText] = text;                                                                                           // 71
		}                                                                                                                   //
                                                                                                                      //
		return setAnswerText;                                                                                               //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Returns the answerOptionNumber identifying this AnswerOption instance                                             //
  * @returns {Number} The answerOptionNumber of this AnswerOption instance                                            //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractAnswerOption.prototype.getAnswerOptionNumber = function () {                                                 // 7
		function getAnswerOptionNumber() {                                                                                  //
			return this[answerOptionNumber];                                                                                   // 79
		}                                                                                                                   //
                                                                                                                      //
		return getAnswerOptionNumber;                                                                                       //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Returns whether this AnswerOption instance is currently marked as correct                                         //
  * @returns {Boolean} True if this AnswerOption instance is marked as correct, False otherwise                       //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractAnswerOption.prototype.getIsCorrect = function () {                                                          // 7
		function getIsCorrect() {                                                                                           //
			return this[isCorrect];                                                                                            // 87
		}                                                                                                                   //
                                                                                                                      //
		return getIsCorrect;                                                                                                //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Set the correct-mark for this AnswerOption instance                                                               //
  * @param {Boolean} value True, if this AnswerOption shall be marked as correct, False otherwise                     //
  * @throws {Error} If the value is not of type Boolean                                                               //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractAnswerOption.prototype.setIsCorrect = function () {                                                          // 7
		function setIsCorrect(value) {                                                                                      //
			if (typeof value !== "boolean") {                                                                                  // 96
				throw new Error("Invalid argument for AnswerOption.setIsCorrect");                                                // 97
			}                                                                                                                  //
			this[isCorrect] = value;                                                                                           // 99
		}                                                                                                                   //
                                                                                                                      //
		return setIsCorrect;                                                                                                //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Serialize the instance object to a JSON compatible object                                                         //
  * @returns {{hashtag: String, type: String, questionIndex: Number, answerText: String, answerOptionNumber: Number, isCorrect: Boolean}}
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractAnswerOption.prototype.serialize = function () {                                                             // 7
		function serialize() {                                                                                              //
			return {                                                                                                           // 107
				hashtag: this.getHashtag(),                                                                                       // 108
				questionIndex: this.getQuestionIndex(),                                                                           // 109
				answerText: this.getAnswerText(),                                                                                 // 110
				answerOptionNumber: this.getAnswerOptionNumber(),                                                                 // 111
				isCorrect: this.getIsCorrect()                                                                                    // 112
			};                                                                                                                 //
		}                                                                                                                   //
                                                                                                                      //
		return serialize;                                                                                                   //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Checks if the properties of this instance are valid.                                                              //
  * @returns {boolean} True, if the complete Question instance is valid, False otherwise                              //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractAnswerOption.prototype.isValid = function () {                                                               // 7
		function isValid() {                                                                                                //
			return this.getAnswerText().replace(/ /g, "").length > 0;                                                          // 121
		}                                                                                                                   //
                                                                                                                      //
		return isValid;                                                                                                     //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Gets the validation error reason as a stackable array                                                             //
  * @returns {Array} Contains an Object which holds the number of the current answerOption and the reason why the validation has failed
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractAnswerOption.prototype.getValidationStackTrace = function () {                                               // 7
		function getValidationStackTrace() {                                                                                //
			return this.getAnswerText().length === 0 ? [{ occuredAt: { type: "answerOption", id: this.getAnswerOptionNumber() }, reason: "answer_text_empty" }] : [];
		}                                                                                                                   //
                                                                                                                      //
		return getValidationStackTrace;                                                                                     //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Checks for equivalence relations to another AnswerOption instance. Also part of the EJSON interface               //
  * @see http://docs.meteor.com/api/ejson.html#EJSON-CustomType-equals                                                //
  * @param {AbstractAnswerOption} answerOption The AnswerOption instance which should be checked                      //
  * @returns {boolean} True if both instances are completely equal, False otherwise                                   //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractAnswerOption.prototype.equals = function () {                                                                // 7
		function equals(answerOption) {                                                                                     //
			return answerOption instanceof AbstractAnswerOption && answerOption.getQuestionIndex() === this.getQuestionIndex() && answerOption.getAnswerText() === this.getAnswerText() && answerOption.getAnswerOptionNumber() === this.getAnswerOptionNumber() && answerOption.getIsCorrect() === this.getIsCorrect();
		}                                                                                                                   //
                                                                                                                      //
		return equals;                                                                                                      //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Part of EJSON interface                                                                                           //
  * @see AbstractAnswerOption.serialize()                                                                             //
  * @see http://docs.meteor.com/api/ejson.html#EJSON-CustomType-toJSONValue                                           //
  * @returns {{hashtag: String, questionIndex: Number, answerText: String, answerOptionNumber: Number, isCorrect: Boolean}}
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractAnswerOption.prototype.toJSONValue = function () {                                                           // 7
		function toJSONValue() {                                                                                            //
			return {                                                                                                           // 153
				hashtag: this.getHashtag(),                                                                                       // 154
				questionIndex: this.getQuestionIndex(),                                                                           // 155
				answerText: this.getAnswerText(),                                                                                 // 156
				answerOptionNumber: this.getAnswerOptionNumber(),                                                                 // 157
				isCorrect: this.getIsCorrect()                                                                                    // 158
			};                                                                                                                 //
		}                                                                                                                   //
                                                                                                                      //
		return toJSONValue;                                                                                                 //
	}();                                                                                                                 //
                                                                                                                      //
	return AbstractAnswerOption;                                                                                         //
}();                                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"answeroption_default.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/ejson","./answeroption_abstract.js",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/answeroptions/answeroption_default.js                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
exports.DefaultAnswerOption = undefined;                                                                              //
                                                                                                                      //
var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require('babel-runtime/helpers/possibleConstructorReturn');                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require('babel-runtime/helpers/inherits');                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
var _ejson = require('meteor/ejson');                                                                                 // 1
                                                                                                                      //
var _answeroption_abstract = require('./answeroption_abstract.js');                                                   // 2
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                     //
                                                                                                                      //
var DefaultAnswerOption = exports.DefaultAnswerOption = function (_AbstractAnswerOption) {                            //
	(0, _inherits3['default'])(DefaultAnswerOption, _AbstractAnswerOption);                                              //
                                                                                                                      //
                                                                                                                      //
	/**                                                                                                                  //
  * Constructs a DefaultAnswerOption instance                                                                         //
  * @see AbstractAnswerOption.constructor()                                                                           //
  * @param options                                                                                                    //
  */                                                                                                                  //
                                                                                                                      //
	function DefaultAnswerOption(options) {                                                                              // 11
		(0, _classCallCheck3['default'])(this, DefaultAnswerOption);                                                        //
                                                                                                                      //
		if (typeof options.type !== "undefined" && options.type !== "DefaultAnswerOption") {                                // 12
			throw new TypeError("Invalid construction type while creating new DefaultAnswerOption");                           // 13
		}                                                                                                                   //
		return (0, _possibleConstructorReturn3['default'])(this, _AbstractAnswerOption.call(this, options));                //
	}                                                                                                                    //
                                                                                                                      //
	/**                                                                                                                  //
  * Part of EJSON interface                                                                                           //
  * @see http://docs.meteor.com/api/ejson.html#EJSON-clone                                                            //
  * @returns {DefaultAnswerOption} An independent deep copy of the current instance                                   //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	DefaultAnswerOption.prototype.clone = function () {                                                                  // 4
		function clone() {                                                                                                  //
			return new DefaultAnswerOption(this.serialize());                                                                  // 24
		}                                                                                                                   //
                                                                                                                      //
		return clone;                                                                                                       //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Serialize the instance object to a JSON compatible object                                                         //
  * @returns {{hashtag:String,questionText:String,type:AbstractQuestion,timer:Number,startTime:Number,questionIndex:Number,answerOptionList:Array}}
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	DefaultAnswerOption.prototype.serialize = function () {                                                              // 4
		function serialize() {                                                                                              //
			return $.extend(_AbstractAnswerOption.prototype.serialize.call(this), { type: "DefaultAnswerOption" });            // 32
		}                                                                                                                   //
                                                                                                                      //
		return serialize;                                                                                                   //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Part of EJSON interface.                                                                                          //
  * @see http://docs.meteor.com/api/ejson.html#EJSON-CustomType-typeName                                              //
  * @returns {String} The name of the instantiated class                                                              //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	DefaultAnswerOption.prototype.typeName = function () {                                                               // 4
		function typeName() {                                                                                               //
			return "DefaultAnswerOption";                                                                                      // 41
		}                                                                                                                   //
                                                                                                                      //
		return typeName;                                                                                                    //
	}();                                                                                                                 //
                                                                                                                      //
	return DefaultAnswerOption;                                                                                          //
}(_answeroption_abstract.AbstractAnswerOption);                                                                       //
                                                                                                                      //
/**                                                                                                                   //
 * Adds a custom type to Meteor's EJSON                                                                               //
 * @see http://docs.meteor.com/api/ejson.html#EJSON-addType                                                           //
 */                                                                                                                   //
                                                                                                                      //
                                                                                                                      //
_ejson.EJSON.addType("DefaultAnswerOption", function (value) {                                                        // 49
	return new DefaultAnswerOption(value);                                                                               // 50
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"collection.js":["meteor/mongo","meteor/aldeed:simple-schema","../hashtags/collection.js","../eventmanager/collection.js","/lib/local_storage.js",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/answeroptions/collection.js                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
exports.answerOptionsCollectionSchema = exports.isCorrectSchema = exports.answerOptionNumberSchema = exports.answerTextSchema = exports.AnswerOptionCollection = undefined;
                                                                                                                      //
var _mongo = require('meteor/mongo');                                                                                 // 18
                                                                                                                      //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                     // 19
                                                                                                                      //
var _collection = require('../hashtags/collection.js');                                                               // 20
                                                                                                                      //
var _collection2 = require('../eventmanager/collection.js');                                                          // 21
                                                                                                                      //
var _local_storage = require('/lib/local_storage.js');                                                                // 22
                                                                                                                      //
var localData = _interopRequireWildcard(_local_storage);                                                              //
                                                                                                                      //
function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in meteorBabelHelpers.sanitizeForInObject(obj)) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj['default'] = obj; return newObj; } }
                                                                                                                      //
var AnswerOptionCollection = exports.AnswerOptionCollection = new _mongo.Mongo.Collection("answeroptions"); /*        // 24
                                                                                                             * This file is part of ARSnova Click.
                                                                                                             * Copyright (C) 2016 The ARSnova Team
                                                                                                             *        //
                                                                                                             * ARSnova Click is free software: you can redistribute it and/or modify
                                                                                                             * it under the terms of the GNU General Public License as published by
                                                                                                             * the Free Software Foundation, either version 3 of the License, or
                                                                                                             * (at your option) any later version.
                                                                                                             *        //
                                                                                                             * ARSnova Click is distributed in the hope that it will be useful,
                                                                                                             * but WITHOUT ANY WARRANTY; without even the implied warranty of
                                                                                                             * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
                                                                                                             * GNU General Public License for more details.
                                                                                                             *        //
                                                                                                             * You should have received a copy of the GNU General Public License
                                                                                                             * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/
                                                                                                                      //
var answerTextSchema = exports.answerTextSchema = {                                                                   // 25
	type: String,                                                                                                        // 26
	min: 0,                                                                                                              // 27
	max: 500,                                                                                                            // 28
	optional: true                                                                                                       // 29
};                                                                                                                    //
var answerOptionNumberSchema = exports.answerOptionNumberSchema = {                                                   // 31
	type: Number,                                                                                                        // 32
	min: 0                                                                                                               // 33
};                                                                                                                    //
var isCorrectSchema = exports.isCorrectSchema = {                                                                     // 35
	type: Boolean                                                                                                        // 36
};                                                                                                                    //
var answerOptionsCollectionSchema = exports.answerOptionsCollectionSchema = new _aldeedSimpleSchema.SimpleSchema({    // 38
	hashtag: {                                                                                                           // 39
		type: _collection.hashtagSchema                                                                                     // 40
	},                                                                                                                   //
	questionIndex: {                                                                                                     // 42
		type: _collection2.questionIndexSchema                                                                              // 43
	},                                                                                                                   //
	answerText: {                                                                                                        // 45
		type: answerTextSchema,                                                                                             // 46
		optional: true                                                                                                      // 47
	},                                                                                                                   //
	answerOptionNumber: {                                                                                                // 49
		type: answerOptionNumberSchema                                                                                      // 50
	},                                                                                                                   //
	isCorrect: {                                                                                                         // 52
		type: isCorrectSchema                                                                                               // 53
	}                                                                                                                    //
});                                                                                                                   //
                                                                                                                      //
AnswerOptionCollection.attachSchema(answerOptionsCollectionSchema);                                                   // 57
                                                                                                                      //
AnswerOptionCollection.deny({                                                                                         // 59
	insert: function () {                                                                                                // 60
		function insert() {                                                                                                 // 60
			return true;                                                                                                       // 61
		}                                                                                                                   //
                                                                                                                      //
		return insert;                                                                                                      //
	}(),                                                                                                                 //
	update: function () {                                                                                                // 63
		function update() {                                                                                                 // 63
			return true;                                                                                                       // 64
		}                                                                                                                   //
                                                                                                                      //
		return update;                                                                                                      //
	}(),                                                                                                                 //
	remove: function () {                                                                                                // 66
		function remove() {                                                                                                 // 66
			return true;                                                                                                       // 67
		}                                                                                                                   //
                                                                                                                      //
		return remove;                                                                                                      //
	}()                                                                                                                  //
});                                                                                                                   //
                                                                                                                      //
AnswerOptionCollection.allow({                                                                                        // 71
	insert: function () {                                                                                                // 72
		function insert(userId, doc) {                                                                                      // 72
			return localData.containsHashtag(doc.hashtag);                                                                     // 73
		}                                                                                                                   //
                                                                                                                      //
		return insert;                                                                                                      //
	}(),                                                                                                                 //
	update: function () {                                                                                                // 75
		function update(userId, doc) {                                                                                      // 75
			return localData.containsHashtag(doc.hashtag);                                                                     // 76
		}                                                                                                                   //
                                                                                                                      //
		return update;                                                                                                      //
	}(),                                                                                                                 //
	remove: function () {                                                                                                // 78
		function remove(userId, doc) {                                                                                      // 78
			return localData.containsHashtag(doc.hashtag);                                                                     // 79
		}                                                                                                                   //
                                                                                                                      //
		return remove;                                                                                                      //
	}()                                                                                                                  //
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"banned_nicks":{"collection.js":["meteor/mongo","meteor/aldeed:simple-schema","../member_list/collection.js","/lib/local_storage.js",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/banned_nicks/collection.js                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
exports.bannedNicksCollectionSchema = exports.BannedNicksCollection = undefined;                                      //
                                                                                                                      //
var _mongo = require('meteor/mongo');                                                                                 // 18
                                                                                                                      //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                     // 19
                                                                                                                      //
var _collection = require('../member_list/collection.js');                                                            // 20
                                                                                                                      //
var _local_storage = require('/lib/local_storage.js');                                                                // 21
                                                                                                                      //
var localData = _interopRequireWildcard(_local_storage);                                                              //
                                                                                                                      //
function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in meteorBabelHelpers.sanitizeForInObject(obj)) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj['default'] = obj; return newObj; } }
                                                                                                                      //
/*                                                                                                                    //
 * This file is part of ARSnova Click.                                                                                //
 * Copyright (C) 2016 The ARSnova Team                                                                                //
 *                                                                                                                    //
 * ARSnova Click is free software: you can redistribute it and/or modify                                              //
 * it under the terms of the GNU General Public License as published by                                               //
 * the Free Software Foundation, either version 3 of the License, or                                                  //
 * (at your option) any later version.                                                                                //
 *                                                                                                                    //
 * ARSnova Click is distributed in the hope that it will be useful,                                                   //
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                     //
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                      //
 * GNU General Public License for more details.                                                                       //
 *                                                                                                                    //
 * You should have received a copy of the GNU General Public License                                                  //
 * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                           //
                                                                                                                      //
var BannedNicksCollection = exports.BannedNicksCollection = new _mongo.Mongo.Collection("bannedNicks");               // 23
var bannedNicksCollectionSchema = exports.bannedNicksCollectionSchema = new _aldeedSimpleSchema.SimpleSchema({        // 24
	userNick: {                                                                                                          // 25
		type: _collection.userNickSchema                                                                                    // 26
	}                                                                                                                    //
});                                                                                                                   //
                                                                                                                      //
BannedNicksCollection.attachSchema(bannedNicksCollectionSchema);                                                      // 30
                                                                                                                      //
BannedNicksCollection.deny({                                                                                          // 32
	insert: function () {                                                                                                // 33
		function insert() {                                                                                                 // 33
			return true;                                                                                                       // 34
		}                                                                                                                   //
                                                                                                                      //
		return insert;                                                                                                      //
	}(),                                                                                                                 //
	update: function () {                                                                                                // 36
		function update() {                                                                                                 // 36
			return true;                                                                                                       // 37
		}                                                                                                                   //
                                                                                                                      //
		return update;                                                                                                      //
	}(),                                                                                                                 //
	remove: function () {                                                                                                // 39
		function remove() {                                                                                                 // 39
			return true;                                                                                                       // 40
		}                                                                                                                   //
                                                                                                                      //
		return remove;                                                                                                      //
	}()                                                                                                                  //
});                                                                                                                   //
                                                                                                                      //
BannedNicksCollection.allow({                                                                                         // 44
	insert: function () {                                                                                                // 45
		function insert(userId, doc) {                                                                                      // 45
			return localData.containsHashtag(doc.hashtag);                                                                     // 46
		}                                                                                                                   //
                                                                                                                      //
		return insert;                                                                                                      //
	}(),                                                                                                                 //
	update: function () {                                                                                                // 48
		function update(userId, doc) {                                                                                      // 48
			return localData.containsHashtag(doc.hashtag);                                                                     // 49
		}                                                                                                                   //
                                                                                                                      //
		return update;                                                                                                      //
	}(),                                                                                                                 //
	remove: function () {                                                                                                // 51
		function remove(userId, doc) {                                                                                      // 51
			return localData.containsHashtag(doc.hashtag);                                                                     // 52
		}                                                                                                                   //
                                                                                                                      //
		return remove;                                                                                                      //
	}()                                                                                                                  //
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"eventmanager":{"collection.js":["meteor/mongo","meteor/aldeed:simple-schema","../hashtags/collection.js","/lib/local_storage.js",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/eventmanager/collection.js                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
exports.eventManagerCollectionSchema = exports.questionIndexSchema = exports.readingConfirmationIndexSchema = exports.lastConnectionSchema = exports.sessionStatusSchema = exports.EventManagerCollection = undefined;
                                                                                                                      //
var _mongo = require('meteor/mongo');                                                                                 // 18
                                                                                                                      //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                     // 19
                                                                                                                      //
var _collection = require('../hashtags/collection.js');                                                               // 20
                                                                                                                      //
var _local_storage = require('/lib/local_storage.js');                                                                // 21
                                                                                                                      //
var localData = _interopRequireWildcard(_local_storage);                                                              //
                                                                                                                      //
function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in meteorBabelHelpers.sanitizeForInObject(obj)) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj['default'] = obj; return newObj; } }
                                                                                                                      //
/*                                                                                                                    //
 * This file is part of ARSnova Click.                                                                                //
 * Copyright (C) 2016 The ARSnova Team                                                                                //
 *                                                                                                                    //
 * ARSnova Click is free software: you can redistribute it and/or modify                                              //
 * it under the terms of the GNU General Public License as published by                                               //
 * the Free Software Foundation, either version 3 of the License, or                                                  //
 * (at your option) any later version.                                                                                //
 *                                                                                                                    //
 * ARSnova Click is distributed in the hope that it will be useful,                                                   //
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                     //
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                      //
 * GNU General Public License for more details.                                                                       //
 *                                                                                                                    //
 * You should have received a copy of the GNU General Public License                                                  //
 * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                           //
                                                                                                                      //
var EventManagerCollection = exports.EventManagerCollection = new _mongo.Mongo.Collection("eventmanager");            // 23
var sessionStatusSchema = exports.sessionStatusSchema = {                                                             // 24
	type: Number,                                                                                                        // 25
	min: 0,                                                                                                              // 26
	max: 3                                                                                                               // 27
};                                                                                                                    //
var lastConnectionSchema = exports.lastConnectionSchema = {                                                           // 29
	type: Number                                                                                                         // 30
};                                                                                                                    //
var readingConfirmationIndexSchema = exports.readingConfirmationIndexSchema = {                                       // 32
	type: Number,                                                                                                        // 33
	min: -1,                                                                                                             // 34
	optional: true                                                                                                       // 35
};                                                                                                                    //
var questionIndexSchema = exports.questionIndexSchema = {                                                             // 37
	type: Number,                                                                                                        // 38
	min: -1,                                                                                                             // 39
	optional: true                                                                                                       // 40
};                                                                                                                    //
var eventManagerCollectionSchema = exports.eventManagerCollectionSchema = new _aldeedSimpleSchema.SimpleSchema({      // 42
	hashtag: {                                                                                                           // 43
		type: _collection.hashtagSchema                                                                                     // 44
	},                                                                                                                   //
	sessionStatus: {                                                                                                     // 46
		type: sessionStatusSchema                                                                                           // 47
	},                                                                                                                   //
	lastConnection: {                                                                                                    // 49
		type: lastConnectionSchema                                                                                          // 50
	},                                                                                                                   //
	readingConfirmationIndex: {                                                                                          // 52
		type: readingConfirmationIndexSchema                                                                                // 53
	},                                                                                                                   //
	questionIndex: {                                                                                                     // 55
		type: questionIndexSchema                                                                                           // 56
	},                                                                                                                   //
	eventStack: {                                                                                                        // 58
		type: [Object]                                                                                                      // 59
	},                                                                                                                   //
	"eventStack.$.key": {                                                                                                // 61
		type: String                                                                                                        // 62
	},                                                                                                                   //
	"eventStack.$.value": {                                                                                              // 64
		type: Object,                                                                                                       // 65
		blackbox: true /* @see https://github.com/aldeed/meteor-simple-schema#blackbox */                                   // 66
	}                                                                                                                    // 64
});                                                                                                                   //
                                                                                                                      //
EventManagerCollection.attachSchema(eventManagerCollectionSchema);                                                    // 70
                                                                                                                      //
EventManagerCollection.deny({                                                                                         // 72
	insert: function () {                                                                                                // 73
		function insert() {                                                                                                 // 73
			return true;                                                                                                       // 74
		}                                                                                                                   //
                                                                                                                      //
		return insert;                                                                                                      //
	}(),                                                                                                                 //
	update: function () {                                                                                                // 76
		function update() {                                                                                                 // 76
			return true;                                                                                                       // 77
		}                                                                                                                   //
                                                                                                                      //
		return update;                                                                                                      //
	}(),                                                                                                                 //
	remove: function () {                                                                                                // 79
		function remove() {                                                                                                 // 79
			return true;                                                                                                       // 80
		}                                                                                                                   //
                                                                                                                      //
		return remove;                                                                                                      //
	}()                                                                                                                  //
});                                                                                                                   //
                                                                                                                      //
EventManagerCollection.allow({                                                                                        // 84
	insert: function () {                                                                                                // 85
		function insert(userId, doc) {                                                                                      // 85
			return localData.containsHashtag(doc.hashtag);                                                                     // 86
		}                                                                                                                   //
                                                                                                                      //
		return insert;                                                                                                      //
	}(),                                                                                                                 //
	update: function () {                                                                                                // 88
		function update(userId, doc) {                                                                                      // 88
			return localData.containsHashtag(doc.hashtag);                                                                     // 89
		}                                                                                                                   //
                                                                                                                      //
		return update;                                                                                                      //
	}(),                                                                                                                 //
	remove: function () {                                                                                                // 91
		function remove(userId, doc) {                                                                                      // 91
			return localData.containsHashtag(doc.hashtag);                                                                     // 92
		}                                                                                                                   //
                                                                                                                      //
		return remove;                                                                                                      //
	}()                                                                                                                  //
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"hashtags":{"collection.js":["meteor/mongo","meteor/aldeed:simple-schema","/lib/local_storage.js",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/hashtags/collection.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
exports.hashtagsCollectionSchema = exports.musicTitleSchema = exports.musicEnabledSchema = exports.musicVolumeSchema = exports.privateKeySchema = exports.themeSchema = exports.hashtagSchema = exports.HashtagsCollection = undefined;
                                                                                                                      //
var _mongo = require('meteor/mongo');                                                                                 // 18
                                                                                                                      //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                     // 19
                                                                                                                      //
var _local_storage = require('/lib/local_storage.js');                                                                // 20
                                                                                                                      //
var localData = _interopRequireWildcard(_local_storage);                                                              //
                                                                                                                      //
function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in meteorBabelHelpers.sanitizeForInObject(obj)) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj['default'] = obj; return newObj; } }
                                                                                                                      //
var HashtagsCollection = exports.HashtagsCollection = new _mongo.Mongo.Collection("hashtags"); /*                     // 22
                                                                                                * This file is part of ARSnova Click.
                                                                                                * Copyright (C) 2016 The ARSnova Team
                                                                                                *                     //
                                                                                                * ARSnova Click is free software: you can redistribute it and/or modify
                                                                                                * it under the terms of the GNU General Public License as published by
                                                                                                * the Free Software Foundation, either version 3 of the License, or
                                                                                                * (at your option) any later version.
                                                                                                *                     //
                                                                                                * ARSnova Click is distributed in the hope that it will be useful,
                                                                                                * but WITHOUT ANY WARRANTY; without even the implied warranty of
                                                                                                * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
                                                                                                * GNU General Public License for more details.
                                                                                                *                     //
                                                                                                * You should have received a copy of the GNU General Public License
                                                                                                * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/
                                                                                                                      //
var hashtagSchema = exports.hashtagSchema = {                                                                         // 23
	type: String,                                                                                                        // 24
	min: 1,                                                                                                              // 25
	max: 25                                                                                                              // 26
};                                                                                                                    //
var themeSchema = exports.themeSchema = {                                                                             // 28
	type: String                                                                                                         // 29
};                                                                                                                    //
var privateKeySchema = exports.privateKeySchema = {                                                                   // 31
	type: String,                                                                                                        // 32
	min: 24,                                                                                                             // 33
	max: 24                                                                                                              // 34
};                                                                                                                    //
var musicVolumeSchema = exports.musicVolumeSchema = {                                                                 // 36
	type: Number,                                                                                                        // 37
	min: 0,                                                                                                              // 38
	max: 100                                                                                                             // 39
};                                                                                                                    //
var musicEnabledSchema = exports.musicEnabledSchema = {                                                               // 41
	type: Number,                                                                                                        // 42
	min: 0,                                                                                                              // 43
	max: 1                                                                                                               // 44
};                                                                                                                    //
var musicTitleSchema = exports.musicTitleSchema = {                                                                   // 46
	type: String                                                                                                         // 47
};                                                                                                                    //
var hashtagsCollectionSchema = exports.hashtagsCollectionSchema = new _aldeedSimpleSchema.SimpleSchema({              // 49
	hashtag: {                                                                                                           // 50
		type: hashtagSchema                                                                                                 // 51
	},                                                                                                                   //
	theme: {                                                                                                             // 53
		type: themeSchema                                                                                                   // 54
	},                                                                                                                   //
	privateKey: {                                                                                                        // 56
		type: privateKeySchema                                                                                              // 57
	},                                                                                                                   //
	musicVolume: {                                                                                                       // 59
		type: musicVolumeSchema                                                                                             // 60
	},                                                                                                                   //
	musicEnabled: {                                                                                                      // 62
		type: musicEnabledSchema                                                                                            // 63
	},                                                                                                                   //
	musicTitle: {                                                                                                        // 65
		type: musicTitleSchema                                                                                              // 66
	}                                                                                                                    //
});                                                                                                                   //
                                                                                                                      //
HashtagsCollection.attachSchema(hashtagsCollectionSchema);                                                            // 70
                                                                                                                      //
HashtagsCollection.deny({                                                                                             // 72
	insert: function () {                                                                                                // 73
		function insert() {                                                                                                 // 73
			return true;                                                                                                       // 74
		}                                                                                                                   //
                                                                                                                      //
		return insert;                                                                                                      //
	}(),                                                                                                                 //
	update: function () {                                                                                                // 76
		function update() {                                                                                                 // 76
			return true;                                                                                                       // 77
		}                                                                                                                   //
                                                                                                                      //
		return update;                                                                                                      //
	}(),                                                                                                                 //
	remove: function () {                                                                                                // 79
		function remove() {                                                                                                 // 79
			return true;                                                                                                       // 80
		}                                                                                                                   //
                                                                                                                      //
		return remove;                                                                                                      //
	}()                                                                                                                  //
});                                                                                                                   //
                                                                                                                      //
HashtagsCollection.allow({                                                                                            // 84
	insert: function () {                                                                                                // 85
		function insert(userId, doc) {                                                                                      // 85
			return doc.privateKey === localData.getPrivateKey();                                                               // 86
		}                                                                                                                   //
                                                                                                                      //
		return insert;                                                                                                      //
	}(),                                                                                                                 //
	remove: function () {                                                                                                // 88
		function remove(userId, doc) {                                                                                      // 88
			return doc.privateKey === localData.getPrivateKey();                                                               // 89
		}                                                                                                                   //
                                                                                                                      //
		return remove;                                                                                                      //
	}()                                                                                                                  //
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"leader_board":{"collection.js":["meteor/mongo","meteor/aldeed:simple-schema","../hashtags/collection.js","../eventmanager/collection.js","../member_list/collection.js","../responses/collection.js","/lib/local_storage.js",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/leader_board/collection.js                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
exports.leaderBoardCollectionSchema = exports.wrongAnswersSchema = exports.rightAnswersSchema = exports.givenAnswersSchema = exports.LeaderBoardCollection = undefined;
                                                                                                                      //
var _mongo = require('meteor/mongo');                                                                                 // 18
                                                                                                                      //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                     // 19
                                                                                                                      //
var _collection = require('../hashtags/collection.js');                                                               // 20
                                                                                                                      //
var _collection2 = require('../eventmanager/collection.js');                                                          // 21
                                                                                                                      //
var _collection3 = require('../member_list/collection.js');                                                           // 22
                                                                                                                      //
var _collection4 = require('../responses/collection.js');                                                             // 23
                                                                                                                      //
var _local_storage = require('/lib/local_storage.js');                                                                // 24
                                                                                                                      //
var localData = _interopRequireWildcard(_local_storage);                                                              //
                                                                                                                      //
function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in meteorBabelHelpers.sanitizeForInObject(obj)) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj['default'] = obj; return newObj; } }
                                                                                                                      //
var LeaderBoardCollection = exports.LeaderBoardCollection = new _mongo.Mongo.Collection("leaderBoard"); /*            // 26
                                                                                                         * This file is part of ARSnova Click.
                                                                                                         * Copyright (C) 2016 The ARSnova Team
                                                                                                         *            //
                                                                                                         * ARSnova Click is free software: you can redistribute it and/or modify
                                                                                                         * it under the terms of the GNU General Public License as published by
                                                                                                         * the Free Software Foundation, either version 3 of the License, or
                                                                                                         * (at your option) any later version.
                                                                                                         *            //
                                                                                                         * ARSnova Click is distributed in the hope that it will be useful,
                                                                                                         * but WITHOUT ANY WARRANTY; without even the implied warranty of
                                                                                                         * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
                                                                                                         * GNU General Public License for more details.
                                                                                                         *            //
                                                                                                         * You should have received a copy of the GNU General Public License
                                                                                                         * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/
                                                                                                                      //
var givenAnswersSchema = exports.givenAnswersSchema = {                                                               // 27
	type: Number,                                                                                                        // 28
	min: 1,                                                                                                              // 29
	max: 26                                                                                                              // 30
};                                                                                                                    //
var rightAnswersSchema = exports.rightAnswersSchema = {                                                               // 32
	type: Number,                                                                                                        // 33
	min: 0,                                                                                                              // 34
	max: 26                                                                                                              // 35
};                                                                                                                    //
var wrongAnswersSchema = exports.wrongAnswersSchema = {                                                               // 37
	type: Number,                                                                                                        // 38
	min: 0,                                                                                                              // 39
	max: 26                                                                                                              // 40
};                                                                                                                    //
var leaderBoardCollectionSchema = exports.leaderBoardCollectionSchema = new _aldeedSimpleSchema.SimpleSchema({        // 42
	hashtag: {                                                                                                           // 43
		type: _collection.hashtagSchema                                                                                     // 44
	},                                                                                                                   //
	questionIndex: {                                                                                                     // 46
		type: _collection2.questionIndexSchema                                                                              // 47
	},                                                                                                                   //
	userNick: {                                                                                                          // 49
		type: _collection3.userNickSchema                                                                                   // 50
	},                                                                                                                   //
	responseTime: {                                                                                                      // 52
		type: _collection4.responseTimeSchema                                                                               // 53
	},                                                                                                                   //
	givenAnswers: {                                                                                                      // 55
		type: givenAnswersSchema                                                                                            // 56
	},                                                                                                                   //
	rightAnswers: {                                                                                                      // 58
		type: rightAnswersSchema                                                                                            // 59
	},                                                                                                                   //
	wrongAnswers: {                                                                                                      // 61
		type: wrongAnswersSchema                                                                                            // 62
	}                                                                                                                    //
});                                                                                                                   //
                                                                                                                      //
LeaderBoardCollection.attachSchema(leaderBoardCollectionSchema);                                                      // 66
                                                                                                                      //
LeaderBoardCollection.deny({                                                                                          // 68
	insert: function () {                                                                                                // 69
		function insert() {                                                                                                 // 69
			return true;                                                                                                       // 70
		}                                                                                                                   //
                                                                                                                      //
		return insert;                                                                                                      //
	}(),                                                                                                                 //
	update: function () {                                                                                                // 72
		function update() {                                                                                                 // 72
			return true;                                                                                                       // 73
		}                                                                                                                   //
                                                                                                                      //
		return update;                                                                                                      //
	}(),                                                                                                                 //
	remove: function () {                                                                                                // 75
		function remove() {                                                                                                 // 75
			return true;                                                                                                       // 76
		}                                                                                                                   //
                                                                                                                      //
		return remove;                                                                                                      //
	}()                                                                                                                  //
});                                                                                                                   //
                                                                                                                      //
LeaderBoardCollection.allow({                                                                                         // 80
	insert: function () {                                                                                                // 81
		function insert(userId, doc) {                                                                                      // 81
			var isOwner = localData.containsHashtag(doc.hashtag);                                                              // 82
			var isOwnNick = doc.userNick === localStorage.getItem(doc.hashtag + "nick");                                       // 83
			return isOwner || isOwnNick;                                                                                       // 84
		}                                                                                                                   //
                                                                                                                      //
		return insert;                                                                                                      //
	}(),                                                                                                                 //
	update: function () {                                                                                                // 86
		function update(userId, doc) {                                                                                      // 86
			return localData.containsHashtag(doc.hashtag);                                                                     // 87
		}                                                                                                                   //
                                                                                                                      //
		return update;                                                                                                      //
	}(),                                                                                                                 //
	remove: function () {                                                                                                // 89
		function remove(userId, doc) {                                                                                      // 89
			return localData.containsHashtag(doc.hashtag);                                                                     // 90
		}                                                                                                                   //
                                                                                                                      //
		return remove;                                                                                                      //
	}()                                                                                                                  //
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"member_list":{"collection.js":["meteor/mongo","meteor/aldeed:simple-schema","../hashtags/collection.js","/lib/local_storage.js",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/member_list/collection.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
exports.memberListCollectionSchema = exports.insertDateSchema = exports.foregroundColorSchema = exports.backgroundColorSchema = exports.readConfirmedSchema = exports.userNickIdSchema = exports.lowerCaseNickSchema = exports.userNickSchema = exports.MemberListCollection = undefined;
                                                                                                                      //
var _mongo = require('meteor/mongo');                                                                                 // 18
                                                                                                                      //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                     // 19
                                                                                                                      //
var _collection = require('../hashtags/collection.js');                                                               // 20
                                                                                                                      //
var _local_storage = require('/lib/local_storage.js');                                                                // 21
                                                                                                                      //
var localData = _interopRequireWildcard(_local_storage);                                                              //
                                                                                                                      //
function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in meteorBabelHelpers.sanitizeForInObject(obj)) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj['default'] = obj; return newObj; } }
                                                                                                                      //
/*                                                                                                                    //
 * This file is part of ARSnova Click.                                                                                //
 * Copyright (C) 2016 The ARSnova Team                                                                                //
 *                                                                                                                    //
 * ARSnova Click is free software: you can redistribute it and/or modify                                              //
 * it under the terms of the GNU General Public License as published by                                               //
 * the Free Software Foundation, either version 3 of the License, or                                                  //
 * (at your option) any later version.                                                                                //
 *                                                                                                                    //
 * ARSnova Click is distributed in the hope that it will be useful,                                                   //
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                     //
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                      //
 * GNU General Public License for more details.                                                                       //
 *                                                                                                                    //
 * You should have received a copy of the GNU General Public License                                                  //
 * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                           //
                                                                                                                      //
var MemberListCollection = exports.MemberListCollection = new _mongo.Mongo.Collection("memberlist");                  // 23
var userNickSchema = exports.userNickSchema = {                                                                       // 24
	type: String,                                                                                                        // 25
	min: 3,                                                                                                              // 26
	max: 25                                                                                                              // 27
};                                                                                                                    //
var lowerCaseNickSchema = exports.lowerCaseNickSchema = {                                                             // 29
	type: String,                                                                                                        // 30
	min: 3,                                                                                                              // 31
	max: 25                                                                                                              // 32
};                                                                                                                    //
var userNickIdSchema = exports.userNickIdSchema = {                                                                   // 34
	type: String                                                                                                         // 35
};                                                                                                                    //
var readConfirmedSchema = exports.readConfirmedSchema = {                                                             // 37
	type: [Number]                                                                                                       // 38
};                                                                                                                    //
var backgroundColorSchema = exports.backgroundColorSchema = {                                                         // 40
	type: String,                                                                                                        // 41
	min: 7,                                                                                                              // 42
	max: 7                                                                                                               // 43
};                                                                                                                    //
var foregroundColorSchema = exports.foregroundColorSchema = {                                                         // 45
	type: String,                                                                                                        // 46
	min: 7,                                                                                                              // 47
	max: 7                                                                                                               // 48
};                                                                                                                    //
var insertDateSchema = exports.insertDateSchema = {                                                                   // 50
	type: String                                                                                                         // 51
};                                                                                                                    //
var memberListCollectionSchema = exports.memberListCollectionSchema = new _aldeedSimpleSchema.SimpleSchema({          // 53
	hashtag: _collection.hashtagSchema,                                                                                  // 54
	nick: userNickSchema,                                                                                                // 55
	privateKey: _collection.privateKeySchema,                                                                            // 56
	lowerCaseNick: lowerCaseNickSchema,                                                                                  // 57
	readConfirmed: readConfirmedSchema,                                                                                  // 58
	backgroundColor: backgroundColorSchema,                                                                              // 59
	foregroundColor: foregroundColorSchema,                                                                              // 60
	insertDate: insertDateSchema                                                                                         // 61
});                                                                                                                   //
                                                                                                                      //
MemberListCollection.attachSchema(memberListCollectionSchema);                                                        // 64
                                                                                                                      //
MemberListCollection.deny({                                                                                           // 66
	insert: function () {                                                                                                // 67
		function insert() {                                                                                                 // 67
			return true;                                                                                                       // 68
		}                                                                                                                   //
                                                                                                                      //
		return insert;                                                                                                      //
	}(),                                                                                                                 //
	update: function () {                                                                                                // 70
		function update() {                                                                                                 // 70
			return true;                                                                                                       // 71
		}                                                                                                                   //
                                                                                                                      //
		return update;                                                                                                      //
	}(),                                                                                                                 //
	remove: function () {                                                                                                // 73
		function remove() {                                                                                                 // 73
			return true;                                                                                                       // 74
		}                                                                                                                   //
                                                                                                                      //
		return remove;                                                                                                      //
	}()                                                                                                                  //
});                                                                                                                   //
                                                                                                                      //
MemberListCollection.allow({                                                                                          // 78
	insert: function () {                                                                                                // 79
		function insert(userId, doc) {                                                                                      // 79
			var isOwner = localData.containsHashtag(doc.hashtag);                                                              // 80
			var isOwnNick = doc.nick === localStorage.getItem(doc.hashtag + "nick");                                           // 81
			return isOwner || isOwnNick;                                                                                       // 82
		}                                                                                                                   //
                                                                                                                      //
		return insert;                                                                                                      //
	}(),                                                                                                                 //
	update: function () {                                                                                                // 84
		function update(userId, doc) {                                                                                      // 84
			var isOwner = localData.containsHashtag(doc.hashtag);                                                              // 85
			var isOwnNick = doc.nick === localStorage.getItem(doc.hashtag + "nick");                                           // 86
			return isOwner || isOwnNick;                                                                                       // 87
		}                                                                                                                   //
                                                                                                                      //
		return update;                                                                                                      //
	}(),                                                                                                                 //
	remove: function () {                                                                                                // 89
		function remove(userId, doc) {                                                                                      // 89
			var isOwner = localData.containsHashtag(doc.hashtag);                                                              // 90
			var isOwnNick = doc.nick === localStorage.getItem(doc.hashtag + "nick");                                           // 91
			return isOwner || isOwnNick;                                                                                       // 92
		}                                                                                                                   //
                                                                                                                      //
		return remove;                                                                                                      //
	}()                                                                                                                  //
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"questions":{"collection.js":["meteor/mongo","meteor/aldeed:simple-schema","../hashtags/collection.js","/lib/local_storage.js",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/questions/collection.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
exports.questionGroupSchema = exports.startTimeSchema = exports.timerSchema = exports.questionTextSchema = exports.QuestionGroupCollection = undefined;
                                                                                                                      //
var _mongo = require('meteor/mongo');                                                                                 // 18
                                                                                                                      //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                     // 19
                                                                                                                      //
var _collection = require('../hashtags/collection.js');                                                               // 20
                                                                                                                      //
var _local_storage = require('/lib/local_storage.js');                                                                // 21
                                                                                                                      //
var localData = _interopRequireWildcard(_local_storage);                                                              //
                                                                                                                      //
function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in meteorBabelHelpers.sanitizeForInObject(obj)) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj['default'] = obj; return newObj; } }
                                                                                                                      //
/*                                                                                                                    //
 * This file is part of ARSnova Click.                                                                                //
 * Copyright (C) 2016 The ARSnova Team                                                                                //
 *                                                                                                                    //
 * ARSnova Click is free software: you can redistribute it and/or modify                                              //
 * it under the terms of the GNU General Public License as published by                                               //
 * the Free Software Foundation, either version 3 of the License, or                                                  //
 * (at your option) any later version.                                                                                //
 *                                                                                                                    //
 * ARSnova Click is distributed in the hope that it will be useful,                                                   //
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                     //
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                      //
 * GNU General Public License for more details.                                                                       //
 *                                                                                                                    //
 * You should have received a copy of the GNU General Public License                                                  //
 * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                           //
                                                                                                                      //
var QuestionGroupCollection = exports.QuestionGroupCollection = new _mongo.Mongo.Collection("questionGroup");         // 23
var questionTextSchema = exports.questionTextSchema = {                                                               // 24
	type: String,                                                                                                        // 25
	optional: true,                                                                                                      // 26
	max: 10000                                                                                                           // 27
};                                                                                                                    //
var timerSchema = exports.timerSchema = {                                                                             // 29
	type: Number,                                                                                                        // 30
	min: 0                                                                                                               // 31
};                                                                                                                    //
var startTimeSchema = exports.startTimeSchema = {                                                                     // 33
	type: String,                                                                                                        // 34
	optional: true                                                                                                       // 35
};                                                                                                                    //
                                                                                                                      //
var questionGroupSchema = exports.questionGroupSchema = new _aldeedSimpleSchema.SimpleSchema({                        // 38
	hashtag: _collection.hashtagSchema,                                                                                  // 39
	questionList: {                                                                                                      // 40
		/* The index is defined in the EventManager.questionIndex variable. The arrays index represents the questionIndex. */
		type: [Object]                                                                                                      // 42
	},                                                                                                                   //
	"questionList.$.hashtag": {                                                                                          // 44
		type: _collection.hashtagSchema,                                                                                    // 45
		optional: true                                                                                                      // 46
	},                                                                                                                   //
	"questionList.$.type": {                                                                                             // 48
		type: String,                                                                                                       // 49
		optional: true                                                                                                      // 50
	},                                                                                                                   //
	"questionList.$.questionText": {                                                                                     // 52
		type: questionTextSchema,                                                                                           // 53
		optional: true                                                                                                      // 54
	},                                                                                                                   //
	"questionList.$.questionIndex": {                                                                                    // 56
		type: Number,                                                                                                       // 57
		optional: true                                                                                                      // 58
	},                                                                                                                   //
	"questionList.$.answerOptionList": {                                                                                 // 60
		type: [Object],                                                                                                     // 61
		optional: true,                                                                                                     // 62
		blackbox: true                                                                                                      // 63
	},                                                                                                                   //
	"questionList.$.timer": {                                                                                            // 65
		type: timerSchema                                                                                                   // 66
	},                                                                                                                   //
	"questionList.$.startTime": {                                                                                        // 68
		type: startTimeSchema,                                                                                              // 69
		optional: true                                                                                                      // 70
	}                                                                                                                    //
});                                                                                                                   //
                                                                                                                      //
//QuestionGroupCollection.attachSchema(questionGroupSchema);                                                          //
                                                                                                                      //
QuestionGroupCollection.deny({                                                                                        // 76
	insert: function () {                                                                                                // 77
		function insert() {                                                                                                 // 77
			return true;                                                                                                       // 78
		}                                                                                                                   //
                                                                                                                      //
		return insert;                                                                                                      //
	}(),                                                                                                                 //
	update: function () {                                                                                                // 80
		function update() {                                                                                                 // 80
			return true;                                                                                                       // 81
		}                                                                                                                   //
                                                                                                                      //
		return update;                                                                                                      //
	}(),                                                                                                                 //
	remove: function () {                                                                                                // 83
		function remove() {                                                                                                 // 83
			return true;                                                                                                       // 84
		}                                                                                                                   //
                                                                                                                      //
		return remove;                                                                                                      //
	}()                                                                                                                  //
});                                                                                                                   //
                                                                                                                      //
QuestionGroupCollection.allow({                                                                                       // 88
	insert: function () {                                                                                                // 89
		function insert(userId, doc) {                                                                                      // 89
			return localData.containsHashtag(doc.hashtag);                                                                     // 90
		}                                                                                                                   //
                                                                                                                      //
		return insert;                                                                                                      //
	}(),                                                                                                                 //
	update: function () {                                                                                                // 92
		function update(userId, doc) {                                                                                      // 92
			return localData.containsHashtag(doc.hashtag);                                                                     // 93
		}                                                                                                                   //
                                                                                                                      //
		return update;                                                                                                      //
	}(),                                                                                                                 //
	remove: function () {                                                                                                // 95
		function remove(userId, doc) {                                                                                      // 95
			return localData.containsHashtag(doc.hashtag);                                                                     // 96
		}                                                                                                                   //
                                                                                                                      //
		return remove;                                                                                                      //
	}()                                                                                                                  //
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"question_abstract.js":["babel-runtime/helpers/classCallCheck","../answeroptions/answeroption_abstract.js","../answeroptions/answeroption_default.js",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/questions/question_abstract.js                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
exports.AbstractQuestion = undefined;                                                                                 //
                                                                                                                      //
var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _answeroption_abstract = require('../answeroptions/answeroption_abstract.js');                                    // 1
                                                                                                                      //
var _answeroption_default = require('../answeroptions/answeroption_default.js');                                      // 2
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                     //
                                                                                                                      //
var hashtag = Symbol("hashtag");                                                                                      // 4
var questionText = Symbol("questionText");                                                                            // 5
var timer = Symbol("timer");                                                                                          // 6
var startTime = Symbol("startTime");                                                                                  // 7
var questionIndex = Symbol("questionIndex");                                                                          // 8
var answerOptionList = Symbol("answerOptionList");                                                                    // 9
                                                                                                                      //
var AbstractQuestion = exports.AbstractQuestion = function () {                                                       //
                                                                                                                      //
	/**                                                                                                                  //
  * Constructor super method for creating a Question instance                                                         //
  * This method cannot be invoked directly.                                                                           //
  * @param {{hashtag:String,questionText:String,timer:Number,startTime:Number,questionIndex:Number,type:String,answerOptionList:Array}} options An object containing the parameters for creating a Question instance. The type and answerOptionList attributes are optional.
  * @throws {TypeError} If this method is invoked directly, the options Object is undefined or the optional type attribute is not matching the constructor name
  * @throws {Error} If the hashtag, the questionText, the timer, the startTime or the questionIndex attributes of the options Object are missing
  */                                                                                                                  //
                                                                                                                      //
	function AbstractQuestion(options) {                                                                                 // 20
		(0, _classCallCheck3['default'])(this, AbstractQuestion);                                                           //
                                                                                                                      //
		if (this.constructor === AbstractQuestion) {                                                                        // 21
			throw new TypeError("Cannot construct Abstract instances directly");                                               // 22
		}                                                                                                                   //
		if (typeof options.hashtag === "undefined" || typeof options.questionText === "undefined" || typeof options.timer === "undefined" || typeof options.startTime === "undefined" || typeof options.questionIndex === "undefined") {
			throw new Error("Invalid argument list for " + this.constructor.name + " instantiation");                          // 25
		}                                                                                                                   //
		this[hashtag] = options.hashtag;                                                                                    // 27
		this[questionText] = options.questionText;                                                                          // 28
		this[timer] = options.timer;                                                                                        // 29
		this[startTime] = options.startTime;                                                                                // 30
		this[questionIndex] = options.questionIndex;                                                                        // 31
		this[answerOptionList] = [];                                                                                        // 32
		if (typeof options.answerOptionList === "undefined" || options.answerOptionList.length === 0) {                     // 33
			for (var i = 0; i < 4; i++) {                                                                                      // 34
				this.addAnswerOption(new _answeroption_default.DefaultAnswerOption({                                              // 35
					hashtag: options.hashtag,                                                                                        // 37
					questionIndex: options.questionIndex,                                                                            // 38
					answerText: "",                                                                                                  // 39
					answerOptionNumber: i,                                                                                           // 40
					isCorrect: false                                                                                                 // 41
				}));                                                                                                              //
			}                                                                                                                  //
		} else {                                                                                                            //
			for (var _i = 0; _i < options.answerOptionList.length; _i++) {                                                     // 46
				if (options.answerOptionList[_i] instanceof _answeroption_abstract.AbstractAnswerOption) {                        // 47
					this.addAnswerOption(options.answerOptionList[_i]);                                                              // 48
				} else {                                                                                                          //
					if (options.answerOptionList[_i] instanceof Object) {                                                            // 50
						switch (options.answerOptionList[_i].type) {                                                                    // 51
							case "DefaultAnswerOption":                                                                                    // 52
								this.addAnswerOption(new _answeroption_default.DefaultAnswerOption(options.answerOptionList[_i]));            // 53
								break;                                                                                                        // 54
						}                                                                                                               // 51
					} else {                                                                                                         //
						throw new Error("Invalid argument list for " + this.constructor.name + " instantiation");                       // 57
					}                                                                                                                //
				}                                                                                                                 //
			}                                                                                                                  //
		}                                                                                                                   //
	}                                                                                                                    //
                                                                                                                      //
	/**                                                                                                                  //
  * Returns the Hashtag of the Question instance                                                                      //
  * @returns {String} The hashtag identifying the session                                                             //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestion.prototype.getHashtag = function () {                                                                // 11
		function getHashtag() {                                                                                             //
			return this[hashtag];                                                                                              // 69
		}                                                                                                                   //
                                                                                                                      //
		return getHashtag;                                                                                                  //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Sets the question text for the Question instance displayed during the quiz                                        //
  * @param {String} text The text which will be displayed during the quiz                                             //
  * @throws {Error} If the text is not of type String                                                                 //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestion.prototype.setQuestionText = function () {                                                           // 11
		function setQuestionText(text) {                                                                                    //
			if (typeof text !== "string") {                                                                                    // 78
				throw new Error("Invalid argument for Question.setText");                                                         // 79
			}                                                                                                                  //
			this[questionText] = text;                                                                                         // 81
		}                                                                                                                   //
                                                                                                                      //
		return setQuestionText;                                                                                             //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Returns the currently set question text                                                                           //
  * @returns {String} The current question text                                                                       //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestion.prototype.getQuestionText = function () {                                                           // 11
		function getQuestionText() {                                                                                        //
			return this[questionText];                                                                                         // 89
		}                                                                                                                   //
                                                                                                                      //
		return getQuestionText;                                                                                             //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Returns the current index of the question                                                                         //
  * @returns {Number} The current index of the question                                                               //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestion.prototype.getQuestionIndex = function () {                                                          // 11
		function getQuestionIndex() {                                                                                       //
			return this[questionIndex];                                                                                        // 97
		}                                                                                                                   //
                                                                                                                      //
		return getQuestionIndex;                                                                                            //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Sets the index of the question and populates the changes to the AnswerOptions of this Question instance           //
  * @param {Number} index The new index of the question                                                               //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestion.prototype.setQuestionIndex = function () {                                                          // 11
		function setQuestionIndex(index) {                                                                                  //
			this[questionIndex] = index;                                                                                       // 105
			for (var i = 0; i < this.getAnswerOptionList().length; i++) {                                                      // 106
				this.getAnswerOptionList()[i].setQuestionIndex(index);                                                            // 107
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return setQuestionIndex;                                                                                            //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Sets the timer of the Question instance                                                                           //
  * @param {Number} time The timer for the questions countdown. Must be in seconds.                                   //
  * @throws {Error} If the time is not of type Number                                                                 //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestion.prototype.setTimer = function () {                                                                  // 11
		function setTimer(time) {                                                                                           //
			if (typeof time !== "number") {                                                                                    // 117
				throw new Error("Invalid argument for Question.setTimer");                                                        // 118
			}                                                                                                                  //
			this[timer] = time;                                                                                                // 120
		}                                                                                                                   //
                                                                                                                      //
		return setTimer;                                                                                                    //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Returns the currently set timer value                                                                             //
  * @returns {Number} The current timer value                                                                         //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestion.prototype.getTimer = function () {                                                                  // 11
		function getTimer() {                                                                                               //
			return this[timer];                                                                                                // 128
		}                                                                                                                   //
                                                                                                                      //
		return getTimer;                                                                                                    //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Sets the start time of the question countdown                                                                     //
  * @param {Number} time The timestamp of the Date() Object where the question starts                                 //
  * @throws {Error} If the timestamp is not of type Number or is in the past                                          //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestion.prototype.setStartTime = function () {                                                              // 11
		function setStartTime(time) {                                                                                       //
			if (typeof time !== "number" || new Date(time) <= new Date()) {                                                    // 137
				throw new Error("Invalid argument for Question.setStartTime");                                                    // 138
			}                                                                                                                  //
			this[startTime] = time;                                                                                            // 140
		}                                                                                                                   //
                                                                                                                      //
		return setStartTime;                                                                                                //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Returns the currently set start time                                                                              //
  * @returns {Number} The currently set start time                                                                    //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestion.prototype.getStartTime = function () {                                                              // 11
		function getStartTime() {                                                                                           //
			return this[startTime];                                                                                            // 148
		}                                                                                                                   //
                                                                                                                      //
		return getStartTime;                                                                                                //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Adds a new AnswerOption to the Question instance                                                                  //
  * @param {AbstractAnswerOption} answerOption The AnswerOption instance to be added                                  //
  * @param {Number} [index] An optional index where the AnswerOption instance should be added. If not set or set to an invalid value the instance is added to the end of the answerOptionList
  * @throws {Error} If the answerOption is not of tye AbstractAnswerOption                                            //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestion.prototype.addAnswerOption = function () {                                                           // 11
		function addAnswerOption(answerOption, index) {                                                                     //
			if (typeof answerOption === "undefined" || !(answerOption instanceof _answeroption_abstract.AbstractAnswerOption)) {
				throw new Error("Invalid argument for Question.removeAnswerOption");                                              // 159
			}                                                                                                                  //
			if (typeof index === "undefined" || index < 0 || index >= this.getAnswerOptionList().length) {                     // 161
				this[answerOptionList].push(answerOption);                                                                        // 162
			} else {                                                                                                           //
				this[answerOptionList][index] = answerOption;                                                                     // 164
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return addAnswerOption;                                                                                             //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Removes an AnswerOption from the answerOptionList                                                                 //
  * @param {Number} index The index of the AnswerOption instance which shall be removed                               //
  * @throws {Error} If the index is not set or set to an invalid value                                                //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestion.prototype.removeAnswerOption = function () {                                                        // 11
		function removeAnswerOption(index) {                                                                                //
			if (typeof index === "undefined" || index < 0 || index > this.getAnswerOptionList().length) {                      // 174
				throw new Error("Invalid argument for Question.removeAnswerOption");                                              // 175
			}                                                                                                                  //
			this[answerOptionList].splice(index, 1);                                                                           // 177
		}                                                                                                                   //
                                                                                                                      //
		return removeAnswerOption;                                                                                          //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Removes all AnswerOption instances in the answerOptionList.                                                       //
  * The AnswerOption instance objects are not destroyed                                                               //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestion.prototype.removeAllAnswerOptions = function () {                                                    // 11
		function removeAllAnswerOptions() {                                                                                 //
			this[answerOptionList] = [];                                                                                       // 185
		}                                                                                                                   //
                                                                                                                      //
		return removeAllAnswerOptions;                                                                                      //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Returns the answerOptionList                                                                                      //
  * @returns {Array} The list of all AnswerOptions currently hold by this Question instance                           //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestion.prototype.getAnswerOptionList = function () {                                                       // 11
		function getAnswerOptionList() {                                                                                    //
			return this[answerOptionList];                                                                                     // 193
		}                                                                                                                   //
                                                                                                                      //
		return getAnswerOptionList;                                                                                         //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Serialize the instance object to a JSON compatible object                                                         //
  * @returns {{hashtag:String,questionText:String,type:AbstractQuestion,timer:Number,startTime:Number,questionIndex:Number,answerOptionList:Array}}
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestion.prototype.serialize = function () {                                                                 // 11
		function serialize() {                                                                                              //
			var answerOptionListSerialized = [];                                                                               // 201
			this.getAnswerOptionList().forEach(function (answeroption) {                                                       // 202
				answerOptionListSerialized.push(answeroption.serialize());                                                        // 202
			});                                                                                                                //
			return {                                                                                                           // 203
				hashtag: this.getHashtag(),                                                                                       // 204
				questionText: this.getQuestionText(),                                                                             // 205
				timer: this.getTimer(),                                                                                           // 206
				startTime: this.getStartTime(),                                                                                   // 207
				questionIndex: this.getQuestionIndex(),                                                                           // 208
				answerOptionList: answerOptionListSerialized                                                                      // 209
			};                                                                                                                 //
		}                                                                                                                   //
                                                                                                                      //
		return serialize;                                                                                                   //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Checks if the properties of this instance are valid. Checks also recursively all including AnswerOption instances
  * and summarizes their result of calling .isValid()                                                                 //
  * @returns {boolean} True, if the complete Question instance is valid, False otherwise                              //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestion.prototype.isValid = function () {                                                                   // 11
		function isValid() {                                                                                                //
			var answerOptionListValid = true;                                                                                  // 219
			this.getAnswerOptionList().forEach(function (answerOption) {                                                       // 220
				if (!answerOption.isValid()) {                                                                                    // 221
					answerOptionListValid = false;                                                                                   // 222
				}                                                                                                                 //
			});                                                                                                                //
			var markdownChars = this.getQuestionText().split().map(function (currentValue) {                                   // 225
				var tmpValue = currentValue;                                                                                      // 226
				tmpValue = tmpValue.replace(/#/g, "");                                                                            // 227
				tmpValue = tmpValue.replace(/\*/g, "");                                                                           // 228
				tmpValue = tmpValue.replace(/1./g, "");                                                                           // 229
				tmpValue = tmpValue.replace(/\[/g, "");                                                                           // 230
				tmpValue = tmpValue.replace(/\]\(/g, "");                                                                         // 231
				tmpValue = tmpValue.replace(/\)/g, "");                                                                           // 232
				tmpValue = tmpValue.replace(/- /g, "");                                                                           // 233
				tmpValue = tmpValue.replace(/ /g, "");                                                                            // 234
				tmpValue = tmpValue.replace(/\\\(/g, "");                                                                         // 235
				tmpValue = tmpValue.replace(/\\\)/g, "");                                                                         // 236
				tmpValue = tmpValue.replace(/$/g, "");                                                                            // 237
				tmpValue = tmpValue.replace(/<hlcode>/g, "");                                                                     // 238
				tmpValue = tmpValue.replace(/<\/hlcode>/g, "");                                                                   // 239
				tmpValue = tmpValue.replace(/>/g, "");                                                                            // 240
				return tmpValue.length;                                                                                           // 241
			});                                                                                                                //
			return answerOptionListValid && markdownChars[0] > 4 && markdownChars[0] < 10001 && this.getTimer() > 5 && this.getTimer() < 261;
		}                                                                                                                   //
                                                                                                                      //
		return isValid;                                                                                                     //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Gets the validation error reason from the question and all included answerOptions as a stackable array            //
  * @returns {Array} Contains an Object which holds the number of the current question and the reason why the validation has failed
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestion.prototype.getValidationStackTrace = function () {                                                   // 11
		function getValidationStackTrace() {                                                                                //
			var result = [];                                                                                                   // 251
			var markdownChars = this.getQuestionText().split().map(function (currentValue) {                                   // 252
				var tmpValue = currentValue;                                                                                      // 253
				tmpValue = tmpValue.replace(/#/g, "");                                                                            // 254
				tmpValue = tmpValue.replace(/\*/g, "");                                                                           // 255
				tmpValue = tmpValue.replace(/1./g, "");                                                                           // 256
				tmpValue = tmpValue.replace(/\[/g, "");                                                                           // 257
				tmpValue = tmpValue.replace(/\]\(/g, "");                                                                         // 258
				tmpValue = tmpValue.replace(/\)/g, "");                                                                           // 259
				tmpValue = tmpValue.replace(/- /g, "");                                                                           // 260
				tmpValue = tmpValue.replace(/ /g, "");                                                                            // 261
				tmpValue = tmpValue.replace(/\\\(/g, "");                                                                         // 262
				tmpValue = tmpValue.replace(/\\\)/g, "");                                                                         // 263
				tmpValue = tmpValue.replace(/$/g, "");                                                                            // 264
				tmpValue = tmpValue.replace(/<hlcode>/g, "");                                                                     // 265
				tmpValue = tmpValue.replace(/<\/hlcode>/g, "");                                                                   // 266
				tmpValue = tmpValue.replace(/>/g, "");                                                                            // 267
				return tmpValue.length;                                                                                           // 268
			});                                                                                                                //
			if (markdownChars[0] < 5) {                                                                                        // 270
				result.push({ occuredAt: { type: "question", id: this.getQuestionIndex() }, reason: "question_text_too_small" });
			} else if (markdownChars[0] > 1000) {                                                                              //
				result.push({ occuredAt: { type: "question", id: this.getQuestionIndex() }, reason: "question_text_too_long" });  // 273
			}                                                                                                                  //
			if (this.getTimer() < 6) {                                                                                         // 275
				result.push({ occuredAt: { type: "question", id: this.getQuestionIndex() }, reason: "timer_too_small" });         // 276
			} else if (this.getTimer() > 260) {                                                                                //
				result.push({ occuredAt: { type: "question", id: this.getQuestionIndex() }, reason: "timer_too_big" });           // 278
			}                                                                                                                  //
			this.getAnswerOptionList().forEach(function (answerOption) {                                                       // 280
				if (!answerOption.isValid()) {                                                                                    // 281
					$.merge(result, answerOption.getValidationStackTrace());                                                         // 282
				}                                                                                                                 //
			});                                                                                                                //
			return result;                                                                                                     // 285
		}                                                                                                                   //
                                                                                                                      //
		return getValidationStackTrace;                                                                                     //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Checks for equivalence relations to another Question instance. Also part of the EJSON interface                   //
  * @see http://docs.meteor.com/api/ejson.html#EJSON-CustomType-equals                                                //
  * @param {AbstractQuestion} question The Question instance which should be checked                                  //
  * @returns {boolean} True if both instances are completely equal, False otherwise                                   //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestion.prototype.equals = function () {                                                                    // 11
		function equals(question) {                                                                                         //
			if (question instanceof AbstractQuestion) {                                                                        // 295
				var questionAnswerOptionList = question.getAnswerOptionList();                                                    // 296
				if (questionAnswerOptionList.length === this.getAnswerOptionList().length) {                                      // 297
					var isEqual = true;                                                                                              // 298
					for (var i = 0; i < this.getAnswerOptionList().length; i++) {                                                    // 299
						if (isEqual && !this.getAnswerOptionList()[i].equals(questionAnswerOptionList[i])) {                            // 300
							isEqual = false;                                                                                               // 301
						}                                                                                                               //
					}                                                                                                                //
					if (question.getTimer() !== this.getTimer() || question.getStartTime() !== this.getStartTime() || question.getHashtag() !== this.getHashtag() || question.getQuestionText() !== this.getQuestionText()) {
						isEqual = false;                                                                                                // 308
					}                                                                                                                //
					return isEqual;                                                                                                  // 310
				}                                                                                                                 //
			}                                                                                                                  //
			return false;                                                                                                      // 313
		}                                                                                                                   //
                                                                                                                      //
		return equals;                                                                                                      //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Part of EJSON interface                                                                                           //
  * @see AbstractQuestion.serialize()                                                                                 //
  * @see http://docs.meteor.com/api/ejson.html#EJSON-CustomType-toJSONValue                                           //
  * @returns {{hashtag,questionText,type,timer,startTime,questionIndex,answerOptionList}|{hashtag:String,questionText:String,type:AbstractQuestion,timer:Number,startTime:Number,questionIndex:Number,answerOptionList:Array}}
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestion.prototype.toJSONValue = function () {                                                               // 11
		function toJSONValue() {                                                                                            //
			return this.serialize();                                                                                           // 323
		}                                                                                                                   //
                                                                                                                      //
		return toJSONValue;                                                                                                 //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Quick way to insert a default AnswerOption to the Question instance.                                              //
  * @param {Number} [index] The index where the AnswerOption should be inserted. If not passed, it will be added to the end of the answerOptionList
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestion.prototype.addDefaultAnswerOption = function () {                                                    // 11
		function addDefaultAnswerOption(index) {                                                                            //
			if (typeof index === "undefined" || index >= this.getAnswerOptionList().length) {                                  // 331
				index = this.getAnswerOptionList().length;                                                                        // 332
			}                                                                                                                  //
			this.addAnswerOption(new _answeroption_default.DefaultAnswerOption({                                               // 334
				hashtag: this.getHashtag(),                                                                                       // 336
				questionIndex: this.getQuestionIndex(),                                                                           // 337
				answerText: "",                                                                                                   // 338
				answerOptionNumber: index,                                                                                        // 339
				isCorrect: false                                                                                                  // 340
			}), index);                                                                                                        //
		}                                                                                                                   //
                                                                                                                      //
		return addDefaultAnswerOption;                                                                                      //
	}();                                                                                                                 //
                                                                                                                      //
	return AbstractQuestion;                                                                                             //
}();                                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"question_choice_abstract.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","./question_abstract.js",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/questions/question_choice_abstract.js                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
exports.AbstractChoiceQuestion = undefined;                                                                           //
                                                                                                                      //
var _classCallCheck2 = require("babel-runtime/helpers/classCallCheck");                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require("babel-runtime/helpers/possibleConstructorReturn");                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require("babel-runtime/helpers/inherits");                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
var _question_abstract = require("./question_abstract.js");                                                           // 1
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
var AbstractChoiceQuestion = exports.AbstractChoiceQuestion = function (_AbstractQuestion) {                          //
	(0, _inherits3["default"])(AbstractChoiceQuestion, _AbstractQuestion);                                               //
                                                                                                                      //
                                                                                                                      //
	/**                                                                                                                  //
  * Constructor super method for creating an AbstractChoiceQuestion instance                                          //
  * This method cannot be invoked directly.                                                                           //
  * @see AbstractQuestion.constructor()                                                                               //
  * @param options                                                                                                    //
  */                                                                                                                  //
                                                                                                                      //
	function AbstractChoiceQuestion(options) {                                                                           // 11
		(0, _classCallCheck3["default"])(this, AbstractChoiceQuestion);                                                     //
                                                                                                                      //
		var _this = (0, _possibleConstructorReturn3["default"])(this, _AbstractQuestion.call(this, options));               //
                                                                                                                      //
		if (_this.constructor === AbstractChoiceQuestion) {                                                                 // 13
			throw new TypeError("Cannot construct Abstract instances directly");                                               // 14
		}                                                                                                                   //
		return _this;                                                                                                       //
	}                                                                                                                    //
                                                                                                                      //
	/**                                                                                                                  //
  * Checks if the properties of this instance are valid. Checks also recursively all including AnswerOption instances
  * and summarizes their result of calling .isValid()                                                                 //
  * @see AbstractQuestion.isValid()                                                                                   //
  * @returns {boolean} True, if the complete Question instance is valid, False otherwise                              //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractChoiceQuestion.prototype.isValid = function () {                                                             // 3
		function isValid() {                                                                                                //
			var hasValidAnswer = false;                                                                                        // 25
			this.getAnswerOptionList().forEach(function (answeroption) {                                                       // 26
				if (answeroption.getIsCorrect()) {                                                                                // 27
					hasValidAnswer = true;                                                                                           // 28
				}                                                                                                                 //
			});                                                                                                                //
			return _AbstractQuestion.prototype.isValid.call(this) && this.getAnswerOptionList().length > 0 && hasValidAnswer;  // 31
		}                                                                                                                   //
                                                                                                                      //
		return isValid;                                                                                                     //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Gets the validation error reason from the question and all included answerOptions as a stackable array            //
  * @returns {Array} Contains an Object which holds the number of the current question and the reason why the validation has failed
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractChoiceQuestion.prototype.getValidationStackTrace = function () {                                             // 3
		function getValidationStackTrace() {                                                                                //
			return _AbstractQuestion.prototype.getValidationStackTrace.call(this);                                             // 39
		}                                                                                                                   //
                                                                                                                      //
		return getValidationStackTrace;                                                                                     //
	}();                                                                                                                 //
                                                                                                                      //
	return AbstractChoiceQuestion;                                                                                       //
}(_question_abstract.AbstractQuestion);                                                                               //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"question_choice_multiple.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/ejson","./question_choice_abstract.js",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/questions/question_choice_multiple.js                                                                          //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
exports.MultipleChoiceQuestion = undefined;                                                                           //
                                                                                                                      //
var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require('babel-runtime/helpers/possibleConstructorReturn');                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require('babel-runtime/helpers/inherits');                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
var _ejson = require('meteor/ejson');                                                                                 // 1
                                                                                                                      //
var _question_choice_abstract = require('./question_choice_abstract.js');                                             // 2
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                     //
                                                                                                                      //
var MultipleChoiceQuestion = exports.MultipleChoiceQuestion = function (_AbstractChoiceQuesti) {                      //
	(0, _inherits3['default'])(MultipleChoiceQuestion, _AbstractChoiceQuesti);                                           //
                                                                                                                      //
                                                                                                                      //
	/**                                                                                                                  //
  * Constructs a MultipleChoiceQuestion instance                                                                      //
  * @see AbstractChoiceQuestion.constructor()                                                                         //
  * @param options                                                                                                    //
  */                                                                                                                  //
                                                                                                                      //
	function MultipleChoiceQuestion(options) {                                                                           // 11
		(0, _classCallCheck3['default'])(this, MultipleChoiceQuestion);                                                     //
                                                                                                                      //
		if (typeof options.type !== "undefined" && options.type !== "MultipleChoiceQuestion") {                             // 12
			throw new TypeError("Invalid construction type while creating new MultipleChoiceQuestion");                        // 13
		}                                                                                                                   //
		return (0, _possibleConstructorReturn3['default'])(this, _AbstractChoiceQuesti.call(this, options));                //
	}                                                                                                                    //
                                                                                                                      //
	/**                                                                                                                  //
  * Part of EJSON interface                                                                                           //
  * @see http://docs.meteor.com/api/ejson.html#EJSON-clone                                                            //
  * @returns {MultipleChoiceQuestion} An independent deep copy of the current instance                                //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	MultipleChoiceQuestion.prototype.clone = function () {                                                               // 4
		function clone() {                                                                                                  //
			return new MultipleChoiceQuestion(this.serialize());                                                               // 24
		}                                                                                                                   //
                                                                                                                      //
		return clone;                                                                                                       //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Serialize the instance object to a JSON compatible object                                                         //
  * @returns {{hashtag:String,questionText:String,type:AbstractQuestion,timer:Number,startTime:Number,questionIndex:Number,answerOptionList:Array}}
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	MultipleChoiceQuestion.prototype.serialize = function () {                                                           // 4
		function serialize() {                                                                                              //
			return $.extend(_AbstractChoiceQuesti.prototype.serialize.call(this), { type: "MultipleChoiceQuestion" });         // 32
		}                                                                                                                   //
                                                                                                                      //
		return serialize;                                                                                                   //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Part of EJSON interface.                                                                                          //
  * @see http://docs.meteor.com/api/ejson.html#EJSON-CustomType-typeName                                              //
  * @returns {String} The name of the instantiated class                                                              //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	MultipleChoiceQuestion.prototype.typeName = function () {                                                            // 4
		function typeName() {                                                                                               //
			return "MultipleChoiceQuestion";                                                                                   // 41
		}                                                                                                                   //
                                                                                                                      //
		return typeName;                                                                                                    //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Gets the validation error reason from the question and all included answerOptions as a stackable array            //
  * @returns {Array} Contains an Object which holds the number of the current question and the reason why the validation has failed
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	MultipleChoiceQuestion.prototype.getValidationStackTrace = function () {                                             // 4
		function getValidationStackTrace() {                                                                                //
			var parentStackTrace = _AbstractChoiceQuesti.prototype.getValidationStackTrace.call(this);                         // 49
			var hasValidAnswer = false;                                                                                        // 50
			this.getAnswerOptionList().forEach(function (answeroption) {                                                       // 51
				if (answeroption.getIsCorrect()) {                                                                                // 52
					hasValidAnswer = true;                                                                                           // 53
				}                                                                                                                 //
			});                                                                                                                //
			if (!hasValidAnswer) {                                                                                             // 56
				parentStackTrace.push({ occuredAt: { type: "question", id: this.getQuestionIndex() }, reason: "no_valid_answers" });
			}                                                                                                                  //
			return parentStackTrace;                                                                                           // 59
		}                                                                                                                   //
                                                                                                                      //
		return getValidationStackTrace;                                                                                     //
	}();                                                                                                                 //
                                                                                                                      //
	return MultipleChoiceQuestion;                                                                                       //
}(_question_choice_abstract.AbstractChoiceQuestion);                                                                  //
                                                                                                                      //
/**                                                                                                                   //
 * Adds a custom type to Meteor's EJSON                                                                               //
 * @see http://docs.meteor.com/api/ejson.html#EJSON-addType                                                           //
 */                                                                                                                   //
                                                                                                                      //
                                                                                                                      //
_ejson.EJSON.addType("MultipleChoiceQuestion", function (value) {                                                     // 67
	return new MultipleChoiceQuestion(value);                                                                            // 68
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"question_choice_single.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/ejson","./question_choice_abstract.js",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/questions/question_choice_single.js                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
exports.SingleChoiceQuestion = undefined;                                                                             //
                                                                                                                      //
var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require('babel-runtime/helpers/possibleConstructorReturn');                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require('babel-runtime/helpers/inherits');                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
var _ejson = require('meteor/ejson');                                                                                 // 1
                                                                                                                      //
var _question_choice_abstract = require('./question_choice_abstract.js');                                             // 2
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                     //
                                                                                                                      //
var SingleChoiceQuestion = exports.SingleChoiceQuestion = function (_AbstractChoiceQuesti) {                          //
	(0, _inherits3['default'])(SingleChoiceQuestion, _AbstractChoiceQuesti);                                             //
                                                                                                                      //
                                                                                                                      //
	/**                                                                                                                  //
  * Constructs a MultipleChoiceQuestion instance                                                                      //
  * @see AbstractChoiceQuestion.constructor()                                                                         //
  * @param options                                                                                                    //
  */                                                                                                                  //
                                                                                                                      //
	function SingleChoiceQuestion(options) {                                                                             // 11
		(0, _classCallCheck3['default'])(this, SingleChoiceQuestion);                                                       //
                                                                                                                      //
		if (typeof options.type !== "undefined" && options.type !== "SingleChoiceQuestion") {                               // 12
			throw new TypeError("Invalid construction type while creating new SingleChoiceQuestion");                          // 13
		}                                                                                                                   //
		return (0, _possibleConstructorReturn3['default'])(this, _AbstractChoiceQuesti.call(this, options));                //
	}                                                                                                                    //
                                                                                                                      //
	/**                                                                                                                  //
  * Part of EJSON interface                                                                                           //
  * @see http://docs.meteor.com/api/ejson.html#EJSON-clone                                                            //
  * @returns {MultipleChoiceQuestion} An independent deep copy of the current instance                                //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	SingleChoiceQuestion.prototype.clone = function () {                                                                 // 4
		function clone() {                                                                                                  //
			return new SingleChoiceQuestion(this.serialize());                                                                 // 24
		}                                                                                                                   //
                                                                                                                      //
		return clone;                                                                                                       //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Serialize the instance object to a JSON compatible object                                                         //
  * @returns {{hashtag:String,questionText:String,type:AbstractQuestion,timer:Number,startTime:Number,questionIndex:Number,answerOptionList:Array}}
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	SingleChoiceQuestion.prototype.serialize = function () {                                                             // 4
		function serialize() {                                                                                              //
			return $.extend(_AbstractChoiceQuesti.prototype.serialize.call(this), { type: "SingleChoiceQuestion" });           // 32
		}                                                                                                                   //
                                                                                                                      //
		return serialize;                                                                                                   //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Checks if the properties of this instance are valid. Checks also recursively all including AnswerOption instances
  * and summarizes their result of calling .isValid(). Checks also if this Question instance contains exactly one correct AnswerOption
  * @see AbstractChoiceQuestion.isValid()                                                                             //
  * @returns {boolean} True, if the complete Question instance is valid, False otherwise                              //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	SingleChoiceQuestion.prototype.isValid = function () {                                                               // 4
		function isValid() {                                                                                                //
			var hasValidAnswer = 0;                                                                                            // 42
			this.getAnswerOptionList().forEach(function (answeroption) {                                                       // 43
				if (answeroption.getIsCorrect()) {                                                                                // 44
					hasValidAnswer++;                                                                                                // 45
				}                                                                                                                 //
			});                                                                                                                //
			return _AbstractChoiceQuesti.prototype.isValid.call(this) && hasValidAnswer === 1;                                 // 48
		}                                                                                                                   //
                                                                                                                      //
		return isValid;                                                                                                     //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Gets the validation error reason from the question and all included answerOptions as a stackable array            //
  * @returns {Array} Contains an Object which holds the number of the current question and the reason why the validation has failed
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	SingleChoiceQuestion.prototype.getValidationStackTrace = function () {                                               // 4
		function getValidationStackTrace() {                                                                                //
			var hasValidAnswer = 0;                                                                                            // 56
			this.getAnswerOptionList().forEach(function (answeroption) {                                                       // 57
				if (answeroption.getIsCorrect()) {                                                                                // 58
					hasValidAnswer++;                                                                                                // 59
				}                                                                                                                 //
			});                                                                                                                //
			var parentStackTrace = _AbstractChoiceQuesti.prototype.getValidationStackTrace.call(this);                         // 62
			if (hasValidAnswer !== 1) {                                                                                        // 63
				parentStackTrace.push({ occuredAt: { type: "question", id: this.getQuestionIndex() }, reason: "one_valid_answer_required" });
			}                                                                                                                  //
			return parentStackTrace;                                                                                           // 66
		}                                                                                                                   //
                                                                                                                      //
		return getValidationStackTrace;                                                                                     //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Part of EJSON interface.                                                                                          //
  * @see http://docs.meteor.com/api/ejson.html#EJSON-CustomType-typeName                                              //
  * @returns {String} The name of the instantiated class                                                              //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	SingleChoiceQuestion.prototype.typeName = function () {                                                              // 4
		function typeName() {                                                                                               //
			return "SingleChoiceQuestion";                                                                                     // 75
		}                                                                                                                   //
                                                                                                                      //
		return typeName;                                                                                                    //
	}();                                                                                                                 //
                                                                                                                      //
	return SingleChoiceQuestion;                                                                                         //
}(_question_choice_abstract.AbstractChoiceQuestion);                                                                  //
                                                                                                                      //
/**                                                                                                                   //
 * Adds a custom type to Meteor's EJSON                                                                               //
 * @see http://docs.meteor.com/api/ejson.html#EJSON-addType                                                           //
 */                                                                                                                   //
                                                                                                                      //
                                                                                                                      //
_ejson.EJSON.addType("SingleChoiceQuestion", function (value) {                                                       // 83
	return new SingleChoiceQuestion(value);                                                                              // 84
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"question_ranged.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/ejson","./question_abstract.js",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/questions/question_ranged.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
exports.RangedQuestion = undefined;                                                                                   //
                                                                                                                      //
var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require('babel-runtime/helpers/possibleConstructorReturn');                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require('babel-runtime/helpers/inherits');                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
var _ejson = require('meteor/ejson');                                                                                 // 1
                                                                                                                      //
var _question_abstract = require('./question_abstract.js');                                                           // 2
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                     //
                                                                                                                      //
var rangeMin = Symbol("rangeMin");                                                                                    // 4
var rangeMax = Symbol("rangeMax");                                                                                    // 5
                                                                                                                      //
var RangedQuestion = exports.RangedQuestion = function (_AbstractQuestion) {                                          //
	(0, _inherits3['default'])(RangedQuestion, _AbstractQuestion);                                                       //
                                                                                                                      //
                                                                                                                      //
	/**                                                                                                                  //
  * Constructs a RangedQuestion instance                                                                              //
  * @see AbstractQuestion.constructor()                                                                               //
  * @param options @see AbstractQuestion.constructor().options                                                        //
  * @param options.rangeMin The minimum range which will be accepted as correct                                       //
  * @param options.rangeMax The maximum range which will be accepted as correct                                       //
  */                                                                                                                  //
                                                                                                                      //
	function RangedQuestion(options) {                                                                                   // 16
		(0, _classCallCheck3['default'])(this, RangedQuestion);                                                             //
                                                                                                                      //
		if (typeof options.type !== "undefined" && options.type !== "RangedQuestion") {                                     // 17
			throw new TypeError("Invalid construction type while creating new RangedQuestion");                                // 18
		}                                                                                                                   //
                                                                                                                      //
		var _this = (0, _possibleConstructorReturn3['default'])(this, _AbstractQuestion.call(this, options));               //
                                                                                                                      //
		_this.removeAllAnswerOptions();                                                                                     // 21
		_this[rangeMin] = options.rangeMin || 0;                                                                            // 22
		_this[rangeMax] = options.rangeMax || 0;                                                                            // 23
		return _this;                                                                                                       //
	}                                                                                                                    //
                                                                                                                      //
	/**                                                                                                                  //
  * Sets the maximum allowed range                                                                                    //
  * @param {Number} max The maximum allowed range                                                                     //
  * @throws {Error} If max is not a Number or max is smaller than or equal to the minimum range                       //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	RangedQuestion.prototype.setMaxRange = function () {                                                                 // 7
		function setMaxRange(max) {                                                                                         //
			if (typeof max !== "number" || max <= this[rangeMin]) {                                                            // 32
				throw new Error("Invalid argument list for RangedQuestion.setMaxRange");                                          // 33
			}                                                                                                                  //
			this[rangeMax] = max;                                                                                              // 35
		}                                                                                                                   //
                                                                                                                      //
		return setMaxRange;                                                                                                 //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Sets the minimum allowed range                                                                                    //
  * @param {Number} min The minimum allowed range                                                                     //
  * @throws {Error} If min is not a Number or min is bigger than or equal to the maximum range                        //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	RangedQuestion.prototype.setMinRange = function () {                                                                 // 7
		function setMinRange(min) {                                                                                         //
			if (typeof min !== "number" || min >= this[rangeMax]) {                                                            // 44
				throw new Error("Invalid argument list for RangedQuestion.setMinRange");                                          // 45
			}                                                                                                                  //
			this[rangeMin] = min;                                                                                              // 47
		}                                                                                                                   //
                                                                                                                      //
		return setMinRange;                                                                                                 //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Sets the minimum and maximum allowed range                                                                        //
  * @param {Number} min The minimum allowed range                                                                     //
  * @param {Number} max The maximum allowed range                                                                     //
  * @throws {Error} If min or max are not Numbers or min is bigger than or equal to max                               //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	RangedQuestion.prototype.setRange = function () {                                                                    // 7
		function setRange(min, max) {                                                                                       //
			if (typeof min !== "number" || typeof max !== "number" || min >= max) {                                            // 57
				throw new Error("Invalid argument list for RangedQuestion.setRange");                                             // 58
			}                                                                                                                  //
			this[rangeMin] = min;                                                                                              // 60
			this[rangeMax] = max;                                                                                              // 61
		}                                                                                                                   //
                                                                                                                      //
		return setRange;                                                                                                    //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Returns the current max range                                                                                     //
  * @returns {Number} The current max range                                                                           //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	RangedQuestion.prototype.getMaxRange = function () {                                                                 // 7
		function getMaxRange() {                                                                                            //
			return this[rangeMax];                                                                                             // 69
		}                                                                                                                   //
                                                                                                                      //
		return getMaxRange;                                                                                                 //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Returns the current min range                                                                                     //
  * @returns {Number} The current min range                                                                           //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	RangedQuestion.prototype.getMinRange = function () {                                                                 // 7
		function getMinRange() {                                                                                            //
			return this[rangeMin];                                                                                             // 77
		}                                                                                                                   //
                                                                                                                      //
		return getMinRange;                                                                                                 //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Serialized the instance object to a JSON compatible object                                                        //
  * @see AbstractQuestion.serialize()                                                                                 //
  * @returns {{hashtag, questionText, type, timer, startTime, questionIndex, answerOptionList}|{hashtag: String, questionText: String, type: AbstractQuestion, timer: Number, startTime: Number, questionIndex: Number, answerOptionList: Array}}
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	RangedQuestion.prototype.serialize = function () {                                                                   // 7
		function serialize() {                                                                                              //
			return $.extend(_AbstractQuestion.prototype.serialize.call(this), { type: "RangedQuestion", rangeMin: this.getMinRange(), rangeMax: this.getMaxRange() });
		}                                                                                                                   //
                                                                                                                      //
		return serialize;                                                                                                   //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Checks if the properties of this instance are valid. Checks also recursively all including AnswerOption instances
  * and summarizes their result of calling .isValid(). Checks if the Question has no answers set and if min range is smaller than max range
  * @see AbstractQuestion.isValid()                                                                                   //
  * @returns {boolean} True, if the complete Question instance is valid, False otherwise                              //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	RangedQuestion.prototype.isValid = function () {                                                                     // 7
		function isValid() {                                                                                                //
			return _AbstractQuestion.prototype.isValid.call(this) && this.getAnswerOptionList().length === 0 && this[rangeMin] < this[rangeMax];
		}                                                                                                                   //
                                                                                                                      //
		return isValid;                                                                                                     //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Gets the validation error reason from the question and all included answerOptions as a stackable array            //
  * @returns {Array} Contains an Object which holds the number of the current question and the reason why the validation has failed
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	RangedQuestion.prototype.getValidationStackTrace = function () {                                                     // 7
		function getValidationStackTrace() {                                                                                //
			var parentStackTrace = _AbstractQuestion.prototype.getValidationStackTrace.call(this);                             // 104
			var hasValidRange = this[rangeMin] < this[rangeMax];                                                               // 105
			if (!hasValidRange) {                                                                                              // 106
				parentStackTrace.push({ occuredAt: { type: "question", id: this.getQuestionIndex() }, reason: "invalid_range" });
			}                                                                                                                  //
			return parentStackTrace;                                                                                           // 109
		}                                                                                                                   //
                                                                                                                      //
		return getValidationStackTrace;                                                                                     //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Checks for equivalence relations to another Question instance. Also part of the EJSON interface                   //
  * @see AbstractQuestion.equals()                                                                                    //
  * @see http://docs.meteor.com/api/ejson.html#EJSON-CustomType-equals                                                //
  * @param {RangedQuestion} question The Question instance which should be checked                                    //
  * @returns {boolean} True if both instances are completely equal, False otherwise                                   //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	RangedQuestion.prototype.equals = function () {                                                                      // 7
		function equals(question) {                                                                                         //
			return _AbstractQuestion.prototype.equals.call(this, question) && question.getMaxRange() === this[rangeMax] && question.getMinRange() === this[rangeMin];
		}                                                                                                                   //
                                                                                                                      //
		return equals;                                                                                                      //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Part of EJSON interface                                                                                           //
  * @see http://docs.meteor.com/api/ejson.html#EJSON-clone                                                            //
  * @returns {RangedQuestion} An independent deep copy of the current instance                                        //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	RangedQuestion.prototype.clone = function () {                                                                       // 7
		function clone() {                                                                                                  //
			return new RangedQuestion(this.serialize());                                                                       // 129
		}                                                                                                                   //
                                                                                                                      //
		return clone;                                                                                                       //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Part of EJSON interface.                                                                                          //
  * @see http://docs.meteor.com/api/ejson.html#EJSON-CustomType-typeName                                              //
  * @returns {String} The name of the instantiated class                                                              //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	RangedQuestion.prototype.typeName = function () {                                                                    // 7
		function typeName() {                                                                                               //
			return "RangedQuestion";                                                                                           // 138
		}                                                                                                                   //
                                                                                                                      //
		return typeName;                                                                                                    //
	}();                                                                                                                 //
                                                                                                                      //
	return RangedQuestion;                                                                                               //
}(_question_abstract.AbstractQuestion);                                                                               //
                                                                                                                      //
/**                                                                                                                   //
 * Adds a custom type to Meteor's EJSON                                                                               //
 * @see http://docs.meteor.com/api/ejson.html#EJSON-addType                                                           //
 */                                                                                                                   //
                                                                                                                      //
                                                                                                                      //
_ejson.EJSON.addType("RangedQuestion", function (value) {                                                             // 146
	return new RangedQuestion(value);                                                                                    // 147
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"question_reflection.js":["./question_choice_single.js","./question_choice_multiple.js","./question_ranged.js","./question_survey.js",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/questions/question_reflection.js                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
exports.questionReflection = undefined;                                                                               //
                                                                                                                      //
var _question_choice_single = require("./question_choice_single.js");                                                 // 2
                                                                                                                      //
var _question_choice_multiple = require("./question_choice_multiple.js");                                             // 3
                                                                                                                      //
var _question_ranged = require("./question_ranged.js");                                                               // 4
                                                                                                                      //
var _question_survey = require("./question_survey.js");                                                               // 5
                                                                                                                      //
var questionReflection = exports.questionReflection = {                                                               // 7
	SingleChoiceQuestion: function () {                                                                                  // 8
		function SingleChoiceQuestion(options) {                                                                            // 8
			return new _question_choice_single.SingleChoiceQuestion(options);                                                  // 9
		}                                                                                                                   //
                                                                                                                      //
		return SingleChoiceQuestion;                                                                                        //
	}(),                                                                                                                 //
	MultipleChoiceQuestion: function () {                                                                                // 11
		function MultipleChoiceQuestion(options) {                                                                          // 11
			return new _question_choice_multiple.MultipleChoiceQuestion(options);                                              // 12
		}                                                                                                                   //
                                                                                                                      //
		return MultipleChoiceQuestion;                                                                                      //
	}(),                                                                                                                 //
	SurveyQuestion: function () {                                                                                        // 14
		function SurveyQuestion(options) {                                                                                  // 14
			return new _question_survey.SurveyQuestion(options);                                                               // 15
		}                                                                                                                   //
                                                                                                                      //
		return SurveyQuestion;                                                                                              //
	}(),                                                                                                                 //
	RangedQuestion: function () {                                                                                        // 17
		function RangedQuestion(options) {                                                                                  // 17
			return new _question_ranged.RangedQuestion(options);                                                               // 18
		}                                                                                                                   //
                                                                                                                      //
		return RangedQuestion;                                                                                              //
	}()                                                                                                                  //
};                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"question_survey.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/ejson","./question_abstract.js",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/questions/question_survey.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
exports.SurveyQuestion = undefined;                                                                                   //
                                                                                                                      //
var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require('babel-runtime/helpers/possibleConstructorReturn');                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require('babel-runtime/helpers/inherits');                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
var _ejson = require('meteor/ejson');                                                                                 // 1
                                                                                                                      //
var _question_abstract = require('./question_abstract.js');                                                           // 2
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                     //
                                                                                                                      //
var SurveyQuestion = exports.SurveyQuestion = function (_AbstractQuestion) {                                          //
	(0, _inherits3['default'])(SurveyQuestion, _AbstractQuestion);                                                       //
                                                                                                                      //
                                                                                                                      //
	/**                                                                                                                  //
  * Constructs a RangedQuestion instance                                                                              //
  * @see AbstractQuestion.constructor()                                                                               //
  * @param options                                                                                                    //
  */                                                                                                                  //
                                                                                                                      //
	function SurveyQuestion(options) {                                                                                   // 11
		(0, _classCallCheck3['default'])(this, SurveyQuestion);                                                             //
                                                                                                                      //
		if (typeof options.type !== "undefined" && options.type !== "SurveyQuestion") {                                     // 12
			throw new TypeError("Invalid construction type while creating new SurveyQuestion");                                // 13
		}                                                                                                                   //
		return (0, _possibleConstructorReturn3['default'])(this, _AbstractQuestion.call(this, options));                    //
	}                                                                                                                    //
                                                                                                                      //
	/**                                                                                                                  //
  * Checks if the properties of this instance are valid. Checks also recursively all including AnswerOption instances
  * and summarizes their result of calling .isValid(). Checks if the Question has exactly zero correct AnswerOptions  //
  * @see AbstractQuestion.isValid()                                                                                   //
  * @returns {boolean} True, if the complete Question instance is valid, False otherwise                              //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	SurveyQuestion.prototype.isValid = function () {                                                                     // 4
		function isValid() {                                                                                                //
			var hasValidAnswer = 0;                                                                                            // 25
			this.getAnswerOptionList().forEach(function (answeroption) {                                                       // 26
				if (answeroption.getIsCorrect()) {                                                                                // 27
					hasValidAnswer++;                                                                                                // 28
				}                                                                                                                 //
			});                                                                                                                //
			return _AbstractQuestion.prototype.isValid.call(this) && hasValidAnswer === 0;                                     // 31
		}                                                                                                                   //
                                                                                                                      //
		return isValid;                                                                                                     //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Gets the validation error reason from the question and all included answerOptions as a stackable array            //
  * @returns {Array} Contains an Object which holds the number of the current question and the reason why the validation has failed
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	SurveyQuestion.prototype.getValidationStackTrace = function () {                                                     // 4
		function getValidationStackTrace() {                                                                                //
			var hasValidAnswer = 0;                                                                                            // 39
			this.getAnswerOptionList().forEach(function (answeroption) {                                                       // 40
				if (answeroption.getIsCorrect()) {                                                                                // 41
					hasValidAnswer++;                                                                                                // 42
				}                                                                                                                 //
			});                                                                                                                //
			var parentStackTrace = _AbstractQuestion.prototype.getValidationStackTrace.call(this);                             // 45
			if (hasValidAnswer !== 0) {                                                                                        // 46
				parentStackTrace.push({ occuredAt: { type: "question", id: this.getQuestionIndex() }, reason: "no_valid_answer_required" });
			}                                                                                                                  //
			return parentStackTrace;                                                                                           // 49
		}                                                                                                                   //
                                                                                                                      //
		return getValidationStackTrace;                                                                                     //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Part of EJSON interface                                                                                           //
  * @see http://docs.meteor.com/api/ejson.html#EJSON-clone                                                            //
  * @returns {SurveyQuestion} An independent deep copy of the current instance                                        //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	SurveyQuestion.prototype.clone = function () {                                                                       // 4
		function clone() {                                                                                                  //
			return new SurveyQuestion(this.serialize());                                                                       // 58
		}                                                                                                                   //
                                                                                                                      //
		return clone;                                                                                                       //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Serialize the instance object to a JSON compatible object                                                         //
  * @returns {{hashtag:String,questionText:String,type:AbstractQuestion,timer:Number,startTime:Number,questionIndex:Number,answerOptionList:Array}}
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	SurveyQuestion.prototype.serialize = function () {                                                                   // 4
		function serialize() {                                                                                              //
			return $.extend(_AbstractQuestion.prototype.serialize.call(this), { type: "SurveyQuestion" });                     // 66
		}                                                                                                                   //
                                                                                                                      //
		return serialize;                                                                                                   //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Part of EJSON interface.                                                                                          //
  * @see http://docs.meteor.com/api/ejson.html#EJSON-CustomType-typeName                                              //
  * @returns {String} The name of the instantiated class                                                              //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	SurveyQuestion.prototype.typeName = function () {                                                                    // 4
		function typeName() {                                                                                               //
			return "SurveyQuestion";                                                                                           // 75
		}                                                                                                                   //
                                                                                                                      //
		return typeName;                                                                                                    //
	}();                                                                                                                 //
                                                                                                                      //
	return SurveyQuestion;                                                                                               //
}(_question_abstract.AbstractQuestion);                                                                               //
                                                                                                                      //
/**                                                                                                                   //
 * Adds a custom type to Meteor's EJSON                                                                               //
 * @see http://docs.meteor.com/api/ejson.html#EJSON-addType                                                           //
 */                                                                                                                   //
                                                                                                                      //
                                                                                                                      //
_ejson.EJSON.addType("SurveyQuestion", function (value) {                                                             // 83
	return new SurveyQuestion(value);                                                                                    // 84
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"questiongroup_abstract.js":["babel-runtime/helpers/classCallCheck","./question_abstract.js","./question_reflection.js","./question_choice_single.js",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/questions/questiongroup_abstract.js                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
exports.AbstractQuestionGroup = undefined;                                                                            //
                                                                                                                      //
var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _question_abstract = require('./question_abstract.js');                                                           // 1
                                                                                                                      //
var _question_reflection = require('./question_reflection.js');                                                       // 2
                                                                                                                      //
var _question_choice_single = require('./question_choice_single.js');                                                 // 3
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                     //
                                                                                                                      //
var hashtag = Symbol("hashtag");                                                                                      // 5
var questionList = Symbol("questionList");                                                                            // 6
var theme = Symbol("theme");                                                                                          // 7
var musicVolume = Symbol("musicVolume");                                                                              // 8
var musicEnabled = Symbol("musicEnabled");                                                                            // 9
var musicTitle = Symbol("musicTitle");                                                                                // 10
                                                                                                                      //
var AbstractQuestionGroup = exports.AbstractQuestionGroup = function () {                                             //
                                                                                                                      //
	/**                                                                                                                  //
  * Constructor super method for creating a QuestionGroup instance                                                    //
  * This method cannot be invoked directly.                                                                           //
  * @param {{hashtag: String, questionList: Array, theme: String}} options An object containing the hashtag and an optional questionList
  * @throws {TypeError} If this method is invoked directly                                                            //
  * @throws {Error} If the hashtag of the options Object is missing                                                   //
  */                                                                                                                  //
                                                                                                                      //
	function AbstractQuestionGroup(options) {                                                                            // 21
		(0, _classCallCheck3['default'])(this, AbstractQuestionGroup);                                                      //
                                                                                                                      //
		if (this.constructor === AbstractQuestionGroup) {                                                                   // 22
			throw new TypeError("Cannot construct Abstract instances directly");                                               // 23
		}                                                                                                                   //
		if (typeof options.hashtag === "undefined") {                                                                       // 25
			throw new Error("Invalid argument list for " + this.constructor.name + " instantiation");                          // 26
		}                                                                                                                   //
		this[questionList] = [];                                                                                            // 28
		if (options.questionList instanceof Array) {                                                                        // 29
			for (var i = 0; i < options.questionList.length; i++) {                                                            // 30
				if (!(options.questionList[i] instanceof _question_abstract.AbstractQuestion)) {                                  // 31
					if (options.questionList[i] instanceof Object) {                                                                 // 32
						options.questionList[i] = _question_reflection.questionReflection[options.questionList[i].type](options.questionList[i]);
					} else {                                                                                                         //
						throw new Error("Invalid argument list for " + this.constructor.name + " instantiation");                       // 35
					}                                                                                                                //
				}                                                                                                                 //
				this[questionList].push(options.questionList[i]);                                                                 // 38
			}                                                                                                                  //
		}                                                                                                                   //
		this[hashtag] = options.hashtag;                                                                                    // 41
		this[theme] = options.theme || "theme-dark";                                                                        // 42
		this[musicVolume] = options.musicVolume || 80;                                                                      // 43
		this[musicEnabled] = options.musicEnabled || "1";                                                                   // 44
		this[musicTitle] = options.musicTitle || "Song1";                                                                   // 45
	}                                                                                                                    //
                                                                                                                      //
	/**                                                                                                                  //
  * Adds a question to the questionGroup instance                                                                     //
  * @param {SingleChoiceQuestion|MultipleChoiceQuestion|RangedQuestion|SurveyQuestion} question The question which extends {AbstractQuestion} to be added
  * @param {Number} [index] An optional index position where the item should be added                                 //
  * @returns {AbstractQuestion|Null} if successful returns the inserted Question otherwise Null                       //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestionGroup.prototype.addQuestion = function () {                                                          // 12
		function addQuestion(question, index) {                                                                             //
			if (question instanceof _question_abstract.AbstractQuestion) {                                                     // 55
				if (typeof index === "undefined" || index >= this.getQuestionList().length) {                                     // 56
					this[questionList].push(question);                                                                               // 57
				} else {                                                                                                          //
					this[questionList][index] = question;                                                                            // 59
				}                                                                                                                 //
				return question;                                                                                                  // 61
			}                                                                                                                  //
			return null;                                                                                                       // 63
		}                                                                                                                   //
                                                                                                                      //
		return addQuestion;                                                                                                 //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Removes a question by the specified index                                                                         //
  * @param {Number} index The index of the question to be removed                                                     //
  * @throws {Error} If the index is not passed, smaller than 0 or larger than the length of the questionList          //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestionGroup.prototype.removeQuestion = function () {                                                       // 12
		function removeQuestion(index) {                                                                                    //
			if (typeof index === "undefined" || index < 0 || index > this.getQuestionList().length) {                          // 72
				throw new Error("Invalid argument list for QuestionGroup.removeQuestion");                                        // 73
			}                                                                                                                  //
			this[questionList].splice(index, 1);                                                                               // 75
			for (var i = index; i < this.getQuestionList().length; i++) {                                                      // 76
				this.getQuestionList()[i].setQuestionIndex(i);                                                                    // 77
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return removeQuestion;                                                                                              //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Returns the Hashtag of the questionGroup instance                                                                 //
  * @returns {String} The hashtag identifying the session                                                             //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestionGroup.prototype.getHashtag = function () {                                                           // 12
		function getHashtag() {                                                                                             //
			return this[hashtag];                                                                                              // 86
		}                                                                                                                   //
                                                                                                                      //
		return getHashtag;                                                                                                  //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Returns the questionList of the questionGroup instance                                                            //
  * @returns {Array} The current list of questions                                                                    //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestionGroup.prototype.getQuestionList = function () {                                                      // 12
		function getQuestionList() {                                                                                        //
			return this[questionList];                                                                                         // 94
		}                                                                                                                   //
                                                                                                                      //
		return getQuestionList;                                                                                             //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Serialize the instance object to a JSON compatible object                                                         //
  * @returns {{hashtag: String, type: String, questionList: Array}}                                                   //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestionGroup.prototype.serialize = function () {                                                            // 12
		function serialize() {                                                                                              //
			var questionListSerialized = [];                                                                                   // 102
			this.getQuestionList().forEach(function (question) {                                                               // 103
				questionListSerialized.push(question.serialize());                                                                // 103
			});                                                                                                                //
			return {                                                                                                           // 104
				hashtag: this.getHashtag(),                                                                                       // 105
				questionList: questionListSerialized,                                                                             // 106
				theme: this.getTheme(),                                                                                           // 107
				musicVolume: this.getMusicVolume(),                                                                               // 108
				musicEnabled: this.getMusicEnabled(),                                                                             // 109
				musicTitle: this.getMusicTitle()                                                                                  // 110
			};                                                                                                                 //
		}                                                                                                                   //
                                                                                                                      //
		return serialize;                                                                                                   //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Checks if the properties of this instance are valid. Checks also recursively all including Question instances     //
  * and summarizes their result of calling .isValid()                                                                 //
  * @returns {boolean} True, if the complete QuestionGroup instance is valid, False otherwise                         //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestionGroup.prototype.isValid = function () {                                                              // 12
		function isValid() {                                                                                                //
			var questionListValid = true;                                                                                      // 120
			this.getQuestionList().forEach(function (question) {                                                               // 121
				if (questionListValid && !question.isValid()) {                                                                   // 122
					questionListValid = false;                                                                                       // 123
				}                                                                                                                 //
			});                                                                                                                //
			return questionListValid;                                                                                          // 126
		}                                                                                                                   //
                                                                                                                      //
		return isValid;                                                                                                     //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Checks for equivalence relations to another questionGroup instance. Also part of the EJSON interface              //
  * @see http://docs.meteor.com/api/ejson.html#EJSON-CustomType-equals                                                //
  * @param {AbstractQuestionGroup} questionGroup The questionGroup instance which should be checked                   //
  * @returns {boolean} True if both instances are completely equal, False otherwise                                   //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestionGroup.prototype.equals = function () {                                                               // 12
		function equals(questionGroup) {                                                                                    //
			if (questionGroup instanceof AbstractQuestionGroup) {                                                              // 136
				if (questionGroup.getHashtag() !== this.getHashtag()) {                                                           // 137
					return false;                                                                                                    // 138
				}                                                                                                                 //
				if (questionGroup.getTheme() !== this.getTheme()) {                                                               // 140
					return false;                                                                                                    // 141
				}                                                                                                                 //
				if (questionGroup.getQuestionList().length === this.getQuestionList().length) {                                   // 143
					var allQuestionsEqual = false;                                                                                   // 144
					for (var i = 0; i < this.getQuestionList().length; i++) {                                                        // 145
						if (this.getQuestionList()[i].equals(questionGroup.getQuestionList()[i])) {                                     // 146
							allQuestionsEqual = true;                                                                                      // 147
						}                                                                                                               //
					}                                                                                                                //
					return allQuestionsEqual;                                                                                        // 150
				}                                                                                                                 //
			}                                                                                                                  //
			return false;                                                                                                      // 153
		}                                                                                                                   //
                                                                                                                      //
		return equals;                                                                                                      //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Part of EJSON interface                                                                                           //
  * @see AbstractQuestionGroup.serialize()                                                                            //
  * @see http://docs.meteor.com/api/ejson.html#EJSON-CustomType-toJSONValue                                           //
  * @returns {{hashtag, type, questionList}|{hashtag: String, type: String, questionList: Array}}                     //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestionGroup.prototype.toJSONValue = function () {                                                          // 12
		function toJSONValue() {                                                                                            //
			return this.serialize();                                                                                           // 163
		}                                                                                                                   //
                                                                                                                      //
		return toJSONValue;                                                                                                 //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Quick way to insert a default question to the QuestionGroup instance.                                             //
  * @param {Number} [index] The index where the question should be inserted. If not passed, it will be added to the end of the questionList
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	AbstractQuestionGroup.prototype.addDefaultQuestion = function () {                                                   // 12
		function addDefaultQuestion(index) {                                                                                //
			if (typeof index === "undefined" || index >= this.getQuestionList().length) {                                      // 171
				index = this.getQuestionList().length;                                                                            // 172
			}                                                                                                                  //
			var questionItem = new _question_choice_single.SingleChoiceQuestion({                                              // 174
				hashtag: this.getHashtag(),                                                                                       // 175
				questionText: "",                                                                                                 // 176
				questionIndex: index,                                                                                             // 177
				timer: 0,                                                                                                         // 178
				startTime: 0,                                                                                                     // 179
				answerOptionList: []                                                                                              // 180
			});                                                                                                                //
			for (var i = 0; i < 4; i++) {                                                                                      // 182
				questionItem.addDefaultAnswerOption(i);                                                                           // 183
			}                                                                                                                  //
			this.addQuestion(questionItem, index);                                                                             // 185
		}                                                                                                                   //
                                                                                                                      //
		return addDefaultQuestion;                                                                                          //
	}();                                                                                                                 //
                                                                                                                      //
	AbstractQuestionGroup.prototype.getTheme = function () {                                                             // 12
		function getTheme() {                                                                                               //
			return this[theme];                                                                                                // 192
		}                                                                                                                   //
                                                                                                                      //
		return getTheme;                                                                                                    //
	}();                                                                                                                 //
                                                                                                                      //
	AbstractQuestionGroup.prototype.setTheme = function () {                                                             // 12
		function setTheme(newTheme) {                                                                                       //
			if (typeof newTheme !== "string") {                                                                                // 196
				throw new Error("Invalid argument list for QuestionGroup.setTheme");                                              // 197
			}                                                                                                                  //
			this[theme] = newTheme;                                                                                            // 199
		}                                                                                                                   //
                                                                                                                      //
		return setTheme;                                                                                                    //
	}();                                                                                                                 //
                                                                                                                      //
	AbstractQuestionGroup.prototype.getMusicVolume = function () {                                                       // 12
		function getMusicVolume() {                                                                                         //
			return this[musicVolume];                                                                                          // 203
		}                                                                                                                   //
                                                                                                                      //
		return getMusicVolume;                                                                                              //
	}();                                                                                                                 //
                                                                                                                      //
	AbstractQuestionGroup.prototype.setMusicVolume = function () {                                                       // 12
		function setMusicVolume(newMusicVolume) {                                                                           //
			if (typeof newMusicVolume !== "number") {                                                                          // 207
				throw new Error("Invalid argument list for QuestionGroup.setMusicVolume");                                        // 208
			}                                                                                                                  //
			this[musicVolume] = newMusicVolume;                                                                                // 210
		}                                                                                                                   //
                                                                                                                      //
		return setMusicVolume;                                                                                              //
	}();                                                                                                                 //
                                                                                                                      //
	AbstractQuestionGroup.prototype.getMusicEnabled = function () {                                                      // 12
		function getMusicEnabled() {                                                                                        //
			return this[musicEnabled];                                                                                         // 214
		}                                                                                                                   //
                                                                                                                      //
		return getMusicEnabled;                                                                                             //
	}();                                                                                                                 //
                                                                                                                      //
	AbstractQuestionGroup.prototype.setMusicEnabled = function () {                                                      // 12
		function setMusicEnabled(newMusicEnabled) {                                                                         //
			if (typeof newMusicEnabled !== "number") {                                                                         // 218
				throw new Error("Invalid argument list for QuestionGroup.setMusicEnabled");                                       // 219
			}                                                                                                                  //
			this[musicEnabled] = newMusicEnabled;                                                                              // 221
		}                                                                                                                   //
                                                                                                                      //
		return setMusicEnabled;                                                                                             //
	}();                                                                                                                 //
                                                                                                                      //
	AbstractQuestionGroup.prototype.getMusicTitle = function () {                                                        // 12
		function getMusicTitle() {                                                                                          //
			return this[musicTitle];                                                                                           // 225
		}                                                                                                                   //
                                                                                                                      //
		return getMusicTitle;                                                                                               //
	}();                                                                                                                 //
                                                                                                                      //
	AbstractQuestionGroup.prototype.setMusicTitle = function () {                                                        // 12
		function setMusicTitle(newMusicTitle) {                                                                             //
			if (typeof newMusicTitle !== "string") {                                                                           // 229
				throw new Error("Invalid argument list for QuestionGroup.setMusicTitle");                                         // 230
			}                                                                                                                  //
			this[musicTitle] = newMusicTitle;                                                                                  // 232
		}                                                                                                                   //
                                                                                                                      //
		return setMusicTitle;                                                                                               //
	}();                                                                                                                 //
                                                                                                                      //
	return AbstractQuestionGroup;                                                                                        //
}();                                                                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"questiongroup_default.js":["babel-runtime/helpers/classCallCheck","babel-runtime/helpers/possibleConstructorReturn","babel-runtime/helpers/inherits","meteor/ejson","./questiongroup_abstract.js",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/questions/questiongroup_default.js                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
exports.DefaultQuestionGroup = undefined;                                                                             //
                                                                                                                      //
var _classCallCheck2 = require('babel-runtime/helpers/classCallCheck');                                               //
                                                                                                                      //
var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);                                                      //
                                                                                                                      //
var _possibleConstructorReturn2 = require('babel-runtime/helpers/possibleConstructorReturn');                         //
                                                                                                                      //
var _possibleConstructorReturn3 = _interopRequireDefault(_possibleConstructorReturn2);                                //
                                                                                                                      //
var _inherits2 = require('babel-runtime/helpers/inherits');                                                           //
                                                                                                                      //
var _inherits3 = _interopRequireDefault(_inherits2);                                                                  //
                                                                                                                      //
var _ejson = require('meteor/ejson');                                                                                 // 1
                                                                                                                      //
var _questiongroup_abstract = require('./questiongroup_abstract.js');                                                 // 2
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }                     //
                                                                                                                      //
var DefaultQuestionGroup = exports.DefaultQuestionGroup = function (_AbstractQuestionGrou) {                          //
	(0, _inherits3['default'])(DefaultQuestionGroup, _AbstractQuestionGrou);                                             //
                                                                                                                      //
                                                                                                                      //
	/**                                                                                                                  //
  * Constructs a DefaultQuestionGroup instance                                                                        //
  * @see AbstractQuestionGroup.constructor()                                                                          //
  * @param options                                                                                                    //
  */                                                                                                                  //
                                                                                                                      //
	function DefaultQuestionGroup(options) {                                                                             // 11
		(0, _classCallCheck3['default'])(this, DefaultQuestionGroup);                                                       //
                                                                                                                      //
		if (typeof options.type !== "undefined" && options.type !== "DefaultQuestionGroup") {                               // 12
			throw new TypeError("Invalid construction type while creating new DefaultQuestionGroup: " + options.type);         // 13
		}                                                                                                                   //
		return (0, _possibleConstructorReturn3['default'])(this, _AbstractQuestionGrou.call(this, options));                //
	}                                                                                                                    //
                                                                                                                      //
	/**                                                                                                                  //
  * Part of EJSON interface                                                                                           //
  * @see http://docs.meteor.com/api/ejson.html#EJSON-clone                                                            //
  * @returns {DefaultQuestionGroup} An independent deep copy of the current instance                                  //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	DefaultQuestionGroup.prototype.clone = function () {                                                                 // 4
		function clone() {                                                                                                  //
			return new DefaultQuestionGroup(this.serialize());                                                                 // 24
		}                                                                                                                   //
                                                                                                                      //
		return clone;                                                                                                       //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Serialize the instance object to a JSON compatible object                                                         //
  * @returns {{hashtag: String, type: String, questionList: Array}}                                                   //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	DefaultQuestionGroup.prototype.serialize = function () {                                                             // 4
		function serialize() {                                                                                              //
			return $.extend(_AbstractQuestionGrou.prototype.serialize.call(this), { type: "DefaultQuestionGroup" });           // 32
		}                                                                                                                   //
                                                                                                                      //
		return serialize;                                                                                                   //
	}();                                                                                                                 //
                                                                                                                      //
	/**                                                                                                                  //
  * Part of EJSON interface.                                                                                          //
  * @see http://docs.meteor.com/api/ejson.html#EJSON-CustomType-typeName                                              //
  * @returns {String} The name of the instantiated class                                                              //
  */                                                                                                                  //
                                                                                                                      //
                                                                                                                      //
	DefaultQuestionGroup.prototype.typeName = function () {                                                              // 4
		function typeName() {                                                                                               //
			return "DefaultQuestionGroup";                                                                                     // 41
		}                                                                                                                   //
                                                                                                                      //
		return typeName;                                                                                                    //
	}();                                                                                                                 //
                                                                                                                      //
	return DefaultQuestionGroup;                                                                                         //
}(_questiongroup_abstract.AbstractQuestionGroup);                                                                     //
                                                                                                                      //
/**                                                                                                                   //
 * Adds a custom type to Meteor's EJSON                                                                               //
 * @see http://docs.meteor.com/api/ejson.html#EJSON-addType                                                           //
 */                                                                                                                   //
                                                                                                                      //
                                                                                                                      //
_ejson.EJSON.addType("DefaultQuestionGroup", function (value) {                                                       // 49
	return new DefaultQuestionGroup(value);                                                                              // 50
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"responses":{"collection.js":["meteor/mongo","meteor/aldeed:simple-schema","../hashtags/collection.js","../eventmanager/collection.js","../member_list/collection.js","../answeroptions/collection.js","/lib/local_storage.js",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/responses/collection.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
exports.responsesCollectionSchema = exports.responseTimeSchema = exports.ResponsesCollection = undefined;             //
                                                                                                                      //
var _mongo = require('meteor/mongo');                                                                                 // 18
                                                                                                                      //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                     // 19
                                                                                                                      //
var _collection = require('../hashtags/collection.js');                                                               // 20
                                                                                                                      //
var _collection2 = require('../eventmanager/collection.js');                                                          // 21
                                                                                                                      //
var _collection3 = require('../member_list/collection.js');                                                           // 22
                                                                                                                      //
var _collection4 = require('../answeroptions/collection.js');                                                         // 23
                                                                                                                      //
var _local_storage = require('/lib/local_storage.js');                                                                // 24
                                                                                                                      //
var localData = _interopRequireWildcard(_local_storage);                                                              //
                                                                                                                      //
function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in meteorBabelHelpers.sanitizeForInObject(obj)) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj['default'] = obj; return newObj; } }
                                                                                                                      //
var ResponsesCollection = exports.ResponsesCollection = new _mongo.Mongo.Collection("responses"); /*                  // 26
                                                                                                   * This file is part of ARSnova Click.
                                                                                                   * Copyright (C) 2016 The ARSnova Team
                                                                                                   *                  //
                                                                                                   * ARSnova Click is free software: you can redistribute it and/or modify
                                                                                                   * it under the terms of the GNU General Public License as published by
                                                                                                   * the Free Software Foundation, either version 3 of the License, or
                                                                                                   * (at your option) any later version.
                                                                                                   *                  //
                                                                                                   * ARSnova Click is distributed in the hope that it will be useful,
                                                                                                   * but WITHOUT ANY WARRANTY; without even the implied warranty of
                                                                                                   * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
                                                                                                   * GNU General Public License for more details.
                                                                                                   *                  //
                                                                                                   * You should have received a copy of the GNU General Public License
                                                                                                   * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/
                                                                                                                      //
var responseTimeSchema = exports.responseTimeSchema = {                                                               // 27
	type: Number,                                                                                                        // 28
	min: 0                                                                                                               // 29
};                                                                                                                    //
var responsesCollectionSchema = exports.responsesCollectionSchema = new _aldeedSimpleSchema.SimpleSchema({            // 31
	hashtag: {                                                                                                           // 32
		type: _collection.hashtagSchema                                                                                     // 33
	},                                                                                                                   //
	questionIndex: {                                                                                                     // 35
		type: _collection2.questionIndexSchema                                                                              // 36
	},                                                                                                                   //
	userNick: {                                                                                                          // 38
		type: _collection3.userNickSchema                                                                                   // 39
	},                                                                                                                   //
	answerOptionNumber: {                                                                                                // 41
		type: _collection4.answerOptionNumberSchema                                                                         // 42
	},                                                                                                                   //
	responseTime: {                                                                                                      // 44
		type: responseTimeSchema                                                                                            // 45
	}                                                                                                                    //
});                                                                                                                   //
                                                                                                                      //
ResponsesCollection.attachSchema(responsesCollectionSchema);                                                          // 49
                                                                                                                      //
ResponsesCollection.deny({                                                                                            // 51
	insert: function () {                                                                                                // 52
		function insert() {                                                                                                 // 52
			return true;                                                                                                       // 53
		}                                                                                                                   //
                                                                                                                      //
		return insert;                                                                                                      //
	}(),                                                                                                                 //
	update: function () {                                                                                                // 55
		function update() {                                                                                                 // 55
			return true;                                                                                                       // 56
		}                                                                                                                   //
                                                                                                                      //
		return update;                                                                                                      //
	}(),                                                                                                                 //
	remove: function () {                                                                                                // 58
		function remove() {                                                                                                 // 58
			return true;                                                                                                       // 59
		}                                                                                                                   //
                                                                                                                      //
		return remove;                                                                                                      //
	}()                                                                                                                  //
});                                                                                                                   //
                                                                                                                      //
ResponsesCollection.allow({                                                                                           // 63
	insert: function () {                                                                                                // 64
		function insert(userId, doc) {                                                                                      // 64
			var isOwner = localData.containsHashtag(doc.hashtag);                                                              // 65
			var isOwnNick = doc.userNick === localStorage.getItem(doc.hashtag + "nick");                                       // 66
			return isOwner || isOwnNick;                                                                                       // 67
		}                                                                                                                   //
                                                                                                                      //
		return insert;                                                                                                      //
	}(),                                                                                                                 //
	update: function () {                                                                                                // 69
		function update(userId, doc) {                                                                                      // 69
			return localData.containsHashtag(doc.hashtag);                                                                     // 70
		}                                                                                                                   //
                                                                                                                      //
		return update;                                                                                                      //
	}(),                                                                                                                 //
	remove: function () {                                                                                                // 72
		function remove(userId, doc) {                                                                                      // 72
			return localData.containsHashtag(doc.hashtag);                                                                     // 73
		}                                                                                                                   //
                                                                                                                      //
		return remove;                                                                                                      //
	}()                                                                                                                  //
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"local_storage.js":["babel-runtime/helpers/typeof","meteor/mongo","/lib/questions/questiongroup_abstract.js","/lib/questions/questiongroup_default.js","/lib/questions/question_abstract.js","/lib/answeroptions/answeroption_default.js","/lib/questions/question_choice_multiple.js",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/local_storage.js                                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
                                                                                                                      //
var _typeof2 = require("babel-runtime/helpers/typeof");                                                               //
                                                                                                                      //
var _typeof3 = _interopRequireDefault(_typeof2);                                                                      //
                                                                                                                      //
exports.getLanguage = getLanguage;                                                                                    //
exports.getAllHashtags = getAllHashtags;                                                                              //
exports.containsHashtag = containsHashtag;                                                                            //
exports.deleteHashtag = deleteHashtag;                                                                                //
exports.addHashtag = addHashtag;                                                                                      //
exports.addQuestion = addQuestion;                                                                                    //
exports.removeQuestion = removeQuestion;                                                                              //
exports.addTimer = addTimer;                                                                                          //
exports.addAnswers = addAnswers;                                                                                      //
exports.reenterSession = reenterSession;                                                                              //
exports.deleteAnswerOption = deleteAnswerOption;                                                                      //
exports.updateAnswerText = updateAnswerText;                                                                          //
exports.initializePrivateKey = initializePrivateKey;                                                                  //
exports.getPrivateKey = getPrivateKey;                                                                                //
exports.importFromFile = importFromFile;                                                                              //
exports.exportFromLocalStorage = exportFromLocalStorage;                                                              //
                                                                                                                      //
var _mongo = require("meteor/mongo");                                                                                 // 18
                                                                                                                      //
var _questiongroup_abstract = require("/lib/questions/questiongroup_abstract.js");                                    // 19
                                                                                                                      //
var _questiongroup_default = require("/lib/questions/questiongroup_default.js");                                      // 20
                                                                                                                      //
var _question_abstract = require("/lib/questions/question_abstract.js");                                              // 21
                                                                                                                      //
var _answeroption_default = require("/lib/answeroptions/answeroption_default.js");                                    // 22
                                                                                                                      //
var _question_choice_multiple = require("/lib/questions/question_choice_multiple.js");                                // 23
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                     //
                                                                                                                      //
/*                                                                                                                    //
 * This file is part of ARSnova Click.                                                                                //
 * Copyright (C) 2016 The ARSnova Team                                                                                //
 *                                                                                                                    //
 * ARSnova Click is free software: you can redistribute it and/or modify                                              //
 * it under the terms of the GNU General Public License as published by                                               //
 * the Free Software Foundation, either version 3 of the License, or                                                  //
 * (at your option) any later version.                                                                                //
 *                                                                                                                    //
 * ARSnova Click is distributed in the hope that it will be useful,                                                   //
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                     //
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                      //
 * GNU General Public License for more details.                                                                       //
 *                                                                                                                    //
 * You should have received a copy of the GNU General Public License                                                  //
 * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                           //
                                                                                                                      //
function getLanguage() {                                                                                              // 25
	return $.parseJSON(localStorage.getItem("__amplify__tap-i18n-language"));                                            // 26
}                                                                                                                     //
                                                                                                                      //
function getAllHashtags() {                                                                                           // 29
	var hashtagString = localStorage.getItem("hashtags");                                                                // 30
	if (!hashtagString) {                                                                                                // 31
		localStorage.setItem("hashtags", JSON.stringify([]));                                                               // 32
		return [];                                                                                                          // 33
	}                                                                                                                    //
	return JSON.parse(hashtagString).sort();                                                                             // 35
}                                                                                                                     //
                                                                                                                      //
function containsHashtag(hashtag) {                                                                                   // 38
	if (!hashtag || hashtag === "hashtags" || hashtag === "privateKey") {                                                // 39
		return;                                                                                                             // 40
	}                                                                                                                    //
	var hashtagString = localStorage.getItem("hashtags");                                                                // 42
	return hashtagString ? $.inArray(hashtag, JSON.parse(hashtagString)) > -1 : false;                                   // 43
}                                                                                                                     //
                                                                                                                      //
function deleteHashtag(hashtag) {                                                                                     // 46
	if (!hashtag || hashtag === "hashtags" || hashtag === "privateKey") {                                                // 47
		return;                                                                                                             // 48
	}                                                                                                                    //
	var allHashtags = JSON.parse(localStorage.getItem("hashtags"));                                                      // 50
	if (!allHashtags) {                                                                                                  // 51
		return false;                                                                                                       // 52
	}                                                                                                                    //
	var index = $.inArray(hashtag, allHashtags);                                                                         // 54
	if (index > -1) {                                                                                                    // 55
		localStorage.removeItem(hashtag);                                                                                   // 56
		allHashtags.splice(index, 1);                                                                                       // 57
		localStorage.setItem("hashtags", JSON.stringify(allHashtags));                                                      // 58
	}                                                                                                                    //
}                                                                                                                     //
                                                                                                                      //
function addHashtag(questionGroup) {                                                                                  // 62
	if (!(questionGroup instanceof _questiongroup_abstract.AbstractQuestionGroup)) {                                     // 63
		return;                                                                                                             // 64
	}                                                                                                                    //
	var hashtagString = localStorage.getItem("hashtags");                                                                // 66
	if (!hashtagString) {                                                                                                // 67
		localStorage.setItem("hashtags", JSON.stringify([questionGroup.getHashtag()]));                                     // 68
		localStorage.setItem(questionGroup.getHashtag(), JSON.stringify(questionGroup.serialize()));                        // 69
	} else {                                                                                                             //
		var hashtags = JSON.parse(hashtagString);                                                                           // 71
		if (!containsHashtag(questionGroup.getHashtag())) {                                                                 // 72
			hashtags.push(questionGroup.getHashtag());                                                                         // 73
			localStorage.setItem("hashtags", JSON.stringify(hashtags));                                                        // 74
		}                                                                                                                   //
		localStorage.setItem(questionGroup.getHashtag(), JSON.stringify(questionGroup.serialize()));                        // 76
	}                                                                                                                    //
}                                                                                                                     //
                                                                                                                      //
function addQuestion(questionItem) {                                                                                  // 80
	if (!(questionItem instanceof _question_abstract.AbstractQuestion)) {                                                // 81
		return;                                                                                                             // 82
	}                                                                                                                    //
	var sessionDataString = localStorage.getItem(questionItem.getHashtag());                                             // 84
	if (sessionDataString) {                                                                                             // 85
		var sessionData = JSON.parse(sessionDataString);                                                                    // 86
		if (questionItem.getQuestionIndex() < sessionData.questionList.length) {                                            // 87
			sessionData.questionList[questionItem.getQuestionIndex()].questionText = questionItem.getQuestionText();           // 88
		} else {                                                                                                            //
			sessionData.questionList.push(questionItem.serialize());                                                           // 90
		}                                                                                                                   //
		localStorage.setItem(questionItem.getHashtag(), JSON.stringify(sessionData));                                       // 92
	}                                                                                                                    //
}                                                                                                                     //
                                                                                                                      //
function removeQuestion(hashtag, questionIndex) {                                                                     // 96
	if (!hashtag || hashtag === "hashtags" || hashtag === "privateKey") {                                                // 97
		return;                                                                                                             // 98
	}                                                                                                                    //
	var sessionDataString = localStorage.getItem(hashtag);                                                               // 100
	if (sessionDataString) {                                                                                             // 101
		var sessionData = JSON.parse(sessionDataString);                                                                    // 102
		sessionData.questionList.splice(questionIndex, 1);                                                                  // 103
		localStorage.setItem(hashtag, JSON.stringify(sessionData));                                                         // 104
	}                                                                                                                    //
}                                                                                                                     //
                                                                                                                      //
function addTimer(hashtag, questionIndex, timer) {                                                                    // 108
	if (!hashtag || hashtag === "hashtags" || hashtag === "privateKey") {                                                // 109
		return;                                                                                                             // 110
	}                                                                                                                    //
	var sessionDataString = localStorage.getItem(hashtag);                                                               // 112
	if (sessionDataString) {                                                                                             // 113
		var sessionData = JSON.parse(sessionDataString);                                                                    // 114
		sessionData.questionList[questionIndex].timer = timer;                                                              // 115
		localStorage.setItem(hashtag, JSON.stringify(sessionData));                                                         // 116
	}                                                                                                                    //
}                                                                                                                     //
                                                                                                                      //
function addAnswers(_ref) {                                                                                           // 120
	var hashtag = _ref.hashtag;                                                                                          //
	var questionIndex = _ref.questionIndex;                                                                              //
	var answerOptionNumber = _ref.answerOptionNumber;                                                                    //
	var answerText = _ref.answerText;                                                                                    //
	var isCorrect = _ref.isCorrect;                                                                                      //
                                                                                                                      //
	if (!hashtag || hashtag === "hashtags" || hashtag === "privateKey") {                                                // 121
		return;                                                                                                             // 122
	}                                                                                                                    //
	var sessionDataString = localStorage.getItem(hashtag);                                                               // 124
	if (sessionDataString) {                                                                                             // 125
		var sessionData = JSON.parse(sessionDataString);                                                                    // 126
		if (!sessionData.questionList[questionIndex].answers) {                                                             // 127
			sessionData.questionList[questionIndex].answers = [];                                                              // 128
		}                                                                                                                   //
		sessionData.questionList[questionIndex].answers.push({                                                              // 130
			answerOptionNumber: answerOptionNumber,                                                                            // 131
			answerText: answerText,                                                                                            // 132
			isCorrect: isCorrect                                                                                               // 133
		});                                                                                                                 //
		localStorage.setItem(hashtag, JSON.stringify(sessionData));                                                         // 135
	}                                                                                                                    //
}                                                                                                                     //
                                                                                                                      //
function reenterSession(hashtag) {                                                                                    // 139
	if (!hashtag || hashtag === "hashtags" || hashtag === "privateKey") {                                                // 140
		throw new TypeError("Undefined or illegal hashtag provided");                                                       // 141
	}                                                                                                                    //
                                                                                                                      //
	var sessionDataString = localStorage.getItem(hashtag);                                                               // 144
	if (!sessionDataString) {                                                                                            // 145
		throw new TypeError("Undefined session data");                                                                      // 146
	}                                                                                                                    //
                                                                                                                      //
	var sessionData = JSON.parse(sessionDataString);                                                                     // 149
	if ((typeof sessionData === "undefined" ? "undefined" : (0, _typeof3["default"])(sessionData)) !== "object") {       // 150
		throw new TypeError("Illegal session data");                                                                        // 151
	}                                                                                                                    //
	if (typeof sessionData.type === "undefined") {                                                                       // 153
		// Legacy mode -> Convert old session data to new OO style                                                          //
		var newQuestionGroup = new _questiongroup_default.DefaultQuestionGroup({                                            // 155
			hashtag: hashtag,                                                                                                  // 156
			questionList: [],                                                                                                  // 157
			musicEnabled: 1,                                                                                                   // 158
			musicVolume: 80,                                                                                                   // 159
			musicTitle: "Song1"                                                                                                // 160
		});                                                                                                                 //
		for (var i = 0; i < sessionData.questionList.length; i++) {                                                         // 162
			var answerOptions = [];                                                                                            // 163
			for (var j = 0; j < sessionData.questionList[i].answers.length; j++) {                                             // 164
				answerOptions.push(new _answeroption_default.DefaultAnswerOption({                                                // 165
					hashtag: hashtag,                                                                                                // 166
					questionIndex: i,                                                                                                // 167
					answerOptionNumber: j,                                                                                           // 168
					answerText: sessionData.questionList[i].answers[j].answerText,                                                   // 169
					isCorrect: sessionData.questionList[i].answers[j].isCorrect === 1                                                // 170
				}));                                                                                                              //
			}                                                                                                                  //
			newQuestionGroup.addQuestion(new _question_choice_multiple.MultipleChoiceQuestion({                                // 173
				hashtag: hashtag,                                                                                                 // 174
				questionIndex: i,                                                                                                 // 175
				questionText: sessionData.questionList[i].questionText,                                                           // 176
				timer: sessionData.questionList[i].timer / 1000,                                                                  // 177
				startTime: 0,                                                                                                     // 178
				answerOptionList: answerOptions                                                                                   // 179
			}));                                                                                                               //
		}                                                                                                                   //
		localStorage.setItem(newQuestionGroup.getHashtag(), JSON.stringify(newQuestionGroup.serialize()));                  // 182
		sessionData = newQuestionGroup.serialize();                                                                         // 183
	}                                                                                                                    //
                                                                                                                      //
	switch (sessionData.type) {                                                                                          // 186
		case "DefaultQuestionGroup":                                                                                        // 187
			return new _questiongroup_default.DefaultQuestionGroup(sessionData);                                               // 188
		default:                                                                                                            // 186
			throw new TypeError("Undefined session type while reentering");                                                    // 190
	}                                                                                                                    // 186
}                                                                                                                     //
                                                                                                                      //
function deleteAnswerOption(hashtag, questionIndex, answerOptionNumber) {                                             // 194
	if (!hashtag || hashtag === "hashtags" || hashtag === "privateKey") {                                                // 195
		return;                                                                                                             // 196
	}                                                                                                                    //
	var sessionDataString = localStorage.getItem(hashtag);                                                               // 198
	if (!sessionDataString) {                                                                                            // 199
		return;                                                                                                             // 200
	}                                                                                                                    //
                                                                                                                      //
	var sessionData = JSON.parse(sessionDataString);                                                                     // 203
	if ((typeof sessionData === "undefined" ? "undefined" : (0, _typeof3["default"])(sessionData)) === "object") {       // 204
		sessionData.questionList[questionIndex].answers = $.grep(sessionData.questionList[questionIndex].answers, function (value) {
			return value.answerOptionNumber !== answerOptionNumber;                                                            // 206
		});                                                                                                                 //
                                                                                                                      //
		localStorage.setItem(hashtag, JSON.stringify(sessionData));                                                         // 209
	}                                                                                                                    //
}                                                                                                                     //
                                                                                                                      //
function updateAnswerText(_ref2) {                                                                                    // 213
	var hashtag = _ref2.hashtag;                                                                                         //
	var questionIndex = _ref2.questionIndex;                                                                             //
	var answerOptionNumber = _ref2.answerOptionNumber;                                                                   //
	var answerText = _ref2.answerText;                                                                                   //
	var isCorrect = _ref2.isCorrect;                                                                                     //
                                                                                                                      //
	if (!hashtag || hashtag === "hashtags" || hashtag === "privateKey") {                                                // 214
		return;                                                                                                             // 215
	}                                                                                                                    //
	var sessionDataString = localStorage.getItem(hashtag);                                                               // 217
	if (!sessionDataString) {                                                                                            // 218
		return;                                                                                                             // 219
	}                                                                                                                    //
                                                                                                                      //
	var sessionData = JSON.parse(sessionDataString);                                                                     // 222
	if ((typeof sessionData === "undefined" ? "undefined" : (0, _typeof3["default"])(sessionData)) === "object") {       // 223
		$.each(sessionData.questionList[questionIndex].answers, function (key, value) {                                     // 224
			if (value.answerOptionNumber === answerOptionNumber) {                                                             // 225
				value.answerText = answerText;                                                                                    // 226
				value.isCorrect = isCorrect;                                                                                      // 227
			}                                                                                                                  //
		});                                                                                                                 //
		localStorage.setItem(hashtag, JSON.stringify(sessionData));                                                         // 230
	}                                                                                                                    //
}                                                                                                                     //
                                                                                                                      //
function initializePrivateKey() {                                                                                     // 234
	if (!localStorage.getItem("privateKey")) {                                                                           // 235
		localStorage.setItem("privateKey", new _mongo.Mongo.ObjectID()._str);                                               // 236
	}                                                                                                                    //
}                                                                                                                     //
                                                                                                                      //
function getPrivateKey() {                                                                                            // 240
	return localStorage.getItem("privateKey");                                                                           // 241
}                                                                                                                     //
                                                                                                                      //
function importFromFile(data) {                                                                                       // 244
	var hashtag = data.hashtag;                                                                                          // 245
	if (hashtag === "hashtags" || hashtag === "privateKey") {                                                            // 246
		return;                                                                                                             // 247
	}                                                                                                                    //
                                                                                                                      //
	var allHashtags = JSON.parse(localStorage.getItem("hashtags"));                                                      // 250
	allHashtags = $.grep(allHashtags, function (value) {                                                                 // 251
		return value !== data.hashtag;                                                                                      // 252
	});                                                                                                                  //
	allHashtags.push(hashtag);                                                                                           // 254
	localStorage.setItem("hashtags", JSON.stringify(allHashtags));                                                       // 255
                                                                                                                      //
	switch (data.type) {                                                                                                 // 257
		case "DefaultQuestionGroup":                                                                                        // 258
			var instance = new _questiongroup_default.DefaultQuestionGroup(data);                                              // 259
			localStorage.setItem(instance.getHashtag(), JSON.stringify(instance.serialize()));                                 // 260
			break;                                                                                                             // 261
		default:                                                                                                            // 257
			throw new TypeError("Undefined session type '" + data.type + "' while importing");                                 // 263
	}                                                                                                                    // 257
}                                                                                                                     //
                                                                                                                      //
function exportFromLocalStorage(hashtag) {                                                                            // 267
	var localStorageData = JSON.parse(localStorage.getItem(hashtag));                                                    // 268
	if (!localStorageData) {                                                                                             // 269
		throw new TypeError("Invalid local storage data while exporting");                                                  // 270
	}                                                                                                                    //
	var quizItem = null;                                                                                                 // 272
	switch (localStorageData.type) {                                                                                     // 273
		case "DefaultQuestionGroup":                                                                                        // 274
			quizItem = new _questiongroup_default.DefaultQuestionGroup(localStorageData);                                      // 275
			break;                                                                                                             // 276
		default:                                                                                                            // 273
			throw new TypeError("Undefined session type while exporting");                                                     // 278
	}                                                                                                                    // 273
	if (!quizItem.theme) {                                                                                               // 280
		quizItem.theme = "theme-dark";                                                                                      // 281
	}                                                                                                                    //
	if (!quizItem.musicVolume) {                                                                                         // 283
		quizItem.musicVolume = 80;                                                                                          // 284
	}                                                                                                                    //
	if (!quizItem.musicEnabled) {                                                                                        // 286
		quizItem.musicEnabled = 1;                                                                                          // 287
	}                                                                                                                    //
	if (!quizItem.musicTitle) {                                                                                          // 289
		quizItem.musicTitle = "Song1";                                                                                      // 290
	}                                                                                                                    //
	return JSON.stringify(quizItem.serialize());                                                                         // 292
}                                                                                                                     //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"server":{"publications":{"answeroptions.js":["meteor/meteor","meteor/aldeed:simple-schema","/lib/answeroptions/collection.js",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/publications/answeroptions.js                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _meteor = require('meteor/meteor');                                                                               // 18
                                                                                                                      //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                     // 19
                                                                                                                      //
var _collection = require('/lib/answeroptions/collection.js');                                                        // 20
                                                                                                                      //
_meteor.Meteor.publish('AnswerOptionCollection.join', function (hashtag) {                                            // 22
  new _aldeedSimpleSchema.SimpleSchema({                                                                              // 23
    hashtag: { type: String }                                                                                         // 24
  }).validate({ hashtag: hashtag });                                                                                  //
  return _collection.AnswerOptionCollection.find({ hashtag: hashtag });                                               // 26
}); /*                                                                                                                //
     * This file is part of ARSnova Click.                                                                            //
     * Copyright (C) 2016 The ARSnova Team                                                                            //
     *                                                                                                                //
     * ARSnova Click is free software: you can redistribute it and/or modify                                          //
     * it under the terms of the GNU General Public License as published by                                           //
     * the Free Software Foundation, either version 3 of the License, or                                              //
     * (at your option) any later version.                                                                            //
     *                                                                                                                //
     * ARSnova Click is distributed in the hope that it will be useful,                                               //
     * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                 //
     * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                  //
     * GNU General Public License for more details.                                                                   //
     *                                                                                                                //
     * You should have received a copy of the GNU General Public License                                              //
     * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                       //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"banned_nicks.js":["meteor/meteor","/lib/banned_nicks/collection.js",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/publications/banned_nicks.js                                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _meteor = require('meteor/meteor');                                                                               // 18
                                                                                                                      //
var _collection = require('/lib/banned_nicks/collection.js');                                                         // 19
                                                                                                                      //
/*                                                                                                                    //
 * This file is part of ARSnova Click.                                                                                //
 * Copyright (C) 2016 The ARSnova Team                                                                                //
 *                                                                                                                    //
 * ARSnova Click is free software: you can redistribute it and/or modify                                              //
 * it under the terms of the GNU General Public License as published by                                               //
 * the Free Software Foundation, either version 3 of the License, or                                                  //
 * (at your option) any later version.                                                                                //
 *                                                                                                                    //
 * ARSnova Click is distributed in the hope that it will be useful,                                                   //
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                     //
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                      //
 * GNU General Public License for more details.                                                                       //
 *                                                                                                                    //
 * You should have received a copy of the GNU General Public License                                                  //
 * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                           //
                                                                                                                      //
_meteor.Meteor.publish('BannedNicksCollection.public', function () {                                                  // 21
  return _collection.BannedNicksCollection.find();                                                                    // 22
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"eventmanager.js":["meteor/meteor","meteor/aldeed:simple-schema","/lib/eventmanager/collection.js",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/publications/eventmanager.js                                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _meteor = require('meteor/meteor');                                                                               // 18
                                                                                                                      //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                     // 19
                                                                                                                      //
var _collection = require('/lib/eventmanager/collection.js');                                                         // 20
                                                                                                                      //
_meteor.Meteor.publish('EventManagerCollection.join', function (hashtag) {                                            // 22
  new _aldeedSimpleSchema.SimpleSchema({                                                                              // 23
    hashtag: { type: String }                                                                                         // 24
  }).validate({ hashtag: hashtag });                                                                                  //
  return _collection.EventManagerCollection.find({ hashtag: hashtag });                                               // 26
}); /*                                                                                                                //
     * This file is part of ARSnova Click.                                                                            //
     * Copyright (C) 2016 The ARSnova Team                                                                            //
     *                                                                                                                //
     * ARSnova Click is free software: you can redistribute it and/or modify                                          //
     * it under the terms of the GNU General Public License as published by                                           //
     * the Free Software Foundation, either version 3 of the License, or                                              //
     * (at your option) any later version.                                                                            //
     *                                                                                                                //
     * ARSnova Click is distributed in the hope that it will be useful,                                               //
     * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                 //
     * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                  //
     * GNU General Public License for more details.                                                                   //
     *                                                                                                                //
     * You should have received a copy of the GNU General Public License                                              //
     * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                       //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"hashtags.js":["meteor/meteor","/lib/hashtags/collection.js",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/publications/hashtags.js                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _meteor = require('meteor/meteor');                                                                               // 18
                                                                                                                      //
var _collection = require('/lib/hashtags/collection.js');                                                             // 19
                                                                                                                      //
/*                                                                                                                    //
 * This file is part of ARSnova Click.                                                                                //
 * Copyright (C) 2016 The ARSnova Team                                                                                //
 *                                                                                                                    //
 * ARSnova Click is free software: you can redistribute it and/or modify                                              //
 * it under the terms of the GNU General Public License as published by                                               //
 * the Free Software Foundation, either version 3 of the License, or                                                  //
 * (at your option) any later version.                                                                                //
 *                                                                                                                    //
 * ARSnova Click is distributed in the hope that it will be useful,                                                   //
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                     //
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                      //
 * GNU General Public License for more details.                                                                       //
 *                                                                                                                    //
 * You should have received a copy of the GNU General Public License                                                  //
 * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                           //
                                                                                                                      //
_meteor.Meteor.publish('HashtagsCollection.public', function () {                                                     // 21
  return _collection.HashtagsCollection.find({}, {                                                                    // 22
    fields: {                                                                                                         // 23
      privateKey: 0                                                                                                   // 24
    }                                                                                                                 //
  });                                                                                                                 //
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"leaderBoard.js":["meteor/meteor","meteor/aldeed:simple-schema","/lib/leader_board/collection.js",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/publications/leaderBoard.js                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _meteor = require('meteor/meteor');                                                                               // 18
                                                                                                                      //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                     // 19
                                                                                                                      //
var _collection = require('/lib/leader_board/collection.js');                                                         // 20
                                                                                                                      //
_meteor.Meteor.publish('LeaderBoardCollection.join', function (hashtag) {                                             // 22
  new _aldeedSimpleSchema.SimpleSchema({                                                                              // 23
    hashtag: { type: String }                                                                                         // 24
  }).validate({ hashtag: hashtag });                                                                                  //
  return _collection.LeaderBoardCollection.find({ hashtag: hashtag });                                                // 26
}); /*                                                                                                                //
     * This file is part of ARSnova Click.                                                                            //
     * Copyright (C) 2016 The ARSnova Team                                                                            //
     *                                                                                                                //
     * ARSnova Click is free software: you can redistribute it and/or modify                                          //
     * it under the terms of the GNU General Public License as published by                                           //
     * the Free Software Foundation, either version 3 of the License, or                                              //
     * (at your option) any later version.                                                                            //
     *                                                                                                                //
     * ARSnova Click is distributed in the hope that it will be useful,                                               //
     * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                 //
     * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                  //
     * GNU General Public License for more details.                                                                   //
     *                                                                                                                //
     * You should have received a copy of the GNU General Public License                                              //
     * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                       //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"memberlist.js":["meteor/meteor","meteor/aldeed:simple-schema","/lib/member_list/collection.js",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/publications/memberlist.js                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _meteor = require('meteor/meteor');                                                                               // 18
                                                                                                                      //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                     // 19
                                                                                                                      //
var _collection = require('/lib/member_list/collection.js');                                                          // 20
                                                                                                                      //
_meteor.Meteor.publish('MemberListCollection.join', function (hashtag) {                                              // 22
  new _aldeedSimpleSchema.SimpleSchema({                                                                              // 23
    hashtag: { type: String }                                                                                         // 24
  }).validate({ hashtag: hashtag });                                                                                  //
  return _collection.MemberListCollection.find({ hashtag: hashtag });                                                 // 26
}); /*                                                                                                                //
     * This file is part of ARSnova Click.                                                                            //
     * Copyright (C) 2016 The ARSnova Team                                                                            //
     *                                                                                                                //
     * ARSnova Click is free software: you can redistribute it and/or modify                                          //
     * it under the terms of the GNU General Public License as published by                                           //
     * the Free Software Foundation, either version 3 of the License, or                                              //
     * (at your option) any later version.                                                                            //
     *                                                                                                                //
     * ARSnova Click is distributed in the hope that it will be useful,                                               //
     * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                 //
     * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                  //
     * GNU General Public License for more details.                                                                   //
     *                                                                                                                //
     * You should have received a copy of the GNU General Public License                                              //
     * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                       //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"questions.js":["meteor/meteor","meteor/aldeed:simple-schema","/lib/questions/collection.js",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/publications/questions.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _meteor = require('meteor/meteor');                                                                               // 18
                                                                                                                      //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                     // 19
                                                                                                                      //
var _collection = require('/lib/questions/collection.js');                                                            // 20
                                                                                                                      //
_meteor.Meteor.publish('QuestionGroupCollection.join', function (hashtag) {                                           // 22
  new _aldeedSimpleSchema.SimpleSchema({                                                                              // 23
    hashtag: { type: String }                                                                                         // 24
  }).validate({ hashtag: hashtag });                                                                                  //
  return _collection.QuestionGroupCollection.find({ hashtag: hashtag });                                              // 26
}); /*                                                                                                                //
     * This file is part of ARSnova Click.                                                                            //
     * Copyright (C) 2016 The ARSnova Team                                                                            //
     *                                                                                                                //
     * ARSnova Click is free software: you can redistribute it and/or modify                                          //
     * it under the terms of the GNU General Public License as published by                                           //
     * the Free Software Foundation, either version 3 of the License, or                                              //
     * (at your option) any later version.                                                                            //
     *                                                                                                                //
     * ARSnova Click is distributed in the hope that it will be useful,                                               //
     * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                 //
     * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                  //
     * GNU General Public License for more details.                                                                   //
     *                                                                                                                //
     * You should have received a copy of the GNU General Public License                                              //
     * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                       //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"responses.js":["meteor/meteor","meteor/aldeed:simple-schema","/lib/responses/collection.js",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/publications/responses.js                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _meteor = require('meteor/meteor');                                                                               // 18
                                                                                                                      //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                     // 19
                                                                                                                      //
var _collection = require('/lib/responses/collection.js');                                                            // 20
                                                                                                                      //
_meteor.Meteor.publish('ResponsesCollection.join', function (hashtag) {                                               // 22
  new _aldeedSimpleSchema.SimpleSchema({                                                                              // 23
    hashtag: { type: String }                                                                                         // 24
  }).validate({ hashtag: hashtag });                                                                                  //
  return _collection.ResponsesCollection.find({ hashtag: hashtag });                                                  // 26
}); /*                                                                                                                //
     * This file is part of ARSnova Click.                                                                            //
     * Copyright (C) 2016 The ARSnova Team                                                                            //
     *                                                                                                                //
     * ARSnova Click is free software: you can redistribute it and/or modify                                          //
     * it under the terms of the GNU General Public License as published by                                           //
     * the Free Software Foundation, either version 3 of the License, or                                              //
     * (at your option) any later version.                                                                            //
     *                                                                                                                //
     * ARSnova Click is distributed in the hope that it will be useful,                                               //
     * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                 //
     * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                  //
     * GNU General Public License for more details.                                                                   //
     *                                                                                                                //
     * You should have received a copy of the GNU General Public License                                              //
     * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                       //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"connection.js":["meteor/meteor","/lib/eventmanager/collection.js","/lib/answeroptions/collection.js","/lib/member_list/collection.js","/lib/responses/collection.js","/lib/questions/collection.js",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/connection.js                                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _meteor = require('meteor/meteor');                                                                               // 18
                                                                                                                      //
var _collection = require('/lib/eventmanager/collection.js');                                                         // 19
                                                                                                                      //
var _collection2 = require('/lib/answeroptions/collection.js');                                                       // 20
                                                                                                                      //
var _collection3 = require('/lib/member_list/collection.js');                                                         // 21
                                                                                                                      //
var _collection4 = require('/lib/responses/collection.js');                                                           // 22
                                                                                                                      //
var _collection5 = require('/lib/questions/collection.js');                                                           // 23
                                                                                                                      //
/*                                                                                                                    //
 * This file is part of ARSnova Click.                                                                                //
 * Copyright (C) 2016 The ARSnova Team                                                                                //
 *                                                                                                                    //
 * ARSnova Click is free software: you can redistribute it and/or modify                                              //
 * it under the terms of the GNU General Public License as published by                                               //
 * the Free Software Foundation, either version 3 of the License, or                                                  //
 * (at your option) any later version.                                                                                //
 *                                                                                                                    //
 * ARSnova Click is distributed in the hope that it will be useful,                                                   //
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                     //
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                      //
 * GNU General Public License for more details.                                                                       //
 *                                                                                                                    //
 * You should have received a copy of the GNU General Public License                                                  //
 * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                           //
                                                                                                                      //
_meteor.Meteor.setInterval(function () {                                                                              // 25
  var sessionDeleteAfterIdleMinutes = 10; //Minutes to session is idle                                                // 26
  var now = new Date().getTime();                                                                                     // 25
  var sessionDeleteTimeInMilliseconds = sessionDeleteAfterIdleMinutes * 60 * 1000;                                    // 28
  _collection.EventManagerCollection.find({                                                                           // 29
    lastConnection: { $lt: now - sessionDeleteTimeInMilliseconds },                                                   // 30
    sessionStatus: { $ne: 0 }                                                                                         // 31
  }).forEach(function (session) {                                                                                     //
    //Remove Session-Datas                                                                                            //
    _collection2.AnswerOptionCollection.remove({ hashtag: session.hashtag });                                         // 34
    _collection3.MemberListCollection.remove({ hashtag: session.hashtag });                                           // 35
    _collection4.ResponsesCollection.remove({ hashtag: session.hashtag });                                            // 36
    _collection5.QuestionGroupCollection.remove({ hashtag: session.hashtag });                                        // 37
    _collection.EventManagerCollection.remove({ hashtag: session.hashtag });                                          // 38
  });                                                                                                                 //
}, 300000);                                                                                                           //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"forbiddenNicks.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/forbiddenNicks.js                                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
exports.__esModule = true;                                                                                            //
var forbiddenNicks = exports.forbiddenNicks = ["ASSHAT", "MOTHERFUCKER", "PUMUKEL", "ARSCH", "ARSCHLOCH", "BASTARD", "BITCH", "DRECKSACK", "DRECKSAU", "FICKEN", "FICKFRESSE", "FOTZE", "FUCK", "HACKFRESSE", "HITLER", "HOLOCAUST", "HOMO", "HURENSOHN", "JUDENSAU", "KACKE", "KANACKE", "KZ", "MISSGEBURT", "NAZI", "NEGER", "NIGGER", "NUTTE", "PADOPHILER", "PÄDOPHILER", "PISSER", "SA", "SAU", "SCHEIẞE", "SCHLAMPE", "SCHWANZ", "SCHWUCHTEL", "SIEG", "SPASTI", "SS", "STRICHER", "VOLLIDIOT", "WICHSER", "BOLLERA", "CABRON", "CABRÓN", "CABRONA", "CABRONAZO", "CAPULLA", "CAPULLO", "CHICHI", "CHOCHO", "COJON", "COJÓN", "COJONES", "COMEPOLLAS", "CONO", "COÑO", "CULO", "FOLLAR", "FOLLEN", "FURCIA", "GILIPOLLAS", "HIJAPUTA", "HIJO", "HIJOPUTA", "HOSTIA", "JODER", "JODETE", "JÓDETE", "JOPUTA", "MAMADA", "MAMON", "MAMÓN", "MAMONA", "MARICA", "MARICON", "MARICÓN", "MARICONA", "MARICONAZO", "NAZI", "OJETE", "OSTIA", "PAJILLERO", "PENDON", "PENDÓN", "PICHA", "POLLA", "POLLON", "POLLÓN", "POLVO", "POTORRO", "PUTA", "PUTO", "PUTON", "PUTÓN", "TORTILLERA", "ZORRON", "ZORRÓN", "ABRUTI", "ABRUTIE", "BAISE", "BAISÉ", "BAISER", "BATARD", "BITE", "BOUGNOUL", "BRANLEUR", "BURNE", "CHIER", "COCU", "CON", "CONNARD", "CONNASSE", "CONNE", "COUILLE", "COUILLON", "COUILLONNE", "CREVARD", "CUL", "ENCULE", "ENCULÉ", "ENCULEE", "ENCULÉE", "ENCULER", "ENFOIRE", "ENFOIRÉ", "FION", "FOUTRE", "MERDE", "NEGRE", "NÈGRE", "NEGRESSE", "NÉGRESSE", "NIQUE", "NIQUER", "PARTOUZE", "PD", "PEDE", "PÉDÉ", "PETASSE", "PÉTASSE", "PINE", "POUFFE", "POUFFIASSE", "PUTAIN", "PUTE", "SALAUD", "SALOP", "SALOPARD", "SALOPE", "SODOMIE", "SUCER", "TAPETTE", "TARE", "TARÉ", "VAGIN", "ZOB", "AFFANCULO", "BAGASCIA", "BALDRACCA", "BATTONA", "BOCCHINARA", "BOCCHINARO", "CAZZI", "CAZZO", "CHIAVARE", "COGLIONE", "CULATTONE", "DIO", "DIO", "DIO", "FANCULO", "FICA", "FIGA", "FOTTERE", "FROCIO", "INCULARE", "MIGNOTTA", "MINCHIA", "POMPINARA", "POMPINO", "PORCO", "PUTTANA", "RICCHIONE", "ROTTINCULO", "SBORRA", "SEGAIOLO", "TROIA", "TROIETTA", "TROIONA", "TROIONE", "VAFFANCULO", "ZOCCOLA", "ADHD", "ANAL", "ANALPLUG", "ANALSEX", "ASS", "BASTARD", "BITCH", "BLOWJOB", "BULLSHIT", "CHINK", "CLIT", "COCK", "COCKSUCKER", "COON", "CUM", "CUMSHOT", "CUNT", "DAMN", "DICK", "DICKHEAD", "DILDO", "DYKE", "F.U.C.K.", "FAG", "FAGGOT", "FAGS", "FCUK", "FUCK", "FUCKER", "FUCT", "FUK", "GOBSHITE", "GODDAMN", "GYPO", "HANDJOB", "HITLER", "HOMO", "HORE", "JESUSSUCKS", "JIZZ", "JIZZUM", "KAFFIR", "KIKE", "KUNT", "LESBO", "MASTURBATE", "MOLEST", "NAZI", "NEGRO", "NIGGER", "PAEDO", "PAEDOPHILE", "PAKI", "PECKER", "PEDO", "PEDOFILE", "PEDOPHILE", "PENIS", "PHUK", "POOF", "PUSSY", "QUEER", "RAPE", "RAPED", "RAPES", "RAPIST", "SCROTUM", "SEX", "SHIT", "SHIZ", "SLAG", "SLUT", "SPASTIC", "SPAZ", "SPERM", "SPUNK", "TITS", "TWAT", "VAGINA", "VULVA", "WANK", "WANKER", "WETBACK", "WHOR", "WHORE", "WOG", "9/11", "あいえき", "せいえき", "ファック", "いぬごろし", "いんぱい", "いんもう", "うんこ", "うんち", "おめこ", "かたわ", "きちがい", "くろんぼ", "けとう", "ころす", "ごうかん", "さんごくじん", "しなじん", "しね", "せっくす", "ちゃんころ", "ちんこ", "ちんちん", "ちんぽ", "ちんば", "つんぼ", "どかた", "とさつ", "どもり", "にぐろ", "にんぴにん", "びっこ", "ひにん", "ふぇら", "ぶらく", "ぺにす", "まんこ", "おまんこ", "めくら", "やらせろ", "やりまん", "りょうじょく", "れいぷ", "ろりこん", "강간", "개새끼", "개지랄", "걸레같은년", "걸레년", "귀두", "빨아", "핥아", "니미랄", "딸딸이", "미친년", "미친놈", "병신", "보지", "부랄", "불알", "빠구리", "빠굴이", "사까시", "꼡성감대", "성관계", "냕성폭행", "성행위", "섹스", "시팔년", "시팔놈", "쌍넘", "쌍년", "쌍놈", "쌍뇬", "씨발", "씨발넘", "씨발년", "씨발놈", "씨발뇬", "씹새끼", "염병", "오르", "왕자지", "유두", "자지", "잠지", "정액", "창녀", "콘돔", "클리토리스", "페니스", "후장", "FUT", "GEIL", "KACK", "KACKBRATZE", "MUSCHI", "SCHEIẞHAUS", "SCHEISSE", "TITTEN", "VERDAMNT", "VERDAMMT", "WIXER", "ABORTUS", "ACHTERLIJK", "BOSNEGER", "DEBIEL", "ETTERBAK", "FLIKKER", "FLIKKER", "FOCK", "GEIL", "GODVER", "GODVERJU", "HOER", "HOERTJE", "HOMOFIEL", "HUPPELKUT", "KAK", "KAKKER", "KANKER", "KANKEREN", "KANKERJOCH", "KANKERLYER", "KLERELIJER", "KLOJO", "KLOOTZAK", "KUT", "LIJER", "LUL", "LULHANNES", "MAKAK", "MAKAKKEN", "MOF", "MONGOOL", "MONGOLEN", "NEGER", "NEGERIN", "NEUK", "NEUKEN", "NIKKER", "NSB", "NSBer", "NSB'er", "OUWEHOEREN", "PAARDELUL", "PIK", "PLEURIS", "POEP", "POEPEN", "POKKE", "POKKELIJER", "POKKELYER", "POKKEN", "POKKENLYER", "ROETMOP", "ROTZAK", "SEKS", "SLET", "SLOERIE", "SNOL", "SPLEETOOG", "STOEPHOER", "STRONT", "SUKKEL", "TERING", "TERINGLYER", "TIET", "TIETEN", "TIETJES", "TRUT", "TYFUS", "TYFUSLIJER", "TYFUSLYER", "VERDOMME", "VETZAK", "ZAKKEWASSR", "ZANDNEGER", "BURRO", "CAGAR", "CAGO", "CAGON", "CAGÓN", "CARAJO", "CHINGAR", "CHÚPAME", "CHUPAME", "COÑORITO", "CORRERSE", "CULERO", "HUEVOS", "MIERDA", "PAJERO", "PENDEJO", "PINGA", "PUTAMADRE", "RAMERA", "SOBO", "SUDACA", "VERGA", "FESSE", "M'EMMERDES", "MEMMERDES", "TABARNAK", "T'ENCULE", "TENCULE", "TROUDUC", "VIOL", "MERDA", "STRONZO", "ANUS", "ARSE", "ASSASSIN", "BALLS", "BIMBO", "BLOODY", "BLOODYHELL", "BOLLOCKS", "BONER", "BOOB", "BOOBS", "BOOBIES", "BUGGER", "BUKKAKE", "CLITORIS", "CONDOM", "CRAP", "DAMM", "DAMMIT", "DOGGYSTYLE", "FANNY", "F0CK", "FCK", "FCKER", "FCKR", "FCKU", "FUCKFACE", "FUCKR", "GENITAL", "GENITALIA", "GENITALS", "GLORY", "GLORYHOLE", "GODDAMMET", "GODDAMMIT", "GODAMMET", "GODAMMIT", "HOOKER", "HORNY", "KILL", "KILLER", "KILLIN", "KILLING", "MILF", "MORON", "MOTHERFUCK", "MTHRFCKR", "MUFF", "MURDER", "MURDERER", "NIGGA", "NIGGAH", "NONCE", "PIG", "PIMP", "PISS", "POOP", "PORN", "PRICK", "PRON", "PROSTITUTE", "SCHLONG", "SCREW", "SEMEN", "SHAG", "SHEMALE", "SHITE", "STRIPPER", "TART", "TERRORIST", "TITTIES", "TITTYFUCK", "TOSSER", "TURD", "VAGINAL", "VIBRATOR", "WEED", "WTF", "XXX", "CABRAO", "CARALHO", "CHUPA", "COMEMERDA", "ESPORRA", "ESPORRADA", "FILHODPUTA", "FODA", "FODASSE", "FODE-TE", "FODER", "FUFA", "MAMADA", "MEITA", "MERDA", "MIJAR", "PILA", "RATA", "ARSEL", "FITTA", "KUK", "KUKHUVUD", "KUKSUGARE", "KUSI", "KUSIPÄÄ", "KUSIPAA", "KYRPÄ", "KYRPA", "MULKKU", "PASKA", "PASKA-AIVO", "PASKANAAMA", "PASKAPÄÄ", "PILLU", "CHUJE", "CHUJU", "CIPA", "DUPA", "DZIWKA", "KURWA", "PIERDOL", "PIERDOLSIE", "SKURWYSYN", "SUKA", "FAEN", "FITTE", "FITTETRYNE", "H'STKUK", "HELVETE", "HESTKUK", "HORE", "KUKK", "KUKKHUE", "KUKSKALLE", "KUKSUGER", "POKKER", "RASSHULL", "TREKUKK", "TRØKUK", "BALCONAR", "MUIE", "PULA", "TARFA"];
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"startup.js":["meteor/meteor","meteor/mongo","meteor/webapp","/lib/hashtags/collection.js","/lib/banned_nicks/collection.js","./forbiddenNicks.js",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/startup.js                                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _meteor = require('meteor/meteor');                                                                               // 18
                                                                                                                      //
var _mongo = require('meteor/mongo');                                                                                 // 19
                                                                                                                      //
var _webapp = require('meteor/webapp');                                                                               // 20
                                                                                                                      //
var _collection = require('/lib/hashtags/collection.js');                                                             // 21
                                                                                                                      //
var _collection2 = require('/lib/banned_nicks/collection.js');                                                        // 22
                                                                                                                      //
var _forbiddenNicks = require('./forbiddenNicks.js');                                                                 // 23
                                                                                                                      //
/*                                                                                                                    //
 * This file is part of ARSnova Click.                                                                                //
 * Copyright (C) 2016 The ARSnova Team                                                                                //
 *                                                                                                                    //
 * ARSnova Click is free software: you can redistribute it and/or modify                                              //
 * it under the terms of the GNU General Public License as published by                                               //
 * the Free Software Foundation, either version 3 of the License, or                                                  //
 * (at your option) any later version.                                                                                //
 *                                                                                                                    //
 * ARSnova Click is distributed in the hope that it will be useful,                                                   //
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                     //
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                      //
 * GNU General Public License for more details.                                                                       //
 *                                                                                                                    //
 * You should have received a copy of the GNU General Public License                                                  //
 * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                           //
                                                                                                                      //
if (_meteor.Meteor.isServer) {                                                                                        // 25
	_meteor.Meteor.startup(function () {                                                                                 // 26
		_webapp.WebApp.addHtmlAttributeHook(function () {                                                                   // 27
			return { "lang": "de" };                                                                                           // 28
		});                                                                                                                 //
		if (_collection.HashtagsCollection && !_collection.HashtagsCollection.findOne()) {                                  // 30
			// block this hash / pk -> do not use and merge to production server!                                              //
			var blockedHashtag1 = {                                                                                            // 32
				hashtag: "hashtags",                                                                                              // 33
				privateKey: new _mongo.Mongo.ObjectID()._str,                                                                     // 34
				sessionStatus: 0,                                                                                                 // 35
				lastConnection: new Date().getTime(),                                                                             // 36
				musicVolume: 0,                                                                                                   // 37
				musicEnabled: 0,                                                                                                  // 38
				musicTitle: "noSong",                                                                                             // 39
				theme: "theme-default"                                                                                            // 40
			};                                                                                                                 //
			// block this hash / pk -> do not use and merge to production server!                                              //
			var blockedHashtag2 = {                                                                                            // 30
				hashtag: "privateKey",                                                                                            // 44
				privateKey: new _mongo.Mongo.ObjectID()._str,                                                                     // 45
				sessionStatus: 0,                                                                                                 // 46
				lastConnection: new Date().getTime(),                                                                             // 47
				musicVolume: 0,                                                                                                   // 48
				musicEnabled: 0,                                                                                                  // 49
				musicTitle: "noSong",                                                                                             // 50
				theme: "theme-default"                                                                                            // 51
			};                                                                                                                 //
                                                                                                                      //
			_collection.HashtagsCollection.insert(blockedHashtag1);                                                            // 54
			_collection.HashtagsCollection.insert(blockedHashtag2);                                                            // 55
		}                                                                                                                   //
		if (_collection2.BannedNicksCollection && !_collection2.BannedNicksCollection.findOne()) {                          // 57
			_forbiddenNicks.forbiddenNicks.forEach(function (item) {                                                           // 58
				_collection2.BannedNicksCollection.insert({ userNick: item });                                                    // 59
			});                                                                                                                //
		}                                                                                                                   //
	});                                                                                                                  //
}                                                                                                                     //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"i18n":{"de.i18n.json":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// i18n/de.i18n.json                                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n.languages_names["de"] = ["German","Deutsch"];
TAPi18n._enable({"helper_name":"_","supported_languages":null,"i18n_files_route":"/tap-i18n","preloaded_langs":[],"cdn_path":null});
TAPi18n.languages_names["en"] = ["English","English"];
if(_.isUndefined(TAPi18n.translations["de"])) {
  TAPi18n.translations["de"] = {};
}

if(_.isUndefined(TAPi18n.translations["de"][namespace])) {
  TAPi18n.translations["de"][namespace] = {};
}

_.extend(TAPi18n.translations["de"][namespace], {"global":{"arsnova_slogan":"Quiz für alle(s)","back":"Zurück","next":"Weiter","delete":"Löschen","save":"Speichern","abort":"Abbrechen","close_window":"Fenster schließen"},"region":{"footer":{"go_to":"Gehe auf: ","show-more":{"show-more-elements":"Alle weiteren Optionen:","onText":"Aktiviert","offText":"Deaktiviert"},"footer_bar":{"about":"Über","home":"Home","tos":"AGB","imprint":"Impressum","data_privacy":"Datenschutz","languages":"Sprache","style":"Stil","import":"Quiz importieren","info":"Info","reading-confirmation":"Lesebestätigung","fullscreen":"Vollbild","show_more":"Mehr","sound":"Sound","qr_code":"QR Code"},"about":{"title":"Über die Quiz-App","declaration":"Ein bisschen <a href='https://getkahoot.com' target='_blank'>Kahoot!</a>, <br />ein bisschen <a href='https://arsnova.eu/' target='_blank'>ARSnova</a>!","ars":"Ersteres ist ein gamifiziertes, letzteres ein für die Lehre entwickeltes <a href='https://de.wikipedia.org/wiki/Audience_Response_System' target='_blank'>Audience Response System (ARS)</a>.","developed_by":"Inspiriert durch <a href='https://getkahoot.com' target='_blank'>Kahoot!</a> entwickelte in nur 10 Tagen  ein <a href='http://www.scrumhub.com' target='_blank'>Scrum-Team</a> aus Bachelor- und Masterstudenten der <a href='http://www.thm.de/site/' target='_blank'>TH Mittelhessen</a> diese <a href='https://de.wikipedia.org/wiki/Gamification' target='_blank'>gamifizierte</a> Alternative zu unserem ARSnova-Flaggschiff <a href='https://arsnova.eu/' target='_blank'>arsnova.eu</a>.","met_requirements":"Die bereits eingelösten Anforderungen an arsnova.click:","requirements":{"1":"Absoluter Datenschutz: keine personenbezogenen Daten auf dem Server, alle Quizdaten liegen im Browser der Quizerstellerin oder des Quizerstellers (<a href='http://www.w3schools.com/html/html5_webstorage.asp' target='_blank'>HTML5 Local Storage</a>)","2":"Keine Registrierung, keine Anmeldung, keine Installation, keine Kosten","3":"Dieselbe Startseite ARSnova.click für beide Rollen: Quizmaster und Kandidat/in","4":"Jeder darf Quizze erstellen: sofort und beliebig viele!","5":"Extrem einfache und beamertaugliche Bedienoberfläche","6":"<a href='https://de.wikipedia.org/wiki/TeX' target='_blank'>TeX</a>-Formelsatz und Textformatierung mit <a href='https://guides.github.com/features/mastering-markdown/' target='_blank'>Markdown</a> in Fragen und Antwortoptionen","7":"Mit nur einem Dialog beliebig viele Antwortoptionen als Multiple Choice, Single Choice und Umfrage","8":"Edutainment: Lernspaß durch Live-Wettbewerb mit Sound gegen die Uhr und die Mitspieler/innen","9":"<a href='https://de.wikipedia.org/wiki/Responsive_Webdesign' target='_blank'>Responsives Webdesign</a>: egal ob Smartphone oder Wide Screen, das Design skaliert dank <a href='http://getbootstrap.com/' target='_blank'>Bootstrap</a>","10":"Modernste reaktive Web-Technologie: <a href='https://www.meteor.com' target='_blank'>Meteor</a>","11":"<a href='https://git.thm.de/arsnova/arsnova.click/' target='_blank'>Open Source</a>"},"manual":{"title":"Bedienungshandbuch?","text":{"1":"Braucht man nicht!","2":"Tippen Sie den Namen des Quiz ein. Die Buttons verfärben sich, sobald Sie entweder den Namen eines freigeschalteten Quiz eingeben (Mach mit!) oder ein neues Quiz mit dem eingegebenen Namen erstellen können (Mach neu!).","3":"Danach heißt es: Klicken. Schauen. Quizzen."}}},"tos":{"title":"Allgemeine Geschäftsbedingungen","declaration":"Alle dürfen die Quiz-App ARSnova.click für ihre Zwecke verwenden, solange dabei nicht gegen geltendes deutsches oder europäisches Recht verstoßen wird.","license":{"title":"Lizenz","text":"ARSnova.click ist ein kostenloser Webservice (Software as a Service). Die Software ist <a href='https://git.thm.de/arsnova/arsnova.click/' target='_blank'>Open Source</a> und steht unter der <a href='http://www.gnu.org/licenses/gpl-3.0-standalone.html' target='_blank'>GNU General Public License Version 3</a>."},"warranty":{"title":"Gewährleistung","text":"Wir sind bemüht, den Online-Dienst ARSnova.click zuverlässig und störungsfrei zu betreiben, können dies aber nicht garantieren. Alle Quizdaten liegen ausschließlich im Browser-Speicher der Quizerstellerin oder des Quizerstellers. Wir übernehmen keine Haftung für den Verlust der Daten, zum Beispiel durch Löschen des Browser-Speichers, oder bei rechtswidriger Nutzung des Dienstes."}},"data_privacy":{"title":"Datenschutz","scope":"Geltungsbereich","declaration":"Diese Datenschutzerklärung klärt Nutzer/innen von arsnova.click über die Art, den Umfang und den Zweck der Verwendung personenbezogener Daten durch den verantwortlichen Anbieter auf. Die rechtlichen Grundlagen des Datenschutzes finden sich im Bundesdatenschutzgesetz (BDSG) und dem Telemediengesetz (TMG).","app_data":{"title":"Anwendungsdaten","text":"Alle Quizfragen und deren Antwortoptionen werden ausschließlich im Browser-Speicher (localStorage) der Quizerstellerin oder des Quizerstellers gehalten."},"access_data":{"title":"Zugriffsdaten","text":"Außer Webserver-Logdateien werden keine personenbezogenen Zugriffsdaten gespeichert."},"logfiles":{"title":"Webserver-Logdateien","text":"Der Anbieter erhebt Protokolldaten über jeden Zugriff auf arsnova.click in sogenannten Logdateien. Der Anbieter verwendet die Protokolldaten ausschließlich für statistische Auswertungen zum Zwecke des Betriebs, der Sicherheit und der Optimierung des Angebotes. Der Anbieter behält sich vor, die Protokolldaten nachträglich zu überprüfen, wenn aufgrund konkreter Anhaltspunkte der berechtigte Verdacht einer rechtswidrigen Nutzung besteht."},"3rdparty":{"title":"Dienste und Inhalte Dritter","text":"In Quizfragen können Inhalte Dritter, wie zum Beispiel Videos von YouTube und Vimeo oder Grafiken von anderen Webseiten, eingebunden werden. Dies setzt voraus, dass die Anbieter dieser Inhalte die IP-Adresse der Nutzer/innen wahrnehmen. Ohne die IP-Adresse können die Inhalte nicht an den Browser gesendet werden."},"cookies":{"title":"Cookies","text":"Cookies sind kleine Dateien, die es ermöglichen, auf dem Zugriffsgerät der Nutzer/innen spezifische, auf das Gerät bezogene Informationen zu speichern. Das Angebot arsnova.click nutzt Cookies, um die statistischen Daten der Webseitennutzung mit Piwik (siehe unten) zu erfassen und sie zwecks Verbesserung des Angebotes analysieren zu können. Die Nutzer/innen können auf den Einsatz der Cookies Einfluss nehmen. Die meisten Browser verfügen über eine Option, mit der das Speichern von Cookies eingeschränkt oder komplett verhindert wird."},"piwik":{"title":"Piwik","text":"Dieses Angebot benutzt Piwik, eine Open-Source-Software zur statistischen Auswertung der Zugriffe, siehe <a href='http://piwik.org/' target='_blank'>piwik.org</a>. Piwik verwendet Cookies, die auf dem Computer der Nutzer/innen gespeichert werden und die eine Analyse der Benutzung der Webseite ermöglichen. Die durch den Cookie erzeugten Informationen über die Benutzung dieses Agebotes werden auf dem Server des Anbieters in Deutschland gespeichert. Die IP-Adresse wird sofort nach der Verarbeitung und vor deren Speicherung anonymisiert. Nutzer/innen können die Installation der Cookies durch eine entsprechende Einstellung ihrer Browser-Software verhindern."}},"imprint":{"title":"Impressum","provider":{"title":"Dienstanbieter","text":{"1":"Der Betrieb der Webapp arsnova.click ist eine kostenlose Dienstleistung der TransMIT-Gesellschaft für Technologietransfer mbH, Projektbereich für mobile Anwendungen.","2":"c/o THM – Technische Hochschule Mittelhessen","3":"Fachbereich MNI – Mathematik, Naturwissenschaften und Informatik","4":"Prof. Dr. Klaus Quibeldey-Cirkel","5":"Lehrstuhl für Softwaretechnik","6":"Wiesenstraße 14","7":"D-35390 Gießen","8":"Telefon: +49 641 309 – 24 50","9":"E-Mail: <a href='mailto:klaus.quibeldey-cirkel@transmit.de' class='text-light'>klaus.quibeldey-cirkel@transmit.de</a>","10":"Sitz der Gesellschaft: Gießen","11":"Website: <a href='https://www.transmit.de' class='text-light'>https://www.transmit.de</a>","12":"Rechtsform: GmbH","13":"Amtsgericht: Gießen HRB 3036","14":"USt-IdNr.: DE 188 685 037"}}}},"header":{"new_question":"Neue Frage","reset":"Reset","yes":"Ja","no":"Nein","reset_session_confirmation":{"title":"Soll das Quiz beendet werden?","text":{"1":"Alle Teilnehmenden werden abgmeldet. Die Rangliste wird gelöscht. Dein Quiz mit allen Einstellungen verbleibt in diesem Browser, solange er nicht zurückgesetzt wird.","2":"Fortfahren?"}}}},"view":{"answeroptions":{"answeroptiontext_placeholder":"Antwortoption eingeben","correct":"Richtig","wrong":"Falsch"},"choose_nickname":{"enter_nickname":"Gib dir einen Nicknamen","enter_nickname_here":"Gib deinen Nick ein","nickname_na_popup":"Dieser Name ist nicht verfügbar!","nickname_blacklist_popup":"Dieser Name ist nicht zulässig!","nickname_too_long":"Der Name ist zu lang","nickname_too_short":"Der Name ist zu kurz"},"hashtag_management":{"enter_quiz_name":"Gib hier den Quiznamen ein","join_session":"Mach mit!","start_session":"Quiz starten","edit_session":"Quiz bearbeiten","reenter_session":"Öffnen","create_session":"Mach neu!","quiz_management":"Gespeicherte Quizze","available_sessions":"Diese Quizze sind in deinem Browser:","session_management":"Quizverwaltung","import":"Quiz importieren","delete_session":"Quiz löschen","delete_session_confirmation":"Soll das Quiz '<span id=\"session_name\"></span>' unwiderruflich gelöscht werden?","export":"Quiz exportieren","valid_question":"Gültige Quizrunde","invalid_question":"Ungültige Quizrunde"},"leaderboard":{"title":{"single_question":"Quizfrage __questionId__ - Alles richtig haben...","all_questions":"Alles richtig haben..."},"no_attendee_correct":"Niemand hat diese Frage richtig beantwortet","no_attendee_correct_global":"Niemand hat alle Fragen richtig beantwortet","question":"Frage","second":"Sekunde","second_plural":"Sekunden","show_more":"Zeige 1 weiteren","show_more_plural":"Zeige %s weitere","show_less":"Zeige weniger"},"liveResults":{"question":"Frage","ranking":"Rangliste","reading_confirmation":"Lesebestätigung","show_more":"Zeige 1 weiteren","show_more_plural":"Zeige %s weitere","complete_correct":"Ganz richtig","complete_wrong":"Ganz falsch","back_to_lobby":"Zurück zur Lobby","global_ranking":"Globale Rangliste","show_question":"Zeige die Frage","show_question_plural":"Zeige Frage","start_round":"Starte Quiz","start_round_plural":"Starte Runde","confirm_read":"Ich habe die Frage gelesen","game_over":"Game over","countdown":"Countdown","answer_option":"Antwort"},"lobby":{"title":"Quiz Lobby","yes":"Ja","no":"Nein","ready":"Startklar fürs Quiz","show_more":"Zeige 1 weiteren","show_more_plural":"Zeige %s weitere","start_quiz":"Los geht's!","kick_member_confirmation":"Soll die Person '<span id=\"nickName\"></span>' aus dem Quiz entfernt werden?","add_kicked_member_to_ban_list":"Den Nicknamen permanent bannen"},"questions":{"enter_question_here":"Gib hier die Frage ein","format":"Format","edit":"Bearbeiten","preview":"Vorschau","single_choice_question":"Single-Choice-Frage (nur eine Antwort ist richtig)","multiple_choice_question":"Multiple-Choice-Frage (eine oder mehrere Antworten sind richtig)","survey_question":"Umfrage (Antworten sind weder richtig noch falsch)","ranged_question":"Schätzfrage (Antworten im vorgegebenen Bereich sind richtig)"},"quiz_summary":{"summary":"Zusammenfassung","quiz_name":"Name der Quizrunde","quiz_url":"URL für Teilnehmer/innen","question_amount":"Gesamtanzahl der Quizfragen","validation_question_group":"Validierung der gesamten Quizrunde","successful":"Erfolgreich","failed":"Fehlgeschlagen","correct":"Richtig","wrong":"Falsch","question":"Frage","text":"Text","type":"Typ","answer":"Antwort","answer_plural":"Antworten","timer":"Countdown","second":"Sekunde","second_plural":"Sekunden","validation":"Validierung","validation_errors":{"types":{"question":"Frage","answerOption":"Antwort"},"reasons":{"question_text_too_small":"Text der Quizfrage ist zu kurz","question_text_too_long":"Text der Quizfrage ist zu lang","timer_too_small":"Timer ist zu kurz","timer_too_big":"Timer ist zu lang","no_valid_answers":"Mindestens eine richtige Antwort muss vorhanden sein","one_valid_answer_required":"Es muss exakt eine richtige Antwort vorhanden sein","no_valid_answer_required":"Keine richtige Antwort darf vorhanden sein","invalid_range":"Die minimale Reichweite muss geringer als die maximale Reichweite sein","answer_text_empty":"Text der Antwort darf nicht leer sein"}},"edit_quiz":"Quiz bearbeiten","start_quiz":"Quiz starten"},"theme_switcher":{"set_theme":"Stil wählen","select_a_theme_title":"Wähle einen Stil","themes":{"default":{"name":"ARSnova.click","description":"Der Stil der ersten Stunde"},"dark":{"name":"Dunkle Version","description":"Dunkler Hintergrund mit geringem Kontrast"},"elegant":{"name":"Elegant","description":"Eleganter Stil für anspruchsvolle Quizrunden"},"thm":{"name":"THM","description":"Corporate Design der TH Mittelhessen"},"arsnova":{"name":"ARSnova","description":"Du kennst ARSnova? Dann fühl' dich wie zu Hause!"}}},"timer":{"set_countdown":"Countdown einstellen","second":"Sekunde","second_plural":"Sekunden"},"translation":{"translations":"Diese Sprachen sind verfügbar:","i18n_currently_not_available":"i18n ist aktuell nicht verfügbar!","beta":"Beta"},"voting":{"question":"Frage","send":"Absenden","seconds_left":"Noch 1 Sekunde!","seconds_left_plural":"Noch __value__ Sekunden!"}},"plugins":{"markdown_bar":{"visible_text":"Angezeigter Text","link_text":"Linktext","link_destination":"Linkziel","tooltip":{"info":"Info","bold":"Fett","heading":"Überschrift","hyperlink":"Hyperlink","unordered_list":"Unsortierte Liste","ordered_list":"Sortierte Liste","latex":"LaTeX-Auszeichnung","code":"Code-Auszeichnung","citation":"Zitat","image":"Bild","youtube":"YouTube","vimeo":"Vimeo"},"info_content":"Du kannst Texte innerhalb von ARSnova mithilfe von <a target='_blank' class='hyperlink' href='https://de.wikipedia.org/wiki/Markdown'>Markdown</a> auszeichnen. Die am häufigsten verwendeten Markdown Optionen werden in Form von Schaltflächen über den unterstützten Eingabefeldern angeboten. Zudem unterstützt ARSnova <a target='_blank' class='hyperlink' href='https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet'>GitHub Flavored Markdown</a>"},"sound":{"title":"Countdown Sound","volume":"Lautstärke","inactive":"Sound ist inaktiv","active":"Sound ist aktiviert"},"splashscreen":{"error":{"title":"Hinweis","set_text_error":"Der Text des Splashscreens kann nur gesetzt werden, nachdem er gerendered wurde!","error_messages":{"Internal Server Error":"Interner Serverfehler","update_failed":"Es ist ein Fehler bei der Aktualisierung deiner Frage aufgetreten.","session_exists":"Diese Sitzung existiert bereits!","session_not_exists":"Diese Sitzung existiert nicht!","hashtag_exists":"Dieser Quizname existiert bereits!","session_not_available":"Dieser Quizrunde kann aktuell nicht beigetreten werden.","private_browsing":"Im Privatmodus deines Browsers funktioniert ARSnova.click leider nur als Teilnehmer/in, da dein Browser das Beschreiben des App-Speichers verweigert. Bitte für die Dauer der Nutzung von ARSnova.click den Privatmodus deaktivieren und ARSnova erneut aufrufen. Deine Anonymität bleibt auch bei deaktiviertem Privatmodus gewahrt.","kicked_from_quiz":"Du wurdest aus dem Quiz geworfen!","export_failed":"Konnte die Daten nicht exportieren! - %s","not_authorized":"Entweder ist das Quiz nicht vorhanden oder du hast keine Berechtigung, diese Daten zu lesen","maximum_answer_options_exceeded":"Die maximale Anzahl an Antwortoptionen wurde bereits erreicht","hashtag_not_found":"Dieser Quizname wurde leider nicht gefunden","member_not_found":"Der Teilnehmer wurde leider nicht gefunden","duplicate_response":"Der Teilnehmer hat bereits eine Antwort abgegeben","answeroption_not_found":"Es existiert keine Antwort mit diesem Index","response_timeout":"Der Countdown ist bereits abgelaufen","insert_leaderboard_failed":"Fehler beim Hinzufügen der Antwort zur Rangliste","session_closed":"Die Quizrunde wurde beendet","invalid_data":"Die importierten Daten sind ungültig oder fehlerhaft!"}}}}});
TAPi18n._registerServerTranslator("de", namespace);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"en.i18n.json":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// i18n/en.i18n.json                                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
// integrate the fallback language translations 
translations = {};
translations[namespace] = {"global":{"arsnova_slogan":"Quizzes for everyone & anything","back":"Back","next":"Next","delete":"Delete","save":"Save","abort":"Abort","close_window":"Close window"},"region":{"footer":{"go_to":"Go to: ","show-more":{"show-more-elements":"All available options:","onText":"Activated","offText":"Deactivated"},"footer_bar":{"about":"About","home":"Home","tos":"ToS","imprint":"Imprint","data_privacy":"Data Privacy","languages":"Languages","style":"Styles","import":"Import","info":"Info","reading-confirmation":"Reading confirmation","fullscreen":"Fullscreen","show_more":"More","sound":"Sound","qr_code":"QR Code"},"about":{"title":"About the quiz app","declaration":"A little bit <a href='https://getkahoot.com' target='_blank'>Kahoot!</a>, <br />a little bit <a href='https://arsnova.eu/' target='_blank'>ARSnova</a>!","ars":"First one is gamificated and the second one designed for educational use. Both are an <a href='https://en.wikipedia.org/wiki/Audience_Response_System' target='_blank'>Audience Response System (ARS)</a>.","developed_by":"Inspired by <a href='https://getkahoot.com' target='_blank'>Kahoot!</a> a <a href='http://www.scrumhub.com' target='_blank'>Scrum-Team</a> of Bachelor and Master students of the <a href='http://www.thm.de/site/' target='_blank'>TH Mittelhessen</a> designed and developed in only 10 days this <a href='https://en.wikipedia.org/wiki/Gamification' target='_blank'>gamificated</a> alternative to our ARSnova-Flagship <a href='https://arsnova.eu/' target='_blank'>arsnova.eu</a>.","met_requirements":"Requirements which ARSnova.click has already met:","requirements":{"1":"Absolute data privacy: No personal files on the server. All quiz data is located at the <a href='http://www.w3schools.com/html/html5_webstorage.asp' target='_blank'>HTML5 Local Storage</a> of the quiz owner.","2":"No registration, no installation, no costs at all","3":"Same landing page for both roles: quiz master and attendee","4":"Anyone can create quizzes: immediately and as much as you like!","5":"Extreme easy to use and beamer friendly user interface","6":"<a href='https://en.wikipedia.org/wiki/TeX' target='_blank'>TeX</a>-Formulas and text formatting with <a href='https://guides.github.com/features/mastering-markdown/' target='_blank'>Markdown</a> in questions and answer options","7":"One dialog fits everything: As many answer options you like with multiple choice, single choice and surveys.","8":"Edutainment: Have fun during learning with a live competition against the clock and the other players with sound effects.","9":"<a href='https://en.wikipedia.org/wiki/Responsive_Webdesign' target='_blank'>Responsive Web design</a>: From the smart phone to the wide screen - the design adapts thanks to <a href='http://getbootstrap.com/' target='_blank'>Bootstrap</a>","10":"The bleading edge in modern web technologies: <a href='https://www.meteor.com' target='_blank'>Meteor</a>","11":"<a href='https://git.thm.de/arsnova/arsnova.click/' target='_blank'>Open Source</a>"},"manual":{"title":"Manual?","text":{"1":"You won't need that!","2":"Simply type in the name of the quiz. The buttons will discolour as soon as you've typed in the name of an active quiz (Join now!) or you can create a new quiz with the entered name (Make a new one!).","3":"Now it is as simple as: Clicking. Looking. Quizzing."}}},"tos":{"title":"Terms of Service","declaration":"Everyone is allowed to use the quiz app ARSnova.click for their own purposes as long as the user does not infringe German or European law.","license":{"title":"License","text":"ARSnova.click is a free webservice (Software as a Service). The software is <a href='https://git.thm.de/arsnova/arsnova.click/' target='_blank'>Open Source</a> und is distributed under the <a href='http://www.gnu.org/licenses/gpl-3.0-standalone.html' target='_blank'>GNU General Public License Version 3</a>."},"warranty":{"title":"Warranty","text":"We are trying to maintain the online service of ARSnova.click reliable but we cannot guarantee that. The quiz files are located exclusively in the local browser storage of the quiz owner. We do not give any legal responsibility for any data loss for example via deleting the local browser storage or by illegal usage of the service."}},"data_privacy":{"title":"Data Privacy","scope":"Scope","declaration":"This privacy statement explains to users of ARSnova.click the nature, scope and purpose of the usage of personal data by the responsible provider. The legal basis of this privacy policy can be found in the German Bundesdatenschutzgesetz (BDSG) and the German Telemediengesetz (TMG).","app_data":{"title":"Application data","text":"All quiz questions and their answer options are held by the local browser storage of the quiz owner."},"access_data":{"title":"Access data","text":"Besides web server log files, no personal access data is stored."},"logfiles":{"title":"Webserver logfiles","text":"The provider collects log files about every access to the ARSnova.click system in so-called log files. The provider uses the data exclusively for statistical purposes, for the purpose of operation, security and the optimization of the service. The provider reserves the right to check the log data if there is a reasonable suspicion of unlawful use due to concrete indications."},"3rdparty":{"title":"3rd party services","text":"In quizzes third party services or content, such as videos from YouTube and Vimeo or graphics can be included from other websites. This requires that the provider of such content percive the user's IP address. Without the IP address the content can not be sent to the browser."},"cookies":{"title":"Cookies","text":"Cookies are small files that make it possible to save specific (related to the device) information of the user inside the access device. The offer ARSnova.click uses cookies to observe statistical data of website's usage by Piwik (see below) to be able to detect and analyze them in order to improve the offer. The user can influence the use of cookies. Most browsers have an option to limit the storage and usage of cookies or prevent the usage of cookies completely."},"piwik":{"title":"Piwik","text":"This offer uses Piwik, an open source software for statistical analysis of traffic, see <a href='http://piwik.org/' target='_blank'>piwik.org</a>. Piwik uses cookies, which are stored on the computer of the user and allow the analysis of your use of the website. The information generated by the cookie about your use of this service is stored on the provider's server in Germany. The IP address is anonymized immediately after processing and before the storage. The user can refuse the use of cookies by changing the settings of their browser software."}},"imprint":{"title":"Imprint","provider":{"title":"Service provider","text":{"1":"The operation of the web app ARSnova.click is a free service of the TransMIT-Gesellschaft für Technologietransfer mbH, Projektbereich für mobile Anwendungen.","2":"c/o THM – Technische Hochschule Mittelhessen","3":"Fachbereich MNI – Mathematik, Naturwissenschaften und Informatik","4":"Prof. Dr. Klaus Quibeldey-Cirkel","5":"Lehrstuhl für Softwaretechnik","6":"Wiesenstraße 14","7":"D-35390 Gießen","8":"Telefon: +49 641 309 – 24 50","9":"E-Mail: <a href='mailto:klaus.quibeldey-cirkel@transmit.de' class='text-light'>klaus.quibeldey-cirkel@transmit.de</a>","10":"Sitz der Gesellschaft: Gießen","11":"Website: <a href='https://www.transmit.de' class='text-light'>https://www.transmit.de</a>","12":"Rechtsform: GmbH","13":"Amtsgericht: Gießen HRB 3036","14":"USt-IdNr.: DE 188 685 037"}}}},"header":{"new_question":"New question","reset":"Reset","yes":"Yes","no":"No","reset_session_confirmation":{"title":"Exit the quiz?","text":{"1":"On resetting the session, all students will be redirected to the landing page. The current ranking and the quiz-lobby will be deleted. The created Question(s), including the assigned answer options and timer configurations, are stored in the local storage of your browser. Except the quiz name, all data of this session will be removed from the server.","2":"Proceed?"}}}},"view":{"answeroptions":{"answeroptiontext_placeholder":"Answer option required","correct":"Correct","wrong":"Wrong"},"choose_nickname":{"enter_nickname":"Take a nickname","enter_nickname_here":"Enter your nickname here","nickname_na_popup":"This name is not available!","nickname_blacklist_popup":"This name is (because of its meaning) not available!","nickname_too_long":"The name is too long","nickname_too_short":"The name is too short"},"hashtag_management":{"enter_quiz_name":"Enter the quiz name here","join_session":"Join now!","edit_session":"Edit","reenter_session":"Open","create_session":"Make a new one!","quiz_management":"Stored Quizzes","available_sessions":"These quizzes are stored in your browser:","session_management":"Quiz Management","import":"Import quiz","delete_session":"Delete quiz","delete_session_confirmation":"Shall the quiz '<span id=\"session_name\"></span>' be removed permanently?","export":"Export quiz","valid_question":"Valid Quiz","invalid_question":"Invalid Quiz"},"leaderboard":{"title":{"single_question":"Question __questionId__ - Correct answers from...","all_questions":"Correct answers from..."},"no_attendee_correct":"No one has answered this question correctly","no_attendee_correct_global":"Nobody has answered all the questions correctly","question":"Question","second":"second","second_plural":"seconds","show_more":"Show 1 more","show_more_plural":"Show %s more","show_less":"Show less"},"liveResults":{"question":"Question","ranking":"Ranking","reading_confirmation":"Reading confirmation","show_more":"Show 1 more","show_more_plural":"Show %s more","complete_correct":"Everything correct","complete_wrong":"Everything wrong","back_to_lobby":"Back to the lobby","global_ranking":"Global ranking","show_question":"Show question","show_question_plural":"Show question","start_round":"Start Quiz","start_round_plural":"Start round","confirm_read":"Got that!","game_over":"Game over","countdown":"Countdown","answer_option":"Answer"},"lobby":{"title":"Quiz Lobby","yes":"Yes","no":"No","ready":"Ready for quizzing","show_more":"Show 1 more","show_more_plural":"Show %s more","start_quiz":"Let's go!","kick_member_confirmation":"Shall the attendee '<span id=\"nickName\"></span>' be removed from the session?","add_kicked_member_to_ban_list":"Ban nickname permanently"},"questions":{"enter_question_here":"Enter your question here","format":"Format","edit":"Edit","preview":"Preview","single_choice_question":"Single-Choice","multiple_choice_question":"Multiple-Choice","survey_question":"Survey","ranged_question":"Question with ranged answeroptions"},"quiz_summary":{"summary":"Summary","quiz_name":"Name of the quiz","quiz_url":"URL for attendees","question_amount":"Amount of all questions","validation_question_group":"Validation for the complete quiz","successful":"Successful","failed":"Failed","correct":"Correct","wrong":"Wrong","question":"Question","text":"Text","type":"Type","answer":"Answer","answer_plural":"Answers","timer":"Countdown","second":"second","second_plural":"seconds","validation":"Validation","validation_errors":{"types":{"question":"Question","answerOption":"Answer"},"reasons":{"question_text_too_small":"The question text is too short","question_text_too_long":"The question text is too long","timer_too_small":"The timer is too short","timer_too_big":"The timer is too long","no_valid_answers":"There must be at least one correct answer","one_valid_answer_required":"There must be exactly one correct answer","no_valid_answer_required":"There are no correct answers allowed","invalid_range":"The minimum range must be smaller than the maximum range","answer_text_empty":"The answer's text is not allowed to be empty"}},"edit_quiz":"Edit quiz","start_quiz":"Start quiz"},"theme_switcher":{"set_theme":"Choose a theme for all attendees","select_a_theme_title":"Choose the theme","themes":{"default":{"name":"ARSnova.click","description":"The first and main theme of ARSnova.click"},"dark":{"name":"Dark version","description":"Dark background with low contrast"},"elegant":{"name":"Elegant","description":"Elegant theme for sophisticated Quizzers"},"thm":{"name":"THM","description":"Corporate Design of the University of Applied Science (THM)"},"arsnova":{"name":"ARSnova","description":"You know ARSnova? Feel home!"}}},"timer":{"set_countdown":"Set countdown","second":"Second","second_plural":"Seconds"},"translation":{"translations":"These translations are available:","i18n_currently_not_available":"I18n is currently not available!","beta":"Beta"},"voting":{"question":"Question","send":"Send","seconds_left":"1 Second left!","seconds_left_plural":"__value__ Seconds left"}},"plugins":{"markdown_bar":{"visible_text":"Visible text","link_text":"Link text","link_destination":"Link target","tooltip":{"info":"Info","bold":"Bold","heading":"Headline","hyperlink":"Hyperlink","unordered_list":"Unordered list","ordered_list":"Ordered list","latex":"LaTex Markup","code":"Code Markup","citation":"Citation","image":"Image","youtube":"YouTube","vimeo":"Vimeo"},"info_content":"You can use <a target='_blank' class='hyperlink' href='https://en.wikipedia.org/wiki/Markdown'>Markdown</a> markup for your text in ARSnova.click. Frequently used markup options are available via the button bar which is visible on all supported input fields. Additionally ARSnova.click supports <a target='_blank' class='hyperlink' href='https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet'>GitHub Flavored Markdown</a>"},"sound":{"title":"Countdown Sound","volume":"Volume","inactive":"Sound is inactive","active":"Sound is active"},"splashscreen":{"error":{"title":"Notification","set_text_error":"The text of the error splashscreen can only be set after it has been rendered!","error_messages":{"Internal Server Error":"Internal Server Error","update_failed":"The update of the question failed.","session_exists":"This session exists already!","session_not_exists":"This session does not exist!","hashtag_exists":"This hashtag exists already!","session_not_available":"Session is currently not available for joining","private_browsing":"If you use ARSnova.click in private browsing you can only join a quiz as an attendee. Unfortunately your browser seems to reject any write access to the local storage. Please use ARSnova.click only via a normal browser tab. Your anonymity will be respected even without using the private mode.","kicked_from_quiz":"You've been kicked from the quiz!","export_failed":"Could not export! - %s","not_authorized":"Either there is no quiz or you don't have write access","maximum_answer_options_exceeded":"Maximum number of possible answer options exceeded","hashtag_not_found":"No such hashtag with the given key","member_not_found":"Member not found","duplicate_response":"User has already given a response","answeroption_not_found":"There is no answer option with the given answerOptionNumber","response_timeout":"Response was given out of time range","insert_leaderboard_failed":"Error while adding response set to leaderboard","session_closed":"The quiz session has been closed","invalid_data":"The imported files are corrupt or the access is denied!"}}}}};
TAPi18n._loadLangFileObject("en", translations);
TAPi18n._registerServerTranslator("en", namespace);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"es.i18n.json":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// i18n/es.i18n.json                                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n.languages_names["es"] = ["Spanish (Spain)","Español"];
if(_.isUndefined(TAPi18n.translations["es"])) {
  TAPi18n.translations["es"] = {};
}

if(_.isUndefined(TAPi18n.translations["es"][namespace])) {
  TAPi18n.translations["es"][namespace] = {};
}

_.extend(TAPi18n.translations["es"][namespace], {"global":{"arsnova_slogan":"Tests para todo el mundo y cualquier cosa","back":"Espalda","next":"Siguiente","delete":"Borrar","save":"Salvar","abort":"Abortar","close_window":"Cerrar ventana"},"region":{"footer":{"go_to":"Ir: ","show-more":{"show-more-elements":"Todas las opciones disponibles:","onText":"Activado","offText":"Desactivado"},"footer_bar":{"about":"Acerca de","home":"Casa","tos":"Términos de servicio","imprint":"Imprimir","data_privacy":"Privacidad de datos","languages":"Idiomas","style":"Estilo","import":"Importar","info":"Info","reading-confirmation":"Confirmación de lectura","fullscreen":"Pantalla completa","show_more":"Más","sound":"Sonar","qr_code":"QR Code"},"about":{"title":"About the quiz app","declaration":"A little bit <a href='https://getkahoot.com' target='_blank'>Kahoot!</a>, <br />a little bit <a href='https://arsnova.eu/' target='_blank'>ARSnova</a>!","ars":"First one is gamificated and the second one designed for educational use. Both are an <a href='https://en.wikipedia.org/wiki/Audience_Response_System' target='_blank'>Audience Response System (ARS)</a>.","developed_by":"Inspired by <a href='https://getkahoot.com' target='_blank'>Kahoot!</a> a <a href='http://www.scrumhub.com' target='_blank'>Scrum-Team</a> of Bachelor and Master students of the <a href='http://www.thm.de/site/' target='_blank'>TH Mittelhessen</a> designed and developed in only 10 days this <a href='https://en.wikipedia.org/wiki/Gamification' target='_blank'>gamificated</a> alternative to our ARSnova-Flagship <a href='https://arsnova.eu/' target='_blank'>arsnova.eu</a>.","met_requirements":"Requirements which ARSnova.click has already met:","requirements":{"1":"Absolute data privacy: No personal files on the server. All quiz data is located at the <a href='http://www.w3schools.com/html/html5_webstorage.asp' target='_blank'>HTML5 Local Storage</a> of the quiz owner.","2":"No registration, no installation, no costs at all","3":"Same landing page for both roles: quiz master and attendee","4":"Anyone can create quizzes: immediately and as much as you like!","5":"Extreme easy to use and beamer friendly user interface","6":"<a href='https://en.wikipedia.org/wiki/TeX' target='_blank'>TeX</a>-Formulas and text formatting with <a href='https://guides.github.com/features/mastering-markdown/' target='_blank'>Markdown</a> in questions and answer options","7":"One dialog fits everything: As many answer options you like with multiple choice, single choice and surveys.","8":"Edutainment: Have fun during learning with a live competition against the clock and the other players with sound effects.","9":"<a href='https://en.wikipedia.org/wiki/Responsive_Webdesign' target='_blank'>Responsive Web design</a>: From the smart phone to the wide screen - the design adapts thanks to <a href='http://getbootstrap.com/' target='_blank'>Bootstrap</a>","10":"The bleading edge in modern web technologies: <a href='https://www.meteor.com' target='_blank'>Meteor</a>","11":"<a href='https://git.thm.de/arsnova/arsnova.click/' target='_blank'>Open Source</a>"},"manual":{"title":"Manual?","text":{"1":"You won't need that!","2":"Simply type in the name of the quiz. The buttons will discolour as soon as you've typed in the name of an active quiz (Join now!) or you can create a new quiz with the entered name (Make a new one!).","3":"Now it is as simple as: Clicking. Looking. Quizzing."}}},"tos":{"title":"Terms of Service","declaration":"Everyone is allowed to use the quiz app ARSnova.click for their own purposes as long as the user does not infringe German or European law.","license":{"title":"License","text":"ARSnova.click is a free webservice (Software as a Service). The software is <a href='https://git.thm.de/arsnova/arsnova.click/' target='_blank'>Open Source</a> und is distributed under the <a href='http://www.gnu.org/licenses/gpl-3.0-standalone.html' target='_blank'>GNU General Public License Version 3</a>."},"warranty":{"title":"Warranty","text":"We are trying to maintain the online service of ARSnova.click reliable but we cannot guarantee that. The quiz files are located exclusively in the local browser storage of the quiz owner. We do not give any legal responsibility for any data loss for example via deleting the local browser storage or by illegal usage of the service."}},"data_privacy":{"title":"Data Privacy","scope":"Scope","declaration":"This privacy statement explains to users of ARSnova.click the nature, scope and purpose of the usage of personal data by the responsible provider. The legal basis of this privacy policy can be found in the German Bundesdatenschutzgesetz (BDSG) and the German Telemediengesetz (TMG).","app_data":{"title":"Application data","text":"All quiz questions and their answer options are held by the local browser storage of the quiz owner."},"access_data":{"title":"Access data","text":"Besides web server log files, no personal access data is stored."},"logfiles":{"title":"Webserver logfiles","text":"The provider collects log files about every access to the ARSnova.click system in so-called log files. The provider uses the data exclusively for statistical purposes, for the purpose of operation, security and the optimization of the service. The provider reserves the right to check the log data if there is a reasonable suspicion of unlawful use due to concrete indications."},"3rdparty":{"title":"3rd party services","text":"In quizzes third party services or content, such as videos from YouTube and Vimeo or graphics can be included from other websites. This requires that the provider of such content percive the user's IP address. Without the IP address the content can not be sent to the browser."},"cookies":{"title":"Cookies","text":"Cookies are small files that make it possible to save specific (related to the device) information of the user inside the access device. The offer ARSnova.click uses cookies to observe statistical data of website's usage by Piwik (see below) to be able to detect and analyze them in order to improve the offer. The user can influence the use of cookies. Most browsers have an option to limit the storage and usage of cookies or prevent the usage of cookies completely."},"piwik":{"title":"Piwik","text":"This offer uses Piwik, an open source software for statistical analysis of traffic, see <a href='http://piwik.org/' target='_blank'>piwik.org</a>. Piwik uses cookies, which are stored on the computer of the user and allow the analysis of your use of the website. The information generated by the cookie about your use of this service is stored on the provider's server in Germany. The IP address is anonymized immediately after processing and before the storage. The user can refuse the use of cookies by changing the settings of their browser software."}},"imprint":{"title":"Imprint","provider":{"title":"Service provider","text":{"1":"The operation of the web app ARSnova.click is a free service of the TransMIT-Gesellschaft für Technologietransfer mbH, Projektbereich für mobile Anwendungen.","2":"c/o THM – Technische Hochschule Mittelhessen","3":"Fachbereich MNI – Mathematik, Naturwissenschaften und Informatik","4":"Prof. Dr. Klaus Quibeldey-Cirkel","5":"Lehrstuhl für Softwaretechnik","6":"Wiesenstraße 14","7":"D-35390 Gießen","8":"Telefon: +49 641 309 – 24 50","9":"E-Mail: <a href='mailto:klaus.quibeldey-cirkel@transmit.de' class='text-light'>klaus.quibeldey-cirkel@transmit.de</a>","10":"Sitz der Gesellschaft: Gießen","11":"Website: <a href='https://www.transmit.de' class='text-light'>https://www.transmit.de</a>","12":"Rechtsform: GmbH","13":"Amtsgericht: Gießen HRB 3036","14":"USt-IdNr.: DE 188 685 037"}}}},"header":{"new_question":"Nueva pregunta","reset":"Reiniciar","yes":"Sí","no":"No","reset_session_confirmation":{"title":"Exit the quiz?","text":{"1":"On resetting the session, all students will be redirected to the landing page. The current ranking and the quiz-lobby will be deleted. The created Question(s), including the assigned answer options and timer configurations, are stored in the local storage of your browser. Except the quiz name, all data of this session will be removed from the server.","2":"Proceed?"}}}},"view":{"answeroptions":{"answeroptiontext_placeholder":"Opción de respuesta necesario","correct":"Correcto","wrong":"Incorrecto"},"choose_nickname":{"enter_nickname":"Tome un apodo","enter_nickname_here":"Introduzca su apodo aquí","nickname_na_popup":"Este nombre no está disponible!","nickname_blacklist_popup":"Este nombre es (debido a su significado) no disponible!","nickname_too_long":"El nombre es demasiado largo","nickname_too_short":"El nombre es demasiado corto"},"hashtag_management":{"enter_quiz_name":"Introduzca el nombre del concurso aquí","join_session":"Únete ahora!","edit_session":"Editar","reenter_session":"Abierto","create_session":"Hacer una nueva!","quiz_management":"Tests almacenados","available_sessions":"Estas pruebas se almacenan en el navegador:","session_management":"Gestión de prueba","import":"Cuestionario de importación","delete_session":"Prueba clara","delete_session_confirmation":"Si elimina permanentemente el '<span id=\"session_name\"></span>' de cuestionarios?","export":"Cuestionario de exportación","valid_question":"Prueba válida","invalid_question":"Cuestionario no válido"},"leaderboard":{"title":{"single_question":"Pregunta __questionId__ - Las respuestas correctas a partir de...","all_questions":"Las respuestas correctas a partir de..."},"no_attendee_correct":"Nadie ha respondido a esta pregunta correctamente","no_attendee_correct_global":"Nadie ha respondido a todas las preguntas correctamente","question":"Pregunta","second":"Segundo","second_plural":"Segundos","show_more":"Desde el 1 más","show_more_plural":"Mostrar %s más","show_less":"Muestra menos"},"liveResults":{"question":"Pregunta","ranking":"Clasificación","reading_confirmation":"Confirmación de lectura","show_more":"Desde el 1 más","show_more_plural":"Mostrar %s más","complete_correct":"Todo correcto","complete_wrong":"Todo mal","back_to_lobby":"Volver al vestíbulo","global_ranking":"Ranking global","show_question":"Mostrar pregunta","show_question_plural":"Mostrar pregunta","start_round":"Inicio del concurso","start_round_plural":"Comience ronda","confirm_read":"Lo tengo!","game_over":"Juego terminado","countdown":"Cuenta regresiva","answer_option":"Responder"},"lobby":{"title":"Prueba Vestíbulo","yes":"Sí","no":"No","ready":"Listo para interrogar","show_more":"Desde el 1 más","show_more_plural":"Mostrar %s más","start_quiz":"Vamonos!","kick_member_confirmation":"Será el asistente '<span id=\"nickName\"></span>' ser retirado de la sesión?","add_kicked_member_to_ban_list":"Desterrar definitivamente los apodos"},"questions":{"enter_question_here":"Introduzca su pregunta aquí","format":"Formato","edit":"Editar","preview":"Avance","single_choice_question":"Una única opción","multiple_choice_question":"Opción multiple","survey_question":"Encuesta","ranged_question":"Pregunta de examen y respuestas"},"quiz_summary":{"summary":"Resumen","quiz_name":"Nombre de la prueba","quiz_url":"URL para los asistentes","question_amount":"Cantidad de todas las preguntas","validation_question_group":"Validación de la prueba completa","successful":"Exitoso","failed":"Ha fallado","correct":"Correcto","wrong":"Incorrecto","question":"Pregunta","text":"Texto","type":"Tipo","answer":"Responder","answer_plural":"Respuestas","timer":"Cuenta regresiva","second":"Segundo","second_plural":"Segundos","validation":"Validación","validation_errors":{"types":{"question":"Pregunta","answerOption":"Responder"},"reasons":{"question_text_too_small":"El texto de la pregunta es demasiado corta","question_text_too_long":"El texto de la pregunta es demasiado largo","timer_too_small":"El contador de tiempo es demasiado corto","timer_too_big":"El contador de tiempo es demasiado largo","no_valid_answers":"Debe haber al menos una respuesta correcta","one_valid_answer_required":"Debe haber exactamente una respuesta correcta","no_valid_answer_required":"No existen respuestas correctas permitidos","invalid_range":"La distancia mínima debe ser menor que el rango máximo","answer_text_empty":"El texto de la respuesta no se le permite estar vacío"}},"edit_quiz":"Editar concurso","start_quiz":"Inicio cuestionario"},"theme_switcher":{"set_theme":"Elegir un tema para todos los asistentes","select_a_theme_title":"Elegir el tema","themes":{"default":{"name":"ARSnova.click","description":"La primera y principal tema de ARSnova.click"},"dark":{"name":"Versión oscura","description":"Fondo oscuro con bajo contraste"},"elegant":{"name":"Elegante","description":"Elegante tema para Quizzers sofisticados"},"thm":{"name":"THM","description":"Diseño Corporativo de la Universidad de Ciencias Aplicadas (THM)"},"arsnova":{"name":"ARSnova","description":"Ya sabes Ars Nova? Sentirse como en casa!"}}},"timer":{"set_countdown":"Ajuste de cuenta atrás","second":"Segundo","second_plural":"Segundos"},"translation":{"translations":"Estas traducciones están disponibles:","i18n_currently_not_available":"I18n actualmente no está disponible!","beta":"Bêta"},"voting":{"question":"Pregunta","send":"Enviar","seconds_left":"1 segundo a la izquierda!","seconds_left_plural":"__value__ segundos en el reloj"}},"plugins":{"markdown_bar":{"visible_text":"Texto visible","link_text":"Texto del enlace","link_destination":"Destino del enlace","tooltip":{"info":"Información","bold":"Negrita","heading":"Titular","hyperlink":"Hiperenlace","unordered_list":"Lista desordenada","ordered_list":"Lista ordenada","latex":"LaTex Markup","code":"Code Markup","citation":"Citación","image":"Imagen","youtube":"YouTube","vimeo":"Vimeo"},"info_content":"You can use <a target='_blank' class='hyperlink' href='https://en.wikipedia.org/wiki/Markdown'>Markdown</a> markup for your text in ARSnova.click. Frequently used markup options are available via the button bar which is visible on all supported input fields. Additionally ARSnova.click supports <a target='_blank' class='hyperlink' href='https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet'>GitHub Flavored Markdown</a>"},"sound":{"title":"Music Quiz","volume":"Volumen","inactive":"El sonido es inactiva","active":"El sonido es activa"},"splashscreen":{"error":{"title":"Notificación","set_text_error":"El texto de la pantalla de bienvenida de error sólo puede establecerse después de que se ha prestado!","error_messages":{"Internal Server Error":"Error de servidor interno","update_failed":"El estado de la cuestión no.","session_exists":"Esta sesión ya existe!","session_not_exists":"Esta sesión no existe","hashtag_exists":"Este hashtag ya existe!","session_not_available":"La sesión no está actualmente disponible para unirse","private_browsing":"If you use ARSnova.click in private browsing you can only join a quiz as an attendee. Unfortunately your browser seems to reject any write access to the local storage. Please use ARSnova.click only via a normal browser tab. Your anonymity will be respected even without using the private mode.","kicked_from_quiz":"Usted ha sido expulsado de la prueba!","export_failed":"No se pudo exportar! - %s","not_authorized":"O bien no hay prueba o que no tiene acceso de escritura","maximum_answer_options_exceeded":"El número máximo de posibles opciones de respuesta superó","hashtag_not_found":"No existe el hashtag con la clave dada","member_not_found":"Miembro no encontrado","duplicate_response":"El usuario ya ha dado una respuesta","answeroption_not_found":"No hay ninguna opción de respuesta con el número de opción respuesta dada","response_timeout":"La respuesta se da fuera del rango de tiempo","insert_leaderboard_failed":"Error al añadir la respuesta se establece en la tabla de posiciones","session_closed":"La sesión se ha cerrado cuestionario","invalid_data":"Los archivos importados son corruptos o el acceso es denegado!"}}}}});
TAPi18n._registerServerTranslator("es", namespace);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"fr.i18n.json":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// i18n/fr.i18n.json                                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n.languages_names["fr"] = ["French (France)","Français"];
if(_.isUndefined(TAPi18n.translations["fr"])) {
  TAPi18n.translations["fr"] = {};
}

if(_.isUndefined(TAPi18n.translations["fr"][namespace])) {
  TAPi18n.translations["fr"][namespace] = {};
}

_.extend(TAPi18n.translations["fr"][namespace], {"global":{"arsnova_slogan":"Questionnaires pour tout le monde et tout","back":"Arrière","next":"Prochain","delete":"Effacer","save":"Sauvegarder","abort":"Avorter","close_window":"Fermer la fenêtre"},"region":{"footer":{"go_to":"Aller à: ","show-more":{"show-more-elements":"Toutes les options disponibles:","onText":"Activé","offText":"Désactivé"},"footer_bar":{"about":"Sur","home":"Accueil","tos":"Conditions d'utilisation","imprint":"Imprimer","data_privacy":"Confidentialité des données","languages":"Langues","style":"Style","import":"Importer","info":"Infos","reading-confirmation":"Confirmation de lecture","fullscreen":"Plein écran","show_more":"Plus","sound":"Sonner","qr_code":"QR Code"},"about":{"title":"About the quiz app","declaration":"A little bit <a href='https://getkahoot.com' target='_blank'>Kahoot!</a>, <br />a little bit <a href='https://arsnova.eu/' target='_blank'>ARSnova</a>!","ars":"First one is gamificated and the second one designed for educational use. Both are an <a href='https://en.wikipedia.org/wiki/Audience_Response_System' target='_blank'>Audience Response System (ARS)</a>.","developed_by":"Inspired by <a href='https://getkahoot.com' target='_blank'>Kahoot!</a> a <a href='http://www.scrumhub.com' target='_blank'>Scrum-Team</a> of Bachelor and Master students of the <a href='http://www.thm.de/site/' target='_blank'>TH Mittelhessen</a> designed and developed in only 10 days this <a href='https://en.wikipedia.org/wiki/Gamification' target='_blank'>gamificated</a> alternative to our ARSnova-Flagship <a href='https://arsnova.eu/' target='_blank'>arsnova.eu</a>.","met_requirements":"Requirements which ARSnova.click has already met:","requirements":{"1":"Absolute data privacy: No personal files on the server. All quiz data is located at the <a href='http://www.w3schools.com/html/html5_webstorage.asp' target='_blank'>HTML5 Local Storage</a> of the quiz owner.","2":"No registration, no installation, no costs at all","3":"Same landing page for both roles: quiz master and attendee","4":"Anyone can create quizzes: immediately and as much as you like!","5":"Extreme easy to use and beamer friendly user interface","6":"<a href='https://en.wikipedia.org/wiki/TeX' target='_blank'>TeX</a>-Formulas and text formatting with <a href='https://guides.github.com/features/mastering-markdown/' target='_blank'>Markdown</a> in questions and answer options","7":"One dialog fits everything: As many answer options you like with multiple choice, single choice and surveys.","8":"Edutainment: Have fun during learning with a live competition against the clock and the other players with sound effects.","9":"<a href='https://en.wikipedia.org/wiki/Responsive_Webdesign' target='_blank'>Responsive Web design</a>: From the smart phone to the wide screen - the design adapts thanks to <a href='http://getbootstrap.com/' target='_blank'>Bootstrap</a>","10":"The bleading edge in modern web technologies: <a href='https://www.meteor.com' target='_blank'>Meteor</a>","11":"<a href='https://git.thm.de/arsnova/arsnova.click/' target='_blank'>Open Source</a>"},"manual":{"title":"Manual?","text":{"1":"You won't need that!","2":"Simply type in the name of the quiz. The buttons will discolour as soon as you've typed in the name of an active quiz (Join now!) or you can create a new quiz with the entered name (Make a new one!).","3":"Now it is as simple as: Clicking. Looking. Quizzing."}}},"tos":{"title":"Terms of Service","declaration":"Everyone is allowed to use the quiz app ARSnova.click for their own purposes as long as the user does not infringe German or European law.","license":{"title":"License","text":"ARSnova.click is a free webservice (Software as a Service). The software is <a href='https://git.thm.de/arsnova/arsnova.click/' target='_blank'>Open Source</a> und is distributed under the <a href='http://www.gnu.org/licenses/gpl-3.0-standalone.html' target='_blank'>GNU General Public License Version 3</a>."},"warranty":{"title":"Warranty","text":"We are trying to maintain the online service of ARSnova.click reliable but we cannot guarantee that. The quiz files are located exclusively in the local browser storage of the quiz owner. We do not give any legal responsibility for any data loss for example via deleting the local browser storage or by illegal usage of the service."}},"data_privacy":{"title":"Data Privacy","scope":"Scope","declaration":"This privacy statement explains to users of ARSnova.click the nature, scope and purpose of the usage of personal data by the responsible provider. The legal basis of this privacy policy can be found in the German Bundesdatenschutzgesetz (BDSG) and the German Telemediengesetz (TMG).","app_data":{"title":"Application data","text":"All quiz questions and their answer options are held by the local browser storage of the quiz owner."},"access_data":{"title":"Access data","text":"Besides web server log files, no personal access data is stored."},"logfiles":{"title":"Webserver logfiles","text":"The provider collects log files about every access to the ARSnova.click system in so-called log files. The provider uses the data exclusively for statistical purposes, for the purpose of operation, security and the optimization of the service. The provider reserves the right to check the log data if there is a reasonable suspicion of unlawful use due to concrete indications."},"3rdparty":{"title":"3rd party services","text":"In quizzes third party services or content, such as videos from YouTube and Vimeo or graphics can be included from other websites. This requires that the provider of such content percive the user's IP address. Without the IP address the content can not be sent to the browser."},"cookies":{"title":"Cookies","text":"Cookies are small files that make it possible to save specific (related to the device) information of the user inside the access device. The offer ARSnova.click uses cookies to observe statistical data of website's usage by Piwik (see below) to be able to detect and analyze them in order to improve the offer. The user can influence the use of cookies. Most browsers have an option to limit the storage and usage of cookies or prevent the usage of cookies completely."},"piwik":{"title":"Piwik","text":"This offer uses Piwik, an open source software for statistical analysis of traffic, see <a href='http://piwik.org/' target='_blank'>piwik.org</a>. Piwik uses cookies, which are stored on the computer of the user and allow the analysis of your use of the website. The information generated by the cookie about your use of this service is stored on the provider's server in Germany. The IP address is anonymized immediately after processing and before the storage. The user can refuse the use of cookies by changing the settings of their browser software."}},"imprint":{"title":"Imprint","provider":{"title":"Service provider","text":{"1":"The operation of the web app ARSnova.click is a free service of the TransMIT-Gesellschaft für Technologietransfer mbH, Projektbereich für mobile Anwendungen.","2":"c/o THM – Technische Hochschule Mittelhessen","3":"Fachbereich MNI – Mathematik, Naturwissenschaften und Informatik","4":"Prof. Dr. Klaus Quibeldey-Cirkel","5":"Lehrstuhl für Softwaretechnik","6":"Wiesenstraße 14","7":"D-35390 Gießen","8":"Telefon: +49 641 309 – 24 50","9":"E-Mail: <a href='mailto:klaus.quibeldey-cirkel@transmit.de' class='text-light'>klaus.quibeldey-cirkel@transmit.de</a>","10":"Sitz der Gesellschaft: Gießen","11":"Website: <a href='https://www.transmit.de' class='text-light'>https://www.transmit.de</a>","12":"Rechtsform: GmbH","13":"Amtsgericht: Gießen HRB 3036","14":"USt-IdNr.: DE 188 685 037"}}}},"header":{"new_question":"Nouvelle question","reset":"Réinitialiser","yes":"Oui","no":"Non","reset_session_confirmation":{"title":"Exit the quiz?","text":{"1":"On resetting the session, all students will be redirected to the landing page. The current ranking and the quiz-lobby will be deleted. The created Question(s), including the assigned answer options and timer configurations, are stored in the local storage of your browser. Except the quiz name, all data of this session will be removed from the server.","2":"Proceed?"}}}},"view":{"answeroptions":{"answeroptiontext_placeholder":"Option de réponse nécessaire","correct":"Correct","wrong":"Faux"},"choose_nickname":{"enter_nickname":"Prendre un surnom","enter_nickname_here":"Entrez votre nom ici","nickname_na_popup":"Ce nom n'est pas disponible!","nickname_blacklist_popup":"Ce nom est (en raison de son sens) non disponible!","nickname_too_long":"Le nom est trop long","nickname_too_short":"Le nom est trop court"},"hashtag_management":{"enter_quiz_name":"Entrez le nom du jeu-questionnaire ici","join_session":"Inscrivez-vous maintenant!","edit_session":"Modifier","reenter_session":"Ouvrir","create_session":"Faire un nouveau!","quiz_management":"Questionnaires stockées","available_sessions":"Ces questionnaires sont stockés dans votre navigateur:","session_management":"Management Quiz","import":"Importer quiz","delete_session":"Effacer Quiz","delete_session_confirmation":"Si le '<span id=\"session_name\"></span>' quiz définitivement supprimé?","export":"Exporter quiz","valid_question":"Questionnaire valide","invalid_question":"Quiz non valide"},"leaderboard":{"title":{"single_question":"Question __questionId__ - Les réponses correctes de...","all_questions":"Les réponses correctes de..."},"no_attendee_correct":"Personne n'a répondu correctement à cette question","no_attendee_correct_global":"Personne n'a répondu correctement à toutes les questions","question":"Question","second":"Seconde","second_plural":"Secondes","show_more":"Voir 1 plus","show_more_plural":"Voir %s plus","show_less":"Montre moins"},"liveResults":{"question":"Question","ranking":"Classement","reading_confirmation":"Confirmation de lecture","show_more":"Voir 1 plus","show_more_plural":"Voir %s plus","complete_correct":"Tout correct","complete_wrong":"Tout mauvais","back_to_lobby":"Retour à l'entrée","global_ranking":"Classement mondial","show_question":"Voir question","show_question_plural":"Voir question","start_round":"Démarrer Quiz","start_round_plural":"Commencez tour","confirm_read":"J'ai lu la question!","game_over":"Jeu terminé","countdown":"Compte à rebours","answer_option":"Répondre"},"lobby":{"title":"Quiz Lobby","yes":"Oui","no":"Non","ready":"Prêt pour Quiz","show_more":"Voir 1 plus","show_more_plural":"Voir %s plus","start_quiz":"Allons-y!","kick_member_confirmation":"Si les participants <span id=\"nickName\"></span> être retirés du jeu-questionnaire?","add_kicked_member_to_ban_list":"Bannir définitivement les surnoms"},"questions":{"enter_question_here":"Entrez votre question ici","format":"Format","edit":"Modifier","preview":"Aperçu","single_choice_question":"Choix unique","multiple_choice_question":"Choix multiple","survey_question":"Enquête","ranged_question":"Question Quiz et réponses"},"quiz_summary":{"summary":"Résumé","quiz_name":"Nom du quiz","quiz_url":"URL pour les participants","question_amount":"Montant de toutes les questions","validation_question_group":"Validation pour le quiz complet","successful":"Réussi","failed":"Échoué","correct":"Correct","wrong":"Faux","question":"Question","text":"Texte","type":"Type","answer":"Répondre","answer_plural":"Réponses","timer":"Compte à rebours","second":"Seconde","second_plural":"Secondes","validation":"Validation","validation_errors":{"types":{"question":"Question","answerOption":"Répondre"},"reasons":{"question_text_too_small":"Le texte de la question est trop courte","question_text_too_long":"Le texte de la question est trop long","timer_too_small":"La minuterie est trop court","timer_too_big":"La minuterie est trop long","no_valid_answers":"Il doit y avoir au moins une bonne réponse","one_valid_answer_required":"Il doit y avoir exactement une réponse correcte","no_valid_answer_required":"Il n'y a pas de réponses correctes permis","invalid_range":"La gamme minimale doit être inférieure à la portée maximale","answer_text_empty":"Le texte de la réponse ne peut pas être vide"}},"edit_quiz":"Modifier quiz","start_quiz":"Démarrer quiz"},"theme_switcher":{"set_theme":"Choisissez un thème pour tous les participants","select_a_theme_title":"Choisissez le thème","themes":{"default":{"name":"ARSnova.click","description":"Le premier et le principal thème de ARSnova.click"},"dark":{"name":"Version sombre","description":"Fond sombre avec un faible contraste"},"elegant":{"name":"Élégant","description":"Thème élégant pour quizzers sophistiqués"},"thm":{"name":"THM","description":"Corporate Design de l'Université des sciences appliquées (THM)"},"arsnova":{"name":"ARSnova","description":"Vous connaissez ARS nova? Sentez-vous la maison!"}}},"timer":{"set_countdown":"Définir le compte à rebours","second":"Seconde","second_plural":"Secondes"},"translation":{"translations":"Ces traductions sont disponibles:","i18n_currently_not_available":"I18n est actuellement pas disponible!","beta":"Beta"},"voting":{"question":"Question","send":"Envoyer","seconds_left":"1 Secondes gauche!","seconds_left_plural":"__value__ Secondes gauche"}},"plugins":{"markdown_bar":{"visible_text":"Visible texte","link_text":"Le texte du lien","link_destination":"Lien cible","tooltip":{"info":"Info","bold":"Audacieux","heading":"Gros titre","hyperlink":"Hyperlink","unordered_list":"Liste non ordonnée","ordered_list":"Liste ordonnée","latex":"LaTex Markup","code":"Code Markup","citation":"Citation","image":"Image","youtube":"YouTube","vimeo":"Vimeo"},"info_content":"You can use <a target='_blank' class='hyperlink' href='https://en.wikipedia.org/wiki/Markdown'>Markdown</a> markup for your text in ARSnova.click. Frequently used markup options are available via the button bar which is visible on all supported input fields. Additionally ARSnova.click supports <a target='_blank' class='hyperlink' href='https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet'>GitHub Flavored Markdown</a>"},"sound":{"title":"Quiz Musique","volume":"Volume","inactive":"Le son est inactif","active":"Le son est actif"},"splashscreen":{"error":{"title":"Notification","set_text_error":"Le texte de l'écran erreur de démarrage ne peut être réglé après qu'il a été rendu!","error_messages":{"Internal Server Error":"Erreur interne du serveur","update_failed":"La mise à jour de la question n'a pas.","session_exists":"Cette session existe déjà!","session_not_exists":"N'existe pas Cette session","hashtag_exists":"Ce hashtag existe déjà!","session_not_available":"Session est actuellement pas disponible pour rejoindre","private_browsing":"If you use ARSnova.click in private browsing you can only join a quiz as an attendee. Unfortunately your browser seems to reject any write access to the local storage. Please use ARSnova.click only via a normal browser tab. Your anonymity will be respected even without using the private mode.","kicked_from_quiz":"Vous avez été expulsé du jeu-questionnaire!","export_failed":"Impossible d'exporter! - %s","not_authorized":"Soit il n'y a pas questionnaire ou vous n'avez pas accès en écriture","maximum_answer_options_exceeded":"Nombre maximum d'options possibles de réponse dépassée","hashtag_not_found":"Aucune hashtag avec la clé donnée","member_not_found":"Membre introuvable","duplicate_response":"L'utilisateur a déjà donné une réponse","answeroption_not_found":"Il n'y a aucune option de réponse avec la answerOptionNumber donnée","response_timeout":"La réponse a été donnée hors de la plage de temps","insert_leaderboard_failed":"Erreur lors de l'ajout d'une réponse réglée sur leaderboard","session_closed":"La session quiz a été fermé","invalid_data":"Les fichiers importés sont corrompus ou l'accès est refusé!"}}}}});
TAPi18n._registerServerTranslator("fr", namespace);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"shared":{"answeroptions.js":["meteor/meteor","meteor/aldeed:simple-schema","/lib/answeroptions/collection.js","/lib/eventmanager/collection.js","/lib/hashtags/collection.js",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// shared/answeroptions.js                                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _meteor = require('meteor/meteor');                                                                               // 18
                                                                                                                      //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                     // 19
                                                                                                                      //
var _collection = require('/lib/answeroptions/collection.js');                                                        // 20
                                                                                                                      //
var _collection2 = require('/lib/eventmanager/collection.js');                                                        // 21
                                                                                                                      //
var _collection3 = require('/lib/hashtags/collection.js');                                                            // 22
                                                                                                                      //
_meteor.Meteor.methods({                                                                                              // 24
	'AnswerOptionCollection.addOption': function () {                                                                    // 25
		function AnswerOptionCollectionAddOption(_ref) {                                                                    // 25
			var hashtag = _ref.hashtag;                                                                                        //
			var questionIndex = _ref.questionIndex;                                                                            //
			var answerText = _ref.answerText;                                                                                  //
			var answerOptionNumber = _ref.answerOptionNumber;                                                                  //
			var isCorrect = _ref.isCorrect;                                                                                    //
                                                                                                                      //
			new _aldeedSimpleSchema.SimpleSchema({                                                                             // 26
				hashtag: _collection3.hashtagSchema,                                                                              // 27
				questionIndex: _collection2.questionIndexSchema,                                                                  // 28
				answerText: _collection.answerTextSchema,                                                                         // 29
				answerOptionNumber: _collection.answerOptionNumberSchema,                                                         // 30
				isCorrect: _collection.isCorrectSchema                                                                            // 31
			}).validate({ hashtag: hashtag, questionIndex: questionIndex, answerText: answerText, answerOptionNumber: answerOptionNumber, isCorrect: isCorrect });
                                                                                                                      //
			if (_collection.AnswerOptionCollection.find({                                                                      // 34
				hashtag: hashtag,                                                                                                 // 35
				questionIndex: questionIndex                                                                                      // 36
			}).count() > 25) {                                                                                                 //
				throw new _meteor.Meteor.Error('AnswerOptionCollection.addOption', 'maximum_answer_options_exceeded');            // 38
			}                                                                                                                  //
			var answerOptionDoc = _collection.AnswerOptionCollection.findOne({                                                 // 40
				hashtag: hashtag,                                                                                                 // 41
				questionIndex: questionIndex,                                                                                     // 42
				answerOptionNumber: answerOptionNumber                                                                            // 43
			});                                                                                                                //
			if (!answerOptionDoc) {                                                                                            // 45
				_collection.AnswerOptionCollection.insert({                                                                       // 46
					hashtag: hashtag,                                                                                                // 47
					questionIndex: questionIndex,                                                                                    // 48
					answerText: answerText,                                                                                          // 49
					answerOptionNumber: answerOptionNumber,                                                                          // 50
					isCorrect: isCorrect                                                                                             // 51
				});                                                                                                               //
				_collection2.EventManagerCollection.update({ hashtag: hashtag }, {                                                // 53
					$push: {                                                                                                         // 54
						eventStack: {                                                                                                   // 55
							key: "AnswerOptionCollection.addOption",                                                                       // 56
							value: {                                                                                                       // 57
								questionIndex: questionIndex,                                                                                 // 58
								answerOptionNumber: answerOptionNumber                                                                        // 59
							}                                                                                                              //
						}                                                                                                               //
					}                                                                                                                //
				});                                                                                                               //
			} else {                                                                                                           //
				_collection.AnswerOptionCollection.update(answerOptionDoc._id, {                                                  // 65
					$set: {                                                                                                          // 66
						answerText: answerText,                                                                                         // 67
						isCorrect: isCorrect                                                                                            // 68
					}                                                                                                                //
				});                                                                                                               //
				_collection2.EventManagerCollection.update({ hashtag: hashtag }, {                                                // 71
					$push: {                                                                                                         // 72
						eventStack: {                                                                                                   // 73
							key: "AnswerOptionCollection.updateOption",                                                                    // 74
							value: {                                                                                                       // 75
								questionIndex: questionIndex,                                                                                 // 76
								answerOptionNumber: answerOptionNumber                                                                        // 77
							}                                                                                                              //
						}                                                                                                               //
					}                                                                                                                //
				});                                                                                                               //
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return AnswerOptionCollectionAddOption;                                                                             //
	}(),                                                                                                                 //
	'AnswerOptionCollection.deleteOption': function () {                                                                 // 84
		function AnswerOptionCollectionDeleteOption(_ref2) {                                                                // 84
			var hashtag = _ref2.hashtag;                                                                                       //
			var questionIndex = _ref2.questionIndex;                                                                           //
			var answerOptionNumber = _ref2.answerOptionNumber;                                                                 //
                                                                                                                      //
			new _aldeedSimpleSchema.SimpleSchema({                                                                             // 85
				hashtag: _collection3.hashtagSchema,                                                                              // 86
				questionIndex: _collection2.questionIndexSchema,                                                                  // 87
				answerOptionNumber: _collection.answerOptionNumberSchema                                                          // 88
			}).validate({ hashtag: hashtag, questionIndex: questionIndex, answerOptionNumber: answerOptionNumber });           //
                                                                                                                      //
			var query = {                                                                                                      // 91
				hashtag: hashtag,                                                                                                 // 92
				questionIndex: questionIndex,                                                                                     // 93
				answerOptionNumber: answerOptionNumber                                                                            // 94
			};                                                                                                                 //
			if (answerOptionNumber < 0) {                                                                                      // 96
				delete query.answerOptionNumber;                                                                                  // 97
				_collection.AnswerOptionCollection.remove(query);                                                                 // 98
				_collection.AnswerOptionCollection.update({ hashtag: hashtag, questionIndex: { $gt: questionIndex } }, { $inc: { questionIndex: -1 } }, { multi: true });
			} else {                                                                                                           //
				_collection.AnswerOptionCollection.remove(query);                                                                 // 105
			}                                                                                                                  //
			_collection2.EventManagerCollection.update({ hashtag: hashtag }, {                                                 // 107
				$push: {                                                                                                          // 108
					eventStack: {                                                                                                    // 109
						key: "AnswerOptionCollection.deleteOption",                                                                     // 110
						value: {                                                                                                        // 111
							questionIndex: questionIndex,                                                                                  // 112
							answerOptionNumber: answerOptionNumber                                                                         // 113
						}                                                                                                               //
					}                                                                                                                //
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return AnswerOptionCollectionDeleteOption;                                                                          //
	}(),                                                                                                                 //
	'AnswerOptionCollection.updateAnswerTextAndIsCorrect': function () {                                                 // 119
		function AnswerOptionCollectionUpdateAnswerTextAndIsCorrect(_ref3) {                                                // 119
			var hashtag = _ref3.hashtag;                                                                                       //
			var questionIndex = _ref3.questionIndex;                                                                           //
			var answerOptionNumber = _ref3.answerOptionNumber;                                                                 //
			var answerText = _ref3.answerText;                                                                                 //
			var isCorrect = _ref3.isCorrect;                                                                                   //
                                                                                                                      //
			new _aldeedSimpleSchema.SimpleSchema({                                                                             // 120
				hashtag: _collection3.hashtagSchema,                                                                              // 121
				questionIndex: _collection2.questionIndexSchema,                                                                  // 122
				answerText: _collection.answerTextSchema,                                                                         // 123
				answerOptionNumber: _collection.answerOptionNumberSchema,                                                         // 124
				isCorrect: _collection.isCorrectSchema                                                                            // 125
			}).validate({ hashtag: hashtag, questionIndex: questionIndex, answerOptionNumber: answerOptionNumber, answerText: answerText, isCorrect: isCorrect });
                                                                                                                      //
			var answerOptionDoc = _collection.AnswerOptionCollection.findOne({                                                 // 128
				hashtag: hashtag,                                                                                                 // 129
				questionIndex: questionIndex,                                                                                     // 130
				answerOptionNumber: answerOptionNumber                                                                            // 131
			});                                                                                                                //
			_collection.AnswerOptionCollection.update(answerOptionDoc._id, {                                                   // 133
				$set: { answerText: answerText, isCorrect: isCorrect }                                                            // 134
			});                                                                                                                //
			_collection2.EventManagerCollection.update({ hashtag: hashtag }, {                                                 // 136
				$push: {                                                                                                          // 137
					eventStack: {                                                                                                    // 138
						key: "AnswerOptionCollection.updateAnswerTextAndIsCorrect",                                                     // 139
						value: {                                                                                                        // 140
							questionIndex: questionIndex,                                                                                  // 141
							answerOptionNumber: answerOptionDoc                                                                            // 142
						}                                                                                                               //
					}                                                                                                                //
				}                                                                                                                 //
			});                                                                                                                //
			return {                                                                                                           // 147
				hashtag: hashtag, questionIndex: questionIndex, answerOptionNumber: answerOptionNumber, answerText: answerText, isCorrect: isCorrect
			};                                                                                                                 //
		}                                                                                                                   //
                                                                                                                      //
		return AnswerOptionCollectionUpdateAnswerTextAndIsCorrect;                                                          //
	}()                                                                                                                  //
}); /*                                                                                                                //
     * This file is part of ARSnova Click.                                                                            //
     * Copyright (C) 2016 The ARSnova Team                                                                            //
     *                                                                                                                //
     * ARSnova Click is free software: you can redistribute it and/or modify                                          //
     * it under the terms of the GNU General Public License as published by                                           //
     * the Free Software Foundation, either version 3 of the License, or                                              //
     * (at your option) any later version.                                                                            //
     *                                                                                                                //
     * ARSnova Click is distributed in the hope that it will be useful,                                               //
     * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                 //
     * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                  //
     * GNU General Public License for more details.                                                                   //
     *                                                                                                                //
     * You should have received a copy of the GNU General Public License                                              //
     * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                       //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"banned_nicks.js":["meteor/meteor","meteor/aldeed:simple-schema","/lib/member_list/collection.js","/lib/banned_nicks/collection.js",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// shared/banned_nicks.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _meteor = require('meteor/meteor');                                                                               // 18
                                                                                                                      //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                     // 19
                                                                                                                      //
var _collection = require('/lib/member_list/collection.js');                                                          // 20
                                                                                                                      //
var _collection2 = require('/lib/banned_nicks/collection.js');                                                        // 21
                                                                                                                      //
/*                                                                                                                    //
 * This file is part of ARSnova Click.                                                                                //
 * Copyright (C) 2016 The ARSnova Team                                                                                //
 *                                                                                                                    //
 * ARSnova Click is free software: you can redistribute it and/or modify                                              //
 * it under the terms of the GNU General Public License as published by                                               //
 * the Free Software Foundation, either version 3 of the License, or                                                  //
 * (at your option) any later version.                                                                                //
 *                                                                                                                    //
 * ARSnova Click is distributed in the hope that it will be useful,                                                   //
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                     //
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                      //
 * GNU General Public License for more details.                                                                       //
 *                                                                                                                    //
 * You should have received a copy of the GNU General Public License                                                  //
 * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                           //
                                                                                                                      //
_meteor.Meteor.methods({                                                                                              // 23
  'BannedNicksCollection.insert': function () {                                                                       // 24
    function BannedNicksCollectionInsert(nick) {                                                                      // 24
      new _aldeedSimpleSchema.SimpleSchema({ userNick: _collection.userNickSchema }).validate({ userNick: nick });    // 25
                                                                                                                      //
      _collection2.BannedNicksCollection.insert({ userNick: nick });                                                  // 27
    }                                                                                                                 //
                                                                                                                      //
    return BannedNicksCollectionInsert;                                                                               //
  }()                                                                                                                 //
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"eventmanager.js":["meteor/meteor","meteor/aldeed:simple-schema","/lib/eventmanager/collection.js","/lib/hashtags/collection.js",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// shared/eventmanager.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _meteor = require('meteor/meteor');                                                                               // 18
                                                                                                                      //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                     // 19
                                                                                                                      //
var _collection = require('/lib/eventmanager/collection.js');                                                         // 20
                                                                                                                      //
var _collection2 = require('/lib/hashtags/collection.js');                                                            // 21
                                                                                                                      //
/*                                                                                                                    //
 * This file is part of ARSnova Click.                                                                                //
 * Copyright (C) 2016 The ARSnova Team                                                                                //
 *                                                                                                                    //
 * ARSnova Click is free software: you can redistribute it and/or modify                                              //
 * it under the terms of the GNU General Public License as published by                                               //
 * the Free Software Foundation, either version 3 of the License, or                                                  //
 * (at your option) any later version.                                                                                //
 *                                                                                                                    //
 * ARSnova Click is distributed in the hope that it will be useful,                                                   //
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                     //
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                      //
 * GNU General Public License for more details.                                                                       //
 *                                                                                                                    //
 * You should have received a copy of the GNU General Public License                                                  //
 * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                           //
                                                                                                                      //
_meteor.Meteor.methods({                                                                                              // 23
	'EventManagerCollection.setSessionStatus': function () {                                                             // 24
		function EventManagerCollectionSetSessionStatus(hashtag, sessionStatus) {                                           // 24
			new _aldeedSimpleSchema.SimpleSchema({                                                                             // 25
				hashtag: _collection2.hashtagSchema,                                                                              // 26
				sessionStatus: _collection.sessionStatusSchema                                                                    // 27
			}).validate({ hashtag: hashtag, sessionStatus: sessionStatus });                                                   //
                                                                                                                      //
			var query = {};                                                                                                    // 30
			if (_meteor.Meteor.isServer) {                                                                                     // 31
				query.hashtag = hashtag;                                                                                          // 32
			}                                                                                                                  //
			_collection.EventManagerCollection.update(query, {                                                                 // 34
				$set: { sessionStatus: sessionStatus },                                                                           // 35
				$push: {                                                                                                          // 36
					eventStack: {                                                                                                    // 37
						key: "EventManagerCollection.setSessionStatus",                                                                 // 38
						value: { sessionStatus: sessionStatus }                                                                         // 39
					}                                                                                                                //
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return EventManagerCollectionSetSessionStatus;                                                                      //
	}(),                                                                                                                 //
	'EventManagerCollection.showReadConfirmedForIndex': function () {                                                    // 44
		function EventManagerCollectionShowReadConfirmedForIndex(hashtag, readingConfirmationIndex) {                       // 44
			new _aldeedSimpleSchema.SimpleSchema({                                                                             // 45
				hashtag: _collection2.hashtagSchema,                                                                              // 46
				readingConfirmationIndex: _collection.readingConfirmationIndexSchema                                              // 47
			}).validate({ hashtag: hashtag, readingConfirmationIndex: readingConfirmationIndex });                             //
                                                                                                                      //
			_collection.EventManagerCollection.update({ hashtag: hashtag }, {                                                  // 50
				$set: { readingConfirmationIndex: readingConfirmationIndex },                                                     // 51
				$push: {                                                                                                          // 52
					eventStack: {                                                                                                    // 53
						key: "EventManagerCollection.showReadConfirmedForIndex",                                                        // 54
						value: { readingConfirmationIndex: readingConfirmationIndex }                                                   // 55
					}                                                                                                                //
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return EventManagerCollectionShowReadConfirmedForIndex;                                                             //
	}(),                                                                                                                 //
	'EventManagerCollection.setActiveQuestion': function () {                                                            // 60
		function EventManagerCollectionSetActiveQuestion(hashtag, questionIndex) {                                          // 60
			new _aldeedSimpleSchema.SimpleSchema({                                                                             // 61
				hashtag: _collection2.hashtagSchema,                                                                              // 62
				questionIndex: _collection.questionIndexSchema                                                                    // 63
			}).validate({ hashtag: hashtag, questionIndex: questionIndex });                                                   //
                                                                                                                      //
			_collection.EventManagerCollection.update({ hashtag: hashtag }, {                                                  // 66
				$set: {                                                                                                           // 67
					questionIndex: questionIndex,                                                                                    // 68
					readingConfirmationIndex: questionIndex                                                                          // 69
				},                                                                                                                //
				$push: {                                                                                                          // 71
					eventStack: {                                                                                                    // 72
						key: "EventManagerCollection.setActiveQuestion",                                                                // 73
						value: {                                                                                                        // 74
							questionIndex: questionIndex,                                                                                  // 75
							readingConfirmationIndex: questionIndex                                                                        // 76
						}                                                                                                               //
					}                                                                                                                //
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return EventManagerCollectionSetActiveQuestion;                                                                     //
	}(),                                                                                                                 //
	'EventManagerCollection.clear': function () {                                                                        // 82
		function EventManagerCollectionClear(hashtag) {                                                                     // 82
			new _aldeedSimpleSchema.SimpleSchema({ hashtag: _collection2.hashtagSchema }).validate({ hashtag: hashtag });      // 83
                                                                                                                      //
			_collection.EventManagerCollection.remove({ hashtag: hashtag });                                                   // 85
		}                                                                                                                   //
                                                                                                                      //
		return EventManagerCollectionClear;                                                                                 //
	}(),                                                                                                                 //
	'EventManagerCollection.beforeClear': function () {                                                                  // 87
		function EventManagerCollectionBeforeClear(hashtag) {                                                               // 87
			new _aldeedSimpleSchema.SimpleSchema({ hashtag: _collection2.hashtagSchema }).validate({ hashtag: hashtag });      // 88
                                                                                                                      //
			var query = {};                                                                                                    // 90
			if (_meteor.Meteor.isServer) {                                                                                     // 91
				query.hashtag = hashtag;                                                                                          // 92
			}                                                                                                                  //
			_collection.EventManagerCollection.update(query, {                                                                 // 94
				$push: {                                                                                                          // 95
					eventStack: {                                                                                                    // 96
						key: "EventManagerCollection.beforeClear",                                                                      // 97
						value: {}                                                                                                       // 98
					}                                                                                                                //
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return EventManagerCollectionBeforeClear;                                                                           //
	}(),                                                                                                                 //
	'EventManagerCollection.reset': function () {                                                                        // 103
		function EventManagerCollectionReset(hashtag) {                                                                     // 103
			new _aldeedSimpleSchema.SimpleSchema({ hashtag: _collection2.hashtagSchema }).validate({ hashtag: hashtag });      // 104
                                                                                                                      //
			_collection.EventManagerCollection.update({ hashtag: hashtag }, {                                                  // 106
				$set: {                                                                                                           // 107
					sessionStatus: 1,                                                                                                // 108
					readingConfirmationIndex: -1,                                                                                    // 109
					questionIndex: -1,                                                                                               // 110
					eventStack: [{                                                                                                   // 111
						key: "EventManagerCollection.reset",                                                                            // 113
						value: {                                                                                                        // 114
							sessionStatus: 1,                                                                                              // 115
							readingConfirmationIndex: -1,                                                                                  // 116
							questionIndex: -1                                                                                              // 117
						}                                                                                                               //
					}]                                                                                                               //
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return EventManagerCollectionReset;                                                                                 //
	}(),                                                                                                                 //
	'EventManagerCollection.add': function () {                                                                          // 124
		function EventManagerCollectionAdd(hashtag) {                                                                       // 124
			new _aldeedSimpleSchema.SimpleSchema({ hashtag: _collection2.hashtagSchema }).validate({ hashtag: hashtag });      // 125
                                                                                                                      //
			if (_collection.EventManagerCollection.findOne({ hashtag: hashtag })) {                                            // 127
				throw new _meteor.Meteor.Error('EventManagerCollection.add', 'hashtag_exists');                                   // 128
			}                                                                                                                  //
			_collection.EventManagerCollection.insert({                                                                        // 130
				hashtag: hashtag,                                                                                                 // 131
				sessionStatus: 1,                                                                                                 // 132
				lastConnection: 0,                                                                                                // 133
				readingConfirmationIndex: -1,                                                                                     // 134
				questionIndex: 0,                                                                                                 // 135
				eventStack: [{                                                                                                    // 136
					key: "EventManagerCollection.add",                                                                               // 138
					value: {                                                                                                         // 139
						sessionStatus: 1,                                                                                               // 140
						readingConfirmationIndex: -1,                                                                                   // 141
						questionIndex: 0                                                                                                // 142
					}                                                                                                                //
				}]                                                                                                                //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return EventManagerCollectionAdd;                                                                                   //
	}(),                                                                                                                 //
	'keepalive': function () {                                                                                           // 148
		function keepalive(hashtag) {                                                                                       // 148
			new _aldeedSimpleSchema.SimpleSchema({ hashtag: _collection2.hashtagSchema }).validate({ hashtag: hashtag });      // 149
                                                                                                                      //
			_collection.EventManagerCollection.update({ hashtag: hashtag }, { $set: { lastConnection: new Date().getTime() } });
		}                                                                                                                   //
                                                                                                                      //
		return keepalive;                                                                                                   //
	}()                                                                                                                  //
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"hashtags.js":["meteor/meteor","meteor/aldeed:simple-schema","/lib/answeroptions/collection.js","/lib/member_list/collection.js","/lib/responses/collection.js","/lib/questions/collection.js","/lib/hashtags/collection.js","/lib/eventmanager/collection.js",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// shared/hashtags.js                                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _meteor = require('meteor/meteor');                                                                               // 18
                                                                                                                      //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                     // 19
                                                                                                                      //
var _collection = require('/lib/answeroptions/collection.js');                                                        // 20
                                                                                                                      //
var _collection2 = require('/lib/member_list/collection.js');                                                         // 21
                                                                                                                      //
var _collection3 = require('/lib/responses/collection.js');                                                           // 22
                                                                                                                      //
var _collection4 = require('/lib/questions/collection.js');                                                           // 23
                                                                                                                      //
var _collection5 = require('/lib/hashtags/collection.js');                                                            // 24
                                                                                                                      //
var _collection6 = require('/lib/eventmanager/collection.js');                                                        // 25
                                                                                                                      //
/*                                                                                                                    //
 * This file is part of ARSnova Click.                                                                                //
 * Copyright (C) 2016 The ARSnova Team                                                                                //
 *                                                                                                                    //
 * ARSnova Click is free software: you can redistribute it and/or modify                                              //
 * it under the terms of the GNU General Public License as published by                                               //
 * the Free Software Foundation, either version 3 of the License, or                                                  //
 * (at your option) any later version.                                                                                //
 *                                                                                                                    //
 * ARSnova Click is distributed in the hope that it will be useful,                                                   //
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                     //
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                      //
 * GNU General Public License for more details.                                                                       //
 *                                                                                                                    //
 * You should have received a copy of the GNU General Public License                                                  //
 * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                           //
                                                                                                                      //
_meteor.Meteor.methods({                                                                                              // 27
	'HashtagsCollection.checkPrivateKey': function () {                                                                  // 28
		function HashtagsCollectionCheckPrivateKey(privateKey, hashtag) {                                                   // 28
			_collection5.hashtagsCollectionSchema.validate({ hashtag: hashtag, privateKey: privateKey });                      // 29
                                                                                                                      //
			var doc = _collection5.HashtagsCollection.findOne({                                                                // 31
				hashtag: hashtag,                                                                                                 // 32
				privateKey: privateKey                                                                                            // 33
			});                                                                                                                //
			return Boolean(doc);                                                                                               // 35
		}                                                                                                                   //
                                                                                                                      //
		return HashtagsCollectionCheckPrivateKey;                                                                           //
	}(),                                                                                                                 //
	'HashtagsCollection.addHashtag': function () {                                                                       // 37
		function HashtagsCollectionAddHashtag(sessionConfiguration) {                                                       // 37
			new _aldeedSimpleSchema.SimpleSchema({ hashtag: _collection5.hashtagSchema }).validate({ hashtag: sessionConfiguration.hashtag });
			if (_collection5.HashtagsCollection.findOne({ hashtag: sessionConfiguration.hashtag })) {                          // 39
				throw new _meteor.Meteor.Error('HashtagsCollection.addHashtag', 'session_exists');                                // 40
			}                                                                                                                  //
                                                                                                                      //
			_collection5.HashtagsCollection.insert(sessionConfiguration);                                                      // 43
			_collection6.EventManagerCollection.update({ hashtag: sessionConfiguration.hashtag }, {                            // 44
				$push: {                                                                                                          // 45
					eventStack: {                                                                                                    // 46
						key: "HashtagsCollection.addHashtag",                                                                           // 47
						value: { hashtag: sessionConfiguration.hashtag }                                                                // 48
					}                                                                                                                //
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return HashtagsCollectionAddHashtag;                                                                                //
	}(),                                                                                                                 //
	'HashtagsCollection.setDefaultTheme': function () {                                                                  // 53
		function HashtagsCollectionSetDefaultTheme(hashtag) {                                                               // 53
			var themeName = arguments.length <= 1 || arguments[1] === undefined ? "theme-dark" : arguments[1];                 //
                                                                                                                      //
			new _aldeedSimpleSchema.SimpleSchema({ hashtag: _collection5.hashtagSchema, theme: _collection5.themeSchema }).validate({ hashtag: hashtag, theme: themeName });
                                                                                                                      //
			var queryParam = {};                                                                                               // 56
			if (_meteor.Meteor.isServer) {                                                                                     // 57
				queryParam.hashtag = hashtag;                                                                                     // 58
			}                                                                                                                  //
                                                                                                                      //
			if (!_collection5.HashtagsCollection.findOne(queryParam)) {                                                        // 61
				throw new _meteor.Meteor.Error('HashtagsCollection.setDefaultTheme', 'session_not_exists');                       // 62
			}                                                                                                                  //
			_collection5.HashtagsCollection.update(queryParam, {                                                               // 64
				$set: {                                                                                                           // 65
					theme: themeName                                                                                                 // 66
				}                                                                                                                 //
			});                                                                                                                //
			_collection6.EventManagerCollection.update({ hashtag: hashtag }, {                                                 // 69
				$push: {                                                                                                          // 70
					eventStack: {                                                                                                    // 71
						key: "HashtagsCollection.setDefaultTheme",                                                                      // 72
						value: { hashtag: hashtag, theme: themeName }                                                                   // 73
					}                                                                                                                //
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return HashtagsCollectionSetDefaultTheme;                                                                           //
	}(),                                                                                                                 //
	'HashtagsCollection.updateMusicSettings': function () {                                                              // 78
		function HashtagsCollectionUpdateMusicSettings(doc) {                                                               // 78
			var hashtagDoc = _collection5.HashtagsCollection.findOne({ hashtag: doc.hashtag });                                // 79
                                                                                                                      //
			if (!hashtagDoc) {                                                                                                 // 81
				throw new _meteor.Meteor.Error('HashtagsCollection.updateMusicSettings', 'session_not_exists');                   // 82
			} else {                                                                                                           //
				_collection5.HashtagsCollection.update(hashtagDoc._id, {                                                          // 84
					$set: {                                                                                                          // 85
						musicVolume: doc.musicVolume,                                                                                   // 86
						musicEnabled: doc.musicEnabled,                                                                                 // 87
						musicTitle: doc.musicTitle                                                                                      // 88
					}                                                                                                                //
				});                                                                                                               //
                                                                                                                      //
				_collection6.EventManagerCollection.update({ hashtag: doc.hashtag }, {                                            // 92
					$push: {                                                                                                         // 93
						eventStack: {                                                                                                   // 94
							key: "HashtagsCollection.updateMusicSettings",                                                                 // 95
							value: { hashtag: doc.hashtag }                                                                                // 96
						}                                                                                                               //
					}                                                                                                                //
				});                                                                                                               //
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return HashtagsCollectionUpdateMusicSettings;                                                                       //
	}(),                                                                                                                 //
	'HashtagsCollection.export': function () {                                                                           // 102
		function HashtagsCollectionExport(_ref) {                                                                           // 102
			var hashtag = _ref.hashtag;                                                                                        //
                                                                                                                      //
			new _aldeedSimpleSchema.SimpleSchema({ hashtag: _collection5.hashtagSchema }).validate({ hashtag: hashtag });      // 103
                                                                                                                      //
			if (_meteor.Meteor.isServer) {                                                                                     // 105
				var hashtagDoc = _collection5.HashtagsCollection.findOne({                                                        // 106
					hashtag: hashtag                                                                                                 // 107
				}, {                                                                                                              //
					fields: {                                                                                                        // 109
						_id: 0,                                                                                                         // 110
						privateKey: 0                                                                                                   // 111
					}                                                                                                                //
				});                                                                                                               //
				if (!hashtagDoc) {                                                                                                // 114
					throw new _meteor.Meteor.Error('HashtagsCollection.export', 'hashtag_not_found');                                // 115
				}                                                                                                                 //
				var questionGroupDoc = _collection4.QuestionGroupCollection.findOne({ hashtag: hashtag }, {                       // 117
					fields: {                                                                                                        // 118
						_id: 0                                                                                                          // 119
					}                                                                                                                //
				});                                                                                                               //
				var answerOptionsDoc = _collection.AnswerOptionCollection.find({ hashtag: hashtag }, {                            // 122
					fields: {                                                                                                        // 123
						_id: 0                                                                                                          // 124
					}                                                                                                                //
				}).fetch();                                                                                                       //
				var memberListDoc = _collection2.MemberListCollection.find({ hashtag: hashtag }, {                                // 127
					fields: {                                                                                                        // 128
						_id: 0                                                                                                          // 129
					}                                                                                                                //
				}).fetch();                                                                                                       //
				var responsesDoc = _collection3.ResponsesCollection.find({ hashtag: hashtag }, {                                  // 132
					fields: {                                                                                                        // 133
						_id: 0                                                                                                          // 134
					}                                                                                                                //
				}).fetch();                                                                                                       //
				var exportData = {                                                                                                // 137
					hashtagDoc: hashtagDoc,                                                                                          // 138
					questionGroupDoc: questionGroupDoc,                                                                              // 139
					answerOptionsDoc: answerOptionsDoc,                                                                              // 140
					memberListDoc: memberListDoc,                                                                                    // 141
					responsesDoc: responsesDoc                                                                                       // 142
				};                                                                                                                //
				return JSON.stringify(exportData);                                                                                // 144
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return HashtagsCollectionExport;                                                                                    //
	}(),                                                                                                                 //
	'HashtagsCollection.import': function () {                                                                           // 147
		function HashtagsCollectionImport(_ref2) {                                                                          // 147
			var privateKey = _ref2.privateKey;                                                                                 //
			var data = _ref2.data;                                                                                             //
                                                                                                                      //
			if (_meteor.Meteor.isServer) {                                                                                     // 148
				var hashtag = data.hashtag;                                                                                       // 149
				var oldDoc = _collection5.HashtagsCollection.findOne({ hashtag: hashtag, privateKey: { $ne: privateKey } });      // 150
				if (oldDoc) {                                                                                                     // 151
					throw new _meteor.Meteor.Error('HashtagsCollection.import', 'hashtag_exists');                                   // 152
				}                                                                                                                 //
				var questionList = [];                                                                                            // 154
				var hashtagDoc = data.hashtagDoc;                                                                                 // 155
                                                                                                                      //
				if (!hashtagDoc.theme) {                                                                                          // 157
					hashtagDoc.theme = "theme-dark";                                                                                 // 158
				}                                                                                                                 //
				if (!hashtagDoc.musicVolume) {                                                                                    // 160
					hashtagDoc.musicVolume = 80;                                                                                     // 161
				}                                                                                                                 //
				if (!hashtagDoc.musicEnabled) {                                                                                   // 163
					hashtagDoc.musicEnabled = 1;                                                                                     // 164
				}                                                                                                                 //
				if (!hashtagDoc.musicTitle) {                                                                                     // 166
					hashtagDoc.musicTitle = "Song1";                                                                                 // 167
				}                                                                                                                 //
                                                                                                                      //
				hashtagDoc.privateKey = privateKey;                                                                               // 170
				delete hashtagDoc._id;                                                                                            // 171
				_collection5.HashtagsCollection.insert(hashtagDoc);                                                               // 172
				for (var i = 0; i < data.questionListDoc.length; i++) {                                                           // 173
					var question = data.questionListDoc[i];                                                                          // 174
					questionList.push({                                                                                              // 175
						hashtag: question.hashtag,                                                                                      // 176
						questionText: question.questionText,                                                                            // 177
						timer: question.timer,                                                                                          // 178
						startTime: question.startTime,                                                                                  // 179
						questionIndex: question.questionIndex,                                                                          // 180
						answerOptionList: [],                                                                                           // 181
						type: question.type                                                                                             // 182
					});                                                                                                              //
					for (var j = 0; j < question.answerOptionList.length; j++) {                                                     // 184
						var answer = question.answerOptionList[j];                                                                      // 185
						_collection.AnswerOptionCollection.insert({                                                                     // 186
							hashtag: answer.hashtag,                                                                                       // 187
							questionIndex: answer.questionIndex,                                                                           // 188
							answerText: answer.answerText,                                                                                 // 189
							answerOptionNumber: answer.answerOptionNumber,                                                                 // 190
							isCorrect: answer.isCorrect,                                                                                   // 191
							type: answer.type                                                                                              // 192
						});                                                                                                             //
						questionList[i].answerOptionList.push({                                                                         // 194
							hashtag: answer.hashtag,                                                                                       // 195
							questionIndex: answer.questionIndex,                                                                           // 196
							answerText: answer.answerText,                                                                                 // 197
							answerOptionNumber: answer.answerOptionNumber,                                                                 // 198
							isCorrect: answer.isCorrect,                                                                                   // 199
							type: answer.type                                                                                              // 200
						});                                                                                                             //
					}                                                                                                                //
				}                                                                                                                 //
				_collection4.QuestionGroupCollection.insert({                                                                     // 204
					hashtag: hashtag,                                                                                                // 205
					questionList: questionList                                                                                       // 206
				});                                                                                                               //
                                                                                                                      //
				_collection6.EventManagerCollection.update({ hashtag: data.hashtagDoc }, {                                        // 209
					$push: {                                                                                                         // 210
						eventStack: {                                                                                                   // 211
							key: "HashtagsCollection.import",                                                                              // 212
							value: { hashtag: data.hashtagDoc }                                                                            // 213
						}                                                                                                               //
					}                                                                                                                //
				});                                                                                                               //
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return HashtagsCollectionImport;                                                                                    //
	}()                                                                                                                  //
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"leaderboard.js":["meteor/meteor","meteor/aldeed:simple-schema","/lib/answeroptions/collection.js","/lib/responses/collection.js","/lib/leader_board/collection.js","/lib/hashtags/collection.js","/lib/member_list/collection.js","/lib/eventmanager/collection.js",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// shared/leaderboard.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _meteor = require('meteor/meteor');                                                                               // 18
                                                                                                                      //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                     // 19
                                                                                                                      //
var _collection = require('/lib/answeroptions/collection.js');                                                        // 20
                                                                                                                      //
var _collection2 = require('/lib/responses/collection.js');                                                           // 21
                                                                                                                      //
var _collection3 = require('/lib/leader_board/collection.js');                                                        // 22
                                                                                                                      //
var _collection4 = require('/lib/hashtags/collection.js');                                                            // 23
                                                                                                                      //
var _collection5 = require('/lib/member_list/collection.js');                                                         // 24
                                                                                                                      //
var _collection6 = require('/lib/eventmanager/collection.js');                                                        // 25
                                                                                                                      //
/*                                                                                                                    //
 * This file is part of ARSnova Click.                                                                                //
 * Copyright (C) 2016 The ARSnova Team                                                                                //
 *                                                                                                                    //
 * ARSnova Click is free software: you can redistribute it and/or modify                                              //
 * it under the terms of the GNU General Public License as published by                                               //
 * the Free Software Foundation, either version 3 of the License, or                                                  //
 * (at your option) any later version.                                                                                //
 *                                                                                                                    //
 * ARSnova Click is distributed in the hope that it will be useful,                                                   //
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                     //
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                      //
 * GNU General Public License for more details.                                                                       //
 *                                                                                                                    //
 * You should have received a copy of the GNU General Public License                                                  //
 * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                           //
                                                                                                                      //
_meteor.Meteor.methods({                                                                                              // 27
	'LeaderBoardCollection.addResponseSet': function () {                                                                // 28
		function LeaderBoardCollectionAddResponseSet(_ref) {                                                                // 28
			var hashtag = _ref.hashtag;                                                                                        //
			var questionIndex = _ref.questionIndex;                                                                            //
			var nick = _ref.nick;                                                                                              //
			var responseTime = _ref.responseTime;                                                                              //
                                                                                                                      //
			new _aldeedSimpleSchema.SimpleSchema({                                                                             // 29
				hashtag: _collection4.hashtagSchema,                                                                              // 30
				questionIndex: _collection6.questionIndexSchema,                                                                  // 31
				nick: _collection5.userNickSchema,                                                                                // 32
				responseTime: _collection2.responseTimeSchema                                                                     // 33
			}).validate({ hashtag: hashtag, questionIndex: questionIndex, nick: nick, responseTime: responseTime });           //
                                                                                                                      //
			if (_meteor.Meteor.isServer) {                                                                                     // 36
				var responseAmount;                                                                                               //
				var falseResponseAmount;                                                                                          //
				var rightResponseAmount;                                                                                          //
				var memberEntry;                                                                                                  //
                                                                                                                      //
				(function () {                                                                                                    //
					var correctAnswers = [];                                                                                         // 37
                                                                                                                      //
					_collection.AnswerOptionCollection.find({                                                                        // 39
						hashtag: hashtag,                                                                                               // 40
						questionIndex: questionIndex,                                                                                   // 41
						isCorrect: 1                                                                                                    // 42
					}, { fields: { "answerOptionNumber": 1 } }).forEach(function (answer) {                                          //
						correctAnswers.push(answer.answerOptionNumber);                                                                 // 44
					});                                                                                                              //
                                                                                                                      //
					responseAmount = 0;                                                                                              // 47
					falseResponseAmount = 0;                                                                                         // 48
                                                                                                                      //
                                                                                                                      //
					_collection2.ResponsesCollection.find({                                                                          // 50
						hashtag: hashtag,                                                                                               // 51
						questionIndex: questionIndex,                                                                                   // 52
						userNick: nick                                                                                                  // 53
					}).forEach(function (response) {                                                                                 //
						if (correctAnswers.indexOf(response.answerOptionNumber) === -1) {                                               // 55
							falseResponseAmount++;                                                                                         // 56
						}                                                                                                               //
						responseAmount++;                                                                                               // 58
					});                                                                                                              //
                                                                                                                      //
					rightResponseAmount = responseAmount - falseResponseAmount;                                                      // 61
					memberEntry = _collection3.LeaderBoardCollection.findOne({                                                       // 63
						hashtag: hashtag,                                                                                               // 64
						questionIndex: questionIndex,                                                                                   // 65
						userNick: nick                                                                                                  // 66
					});                                                                                                              //
                                                                                                                      //
                                                                                                                      //
					if (!memberEntry) {                                                                                              // 69
						_collection3.LeaderBoardCollection.insert({                                                                     // 70
							hashtag: hashtag,                                                                                              // 71
							questionIndex: questionIndex,                                                                                  // 72
							userNick: nick,                                                                                                // 73
							responseTime: responseTime,                                                                                    // 74
							givenAnswers: responseAmount,                                                                                  // 75
							rightAnswers: rightResponseAmount,                                                                             // 76
							wrongAnswers: falseResponseAmount                                                                              // 77
						});                                                                                                             //
					} else {                                                                                                         //
						_collection3.LeaderBoardCollection.update(memberEntry._id, {                                                    // 80
							$set: {                                                                                                        // 81
								givenAnswers: responseAmount,                                                                                 // 82
								rightAnswers: rightResponseAmount,                                                                            // 83
								wrongAnswers: falseResponseAmount                                                                             // 84
							}                                                                                                              //
						});                                                                                                             //
					}                                                                                                                //
					_collection6.EventManagerCollection.update({ hashtag: hashtag }, { $push: { eventStack: { key: "LeaderBoardCollection.addResponseSet",
								value: {                                                                                                      // 89
									nick: nick,                                                                                                  // 90
									questionIndex: questionIndex                                                                                 // 91
								}                                                                                                             //
							}                                                                                                              //
						}                                                                                                               //
					});                                                                                                              //
				})();                                                                                                             //
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return LeaderBoardCollectionAddResponseSet;                                                                         //
	}()                                                                                                                  //
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"memberlist.js":["meteor/meteor","meteor/aldeed:simple-schema","/lib/eventmanager/collection.js","/lib/hashtags/collection.js","/lib/member_list/collection.js",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// shared/memberlist.js                                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _meteor = require('meteor/meteor');                                                                               // 18
                                                                                                                      //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                     // 19
                                                                                                                      //
var _collection = require('/lib/eventmanager/collection.js');                                                         // 20
                                                                                                                      //
var _collection2 = require('/lib/hashtags/collection.js');                                                            // 21
                                                                                                                      //
var _collection3 = require('/lib/member_list/collection.js');                                                         // 22
                                                                                                                      //
_meteor.Meteor.methods({                                                                                              // 24
	'MemberListCollection.addLearner': function () {                                                                     // 25
		function MemberListCollectionAddLearner(_ref) {                                                                     // 25
			var hashtag = _ref.hashtag;                                                                                        //
			var nick = _ref.nick;                                                                                              //
			var privateKey = _ref.privateKey;                                                                                  //
			var backgroundColor = _ref.backgroundColor;                                                                        //
			var foregroundColor = _ref.foregroundColor;                                                                        //
                                                                                                                      //
			new _aldeedSimpleSchema.SimpleSchema({                                                                             // 26
				hashtag: _collection2.hashtagSchema,                                                                              // 27
				nick: _collection3.userNickSchema,                                                                                // 28
				privateKey: _collection2.privateKeySchema,                                                                        // 29
				backgroundColor: _collection3.backgroundColorSchema,                                                              // 30
				foregroundColor: _collection3.foregroundColorSchema                                                               // 31
			}).validate({ hashtag: hashtag, nick: nick, privateKey: privateKey, backgroundColor: backgroundColor, foregroundColor: foregroundColor });
                                                                                                                      //
			if (_collection3.MemberListCollection.findOne({                                                                    // 34
				hashtag: hashtag,                                                                                                 // 35
				nick: nick                                                                                                        // 36
			})) {                                                                                                              //
				throw new _meteor.Meteor.Error('MemberListCollection.addLearner', 'Nick already exists!');                        // 38
			}                                                                                                                  //
			var query = {};                                                                                                    // 40
			if (_meteor.Meteor.isServer) {                                                                                     // 41
				query.hashtag = hashtag;                                                                                          // 42
			}                                                                                                                  //
			if (_collection.EventManagerCollection.findOne(query).sessionStatus !== 2) {                                       // 44
				throw new _meteor.Meteor.Error('MemberListCollection.addLearner', 'session_not_available');                       // 45
			}                                                                                                                  //
			_collection3.MemberListCollection.insert({                                                                         // 47
				hashtag: hashtag,                                                                                                 // 48
				nick: nick,                                                                                                       // 49
				privateKey: privateKey,                                                                                           // 50
				lowerCaseNick: nick.toLowerCase(),                                                                                // 51
				backgroundColor: backgroundColor,                                                                                 // 52
				foregroundColor: foregroundColor,                                                                                 // 53
				readConfirmed: [],                                                                                                // 54
				insertDate: new Date().getTime()                                                                                  // 55
			});                                                                                                                //
			_collection.EventManagerCollection.update(query, {                                                                 // 57
				$push: {                                                                                                          // 58
					eventStack: {                                                                                                    // 59
						key: "MemberListCollection.addLearner",                                                                         // 60
						value: { user: nick }                                                                                           // 61
					}                                                                                                                //
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return MemberListCollectionAddLearner;                                                                              //
	}(),                                                                                                                 //
	'MemberListCollection.removeLearner': function () {                                                                  // 66
		function MemberListCollectionRemoveLearner(hashtag, nickId) {                                                       // 66
			new _aldeedSimpleSchema.SimpleSchema({                                                                             // 67
				hashtag: _collection2.hashtagSchema,                                                                              // 68
				nickId: _collection3.userNickIdSchema                                                                             // 69
			}).validate({ hashtag: hashtag, nickId: nickId });                                                                 //
                                                                                                                      //
			var nickName = _collection3.MemberListCollection.findOne({                                                         // 72
				hashtag: hashtag,                                                                                                 // 73
				_id: nickId                                                                                                       // 74
			}).nick;                                                                                                           //
                                                                                                                      //
			if (nickName) {                                                                                                    // 77
				_collection3.MemberListCollection.remove({                                                                        // 78
					hashtag: hashtag,                                                                                                // 79
					_id: nickId                                                                                                      // 80
				});                                                                                                               //
				_collection.EventManagerCollection.update({ hashtag: hashtag }, {                                                 // 82
					$push: {                                                                                                         // 83
						eventStack: {                                                                                                   // 84
							key: "MemberListCollection.removeLearner",                                                                     // 85
							value: { user: nickName }                                                                                      // 86
						}                                                                                                               //
					}                                                                                                                //
				});                                                                                                               //
			}                                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return MemberListCollectionRemoveLearner;                                                                           //
	}(),                                                                                                                 //
	'MemberListCollection.setReadConfirmed': function () {                                                               // 92
		function MemberListCollectionSetReadConfirmed(_ref2) {                                                              // 92
			var hashtag = _ref2.hashtag;                                                                                       //
			var questionIndex = _ref2.questionIndex;                                                                           //
			var nick = _ref2.nick;                                                                                             //
                                                                                                                      //
			new _aldeedSimpleSchema.SimpleSchema({                                                                             // 93
				hashtag: _collection2.hashtagSchema,                                                                              // 94
				questionIndex: _collection.questionIndexSchema,                                                                   // 95
				nick: _collection3.userNickSchema                                                                                 // 96
			}).validate({ hashtag: hashtag, questionIndex: questionIndex, nick: nick });                                       //
                                                                                                                      //
			var member = _collection3.MemberListCollection.findOne({                                                           // 99
				hashtag: hashtag,                                                                                                 // 100
				nick: nick                                                                                                        // 101
			});                                                                                                                //
			if (!member) {                                                                                                     // 103
				throw new _meteor.Meteor.Error('MemberListCollection.setReadConfirmed', 'member_not_found');                      // 104
			}                                                                                                                  //
			member.readConfirmed[questionIndex] = 1;                                                                           // 106
			_collection3.MemberListCollection.update(member._id, { $set: { readConfirmed: member.readConfirmed } });           // 107
			_collection.EventManagerCollection.update({ hashtag: hashtag }, {                                                  // 108
				$push: {                                                                                                          // 109
					eventStack: {                                                                                                    // 110
						key: "MemberListCollection.setReadConfirmed",                                                                   // 111
						value: {                                                                                                        // 112
							user: nick,                                                                                                    // 113
							questionIndex: questionIndex                                                                                   // 114
						}                                                                                                               //
					}                                                                                                                //
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return MemberListCollectionSetReadConfirmed;                                                                        //
	}(),                                                                                                                 //
	'MemberListCollection.clearReadConfirmed': function () {                                                             // 120
		function MemberListCollectionClearReadConfirmed(hashtag) {                                                          // 120
			new _aldeedSimpleSchema.SimpleSchema({ hashtag: _collection2.hashtagSchema }).validate({ hashtag: hashtag });      // 121
                                                                                                                      //
			_collection3.MemberListCollection.update({ hashtag: hashtag }, { $set: { readConfirmed: [] } }, { multi: true });  // 123
			_collection.EventManagerCollection.update({ hashtag: hashtag }, {                                                  // 124
				$push: {                                                                                                          // 125
					eventStack: {                                                                                                    // 126
						key: "MemberListCollection.clearReadConfirmed",                                                                 // 127
						value: {}                                                                                                       // 128
					}                                                                                                                //
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return MemberListCollectionClearReadConfirmed;                                                                      //
	}(),                                                                                                                 //
	'MemberListCollection.removeFromSession': function () {                                                              // 133
		function MemberListCollectionRemoveFromSession(hashtag) {                                                           // 133
			new _aldeedSimpleSchema.SimpleSchema({ hashtag: _collection2.hashtagSchema }).validate({ hashtag: hashtag });      // 134
                                                                                                                      //
			_collection3.MemberListCollection.remove({ hashtag: hashtag });                                                    // 136
			_collection.EventManagerCollection.update({ hashtag: hashtag }, {                                                  // 137
				$push: {                                                                                                          // 138
					eventStack: {                                                                                                    // 139
						key: "MemberListCollection.removeFromSession",                                                                  // 140
						value: {}                                                                                                       // 141
					}                                                                                                                //
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return MemberListCollectionRemoveFromSession;                                                                       //
	}()                                                                                                                  //
}); /*                                                                                                                //
     * This file is part of ARSnova Click.                                                                            //
     * Copyright (C) 2016 The ARSnova Team                                                                            //
     *                                                                                                                //
     * ARSnova Click is free software: you can redistribute it and/or modify                                          //
     * it under the terms of the GNU General Public License as published by                                           //
     * the Free Software Foundation, either version 3 of the License, or                                              //
     * (at your option) any later version.                                                                            //
     *                                                                                                                //
     * ARSnova Click is distributed in the hope that it will be useful,                                               //
     * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                 //
     * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                  //
     * GNU General Public License for more details.                                                                   //
     *                                                                                                                //
     * You should have received a copy of the GNU General Public License                                              //
     * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                       //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"questions.js":["meteor/meteor","meteor/aldeed:simple-schema","/lib/answeroptions/collection.js","/lib/hashtags/collection.js","/lib/questions/collection.js","/lib/eventmanager/collection.js",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// shared/questions.js                                                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _meteor = require('meteor/meteor');                                                                               // 18
                                                                                                                      //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                     // 19
                                                                                                                      //
var _collection = require('/lib/answeroptions/collection.js');                                                        // 20
                                                                                                                      //
var _collection2 = require('/lib/hashtags/collection.js');                                                            // 21
                                                                                                                      //
var _collection3 = require('/lib/questions/collection.js');                                                           // 22
                                                                                                                      //
var _collection4 = require('/lib/eventmanager/collection.js');                                                        // 23
                                                                                                                      //
/*                                                                                                                    //
 * This file is part of ARSnova Click.                                                                                //
 * Copyright (C) 2016 The ARSnova Team                                                                                //
 *                                                                                                                    //
 * ARSnova Click is free software: you can redistribute it and/or modify                                              //
 * it under the terms of the GNU General Public License as published by                                               //
 * the Free Software Foundation, either version 3 of the License, or                                                  //
 * (at your option) any later version.                                                                                //
 *                                                                                                                    //
 * ARSnova Click is distributed in the hope that it will be useful,                                                   //
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                     //
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                      //
 * GNU General Public License for more details.                                                                       //
 *                                                                                                                    //
 * You should have received a copy of the GNU General Public License                                                  //
 * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                           //
                                                                                                                      //
_meteor.Meteor.methods({                                                                                              // 25
	"QuestionGroupCollection.insert": function () {                                                                      // 26
		function QuestionGroupCollectionInsert(questionGroup) {                                                             // 26
			_collection3.questionGroupSchema.validate({                                                                        // 27
				hashtag: questionGroup.hashtag,                                                                                   // 28
				questionList: questionGroup.questionList                                                                          // 29
			});                                                                                                                //
                                                                                                                      //
			var query = {};                                                                                                    // 32
			if (_meteor.Meteor.isServer) {                                                                                     // 33
				query.hashtag = questionGroup.hashtag;                                                                            // 34
			}                                                                                                                  //
			if (_collection3.QuestionGroupCollection.find(query).count() > 0) {                                                // 36
				_collection3.QuestionGroupCollection.update(query, questionGroup);                                                // 37
			} else {                                                                                                           //
				_collection3.QuestionGroupCollection.insert(questionGroup);                                                       // 39
				for (var i = 0; i < questionGroup.questionList.length; i++) {                                                     // 40
					var questionItem = questionGroup.questionList[i];                                                                // 41
					for (var j = 0; j < questionItem.answerOptionList.length; j++) {                                                 // 42
						var answerItem = questionItem.answerOptionList[j];                                                              // 43
						_meteor.Meteor.call("AnswerOptionCollection.addOption", {                                                       // 44
							hashtag: questionGroup.hashtag,                                                                                // 45
							questionIndex: questionItem.questionIndex,                                                                     // 46
							answerText: answerItem.answerText,                                                                             // 47
							answerOptionNumber: answerItem.answerOptionNumber,                                                             // 48
							isCorrect: answerItem.isCorrect                                                                                // 49
						});                                                                                                             //
					}                                                                                                                //
				}                                                                                                                 //
			}                                                                                                                  //
			_collection4.EventManagerCollection.update({ hashtag: questionGroup.hashtag }, {                                   // 54
				$push: {                                                                                                          // 55
					eventStack: {                                                                                                    // 56
						key: "QuestionGroupCollection.insert",                                                                          // 57
						value: {}                                                                                                       // 58
					}                                                                                                                //
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return QuestionGroupCollectionInsert;                                                                               //
	}(),                                                                                                                 //
	"QuestionGroupCollection.addQuestion": function () {                                                                 // 63
		function QuestionGroupCollectionAddQuestion(questionItem) {                                                         // 63
			new _aldeedSimpleSchema.SimpleSchema({                                                                             // 64
				hashtag: _collection2.hashtagSchema,                                                                              // 65
				questionIndex: _collection4.questionIndexSchema,                                                                  // 66
				questionText: _collection3.questionTextSchema                                                                     // 67
			}).validate({ hashtag: questionItem.hashtag, questionIndex: questionItem.getQuestionIndex(), questionText: questionItem.getQuestionText() });
                                                                                                                      //
			var query = {};                                                                                                    // 70
			if (_meteor.Meteor.isServer) {                                                                                     // 71
				query.hashtag = questionItem.hashtag;                                                                             // 72
			}                                                                                                                  //
			var questionGroup = _collection3.QuestionGroupCollection.findOne(query);                                           // 74
			if (!questionGroup) {                                                                                              // 75
				_collection3.QuestionGroupCollection.insert({                                                                     // 76
					hashtag: questionItem.hashtag,                                                                                   // 77
					questionList: [questionItem]                                                                                     // 78
				});                                                                                                               //
			} else {                                                                                                           //
				if (questionItem.getQuestionIndex() < questionGroup.questionList.length) {                                        // 81
					questionGroup.questionList[questionItem.getQuestionIndex()].questionText = questionItem.getQuestionIndex();      // 82
				} else {                                                                                                          //
					questionGroup.questionList.push(questionItem.serialize());                                                       // 84
				}                                                                                                                 //
				_collection3.QuestionGroupCollection.update(questionGroup._id, { $set: { questionList: questionGroup.questionList } });
			}                                                                                                                  //
			_collection4.EventManagerCollection.update({ hashtag: questionItem.hashtag }, {                                    // 88
				$push: {                                                                                                          // 89
					eventStack: {                                                                                                    // 90
						key: "QuestionGroupCollection.addQuestion",                                                                     // 91
						value: { questionIndex: questionItem.getQuestionIndex() }                                                       // 92
					}                                                                                                                //
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return QuestionGroupCollectionAddQuestion;                                                                          //
	}(),                                                                                                                 //
	"QuestionGroupCollection.removeQuestion": function () {                                                              // 97
		function QuestionGroupCollectionRemoveQuestion(_ref) {                                                              // 97
			var hashtag = _ref.hashtag;                                                                                        //
			var questionIndex = _ref.questionIndex;                                                                            //
                                                                                                                      //
			new _aldeedSimpleSchema.SimpleSchema({                                                                             // 98
				hashtag: _collection2.hashtagSchema,                                                                              // 99
				questionIndex: _collection4.questionIndexSchema                                                                   // 100
			}).validate({ hashtag: hashtag, questionIndex: questionIndex });                                                   //
                                                                                                                      //
			var query = {};                                                                                                    // 103
			if (_meteor.Meteor.isServer) {                                                                                     // 104
				query.hashtag = hashtag;                                                                                          // 105
			}                                                                                                                  //
			var questionGroup = _collection3.QuestionGroupCollection.findOne(query);                                           // 107
			if (questionGroup) {                                                                                               // 108
				questionGroup.questionList.splice(questionIndex, 1);                                                              // 109
				_collection3.QuestionGroupCollection.update(questionGroup._id, { $set: { questionList: questionGroup.questionList } });
			}                                                                                                                  //
			_collection4.EventManagerCollection.update({ hashtag: hashtag }, {                                                 // 112
				$push: {                                                                                                          // 113
					eventStack: {                                                                                                    // 114
						key: "QuestionGroupCollection.addQuestion",                                                                     // 115
						value: { questionIndex: questionIndex }                                                                         // 116
					}                                                                                                                //
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return QuestionGroupCollectionRemoveQuestion;                                                                       //
	}(),                                                                                                                 //
	"QuestionGroupCollection.persist": function () {                                                                     // 121
		function QuestionGroupCollectionPersist(questionGroupElement) {                                                     // 121
			new _aldeedSimpleSchema.SimpleSchema({                                                                             // 122
				hashtag: _collection2.hashtagSchema                                                                               // 123
			}).validate({ hashtag: questionGroupElement.hashtag });                                                            //
                                                                                                                      //
			_meteor.Meteor.call("QuestionGroupCollection.insert", questionGroupElement);                                       // 126
                                                                                                                      //
			_collection4.EventManagerCollection.update({ hashtag: questionGroupElement.hashtag }, {                            // 128
				$push: {                                                                                                          // 129
					eventStack: {                                                                                                    // 130
						key: "QuestionGroupCollection.persist",                                                                         // 131
						value: { questionGroupElement: questionGroupElement }                                                           // 132
					}                                                                                                                //
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return QuestionGroupCollectionPersist;                                                                              //
	}(),                                                                                                                 //
	"Question.isSC": function () {                                                                                       // 137
		function QuestionIsSC(_ref2) {                                                                                      // 137
			var hashtag = _ref2.hashtag;                                                                                       //
			var questionIndex = _ref2.questionIndex;                                                                           //
                                                                                                                      //
			new _aldeedSimpleSchema.SimpleSchema({                                                                             // 138
				hashtag: _collection2.hashtagSchema,                                                                              // 139
				questionIndex: _collection4.questionIndexSchema                                                                   // 140
			}).validate({ hashtag: hashtag, questionIndex: questionIndex });                                                   //
                                                                                                                      //
			return _collection.AnswerOptionCollection.find({                                                                   // 143
				hashtag: hashtag,                                                                                                 // 144
				questionIndex: questionIndex,                                                                                     // 145
				isCorrect: true                                                                                                   // 146
			}).count() === 1;                                                                                                  //
		}                                                                                                                   //
                                                                                                                      //
		return QuestionIsSC;                                                                                                //
	}(),                                                                                                                 //
	"Question.setTimer": function () {                                                                                   // 149
		function QuestionSetTimer(_ref3) {                                                                                  // 149
			var hashtag = _ref3.hashtag;                                                                                       //
			var questionIndex = _ref3.questionIndex;                                                                           //
			var timer = _ref3.timer;                                                                                           //
                                                                                                                      //
			new _aldeedSimpleSchema.SimpleSchema({                                                                             // 150
				hashtag: _collection2.hashtagSchema,                                                                              // 151
				questionIndex: _collection4.questionIndexSchema,                                                                  // 152
				timer: _collection3.timerSchema                                                                                   // 153
			}).validate({ hashtag: hashtag, questionIndex: questionIndex, timer: timer });                                     //
                                                                                                                      //
			var query = {};                                                                                                    // 156
			if (_meteor.Meteor.isServer) {                                                                                     // 157
				query.hashtag = hashtag;                                                                                          // 158
			}                                                                                                                  //
			var questionGroup = _collection3.QuestionGroupCollection.findOne(query);                                           // 160
			if (!questionGroup) {                                                                                              // 161
				throw new _meteor.Meteor.Error('Question.setTimer', 'hashtag_not_found');                                         // 162
			}                                                                                                                  //
                                                                                                                      //
			questionGroup.questionList[questionIndex].timer = timer;                                                           // 165
			_collection3.QuestionGroupCollection.update(questionGroup._id, { $set: { questionList: questionGroup.questionList } });
			_collection4.EventManagerCollection.update({ hashtag: hashtag }, {                                                 // 167
				$push: {                                                                                                          // 168
					eventStack: {                                                                                                    // 169
						key: "QuestionGroupCollection.setTimer",                                                                        // 170
						value: {                                                                                                        // 171
							questionIndex: questionIndex,                                                                                  // 172
							timer: timer                                                                                                   // 173
						}                                                                                                               //
					}                                                                                                                //
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return QuestionSetTimer;                                                                                            //
	}(),                                                                                                                 //
	"Question.startTimer": function () {                                                                                 // 179
		function QuestionStartTimer(_ref4) {                                                                                // 179
			var hashtag = _ref4.hashtag;                                                                                       //
			var questionIndex = _ref4.questionIndex;                                                                           //
                                                                                                                      //
			new _aldeedSimpleSchema.SimpleSchema({                                                                             // 180
				hashtag: _collection2.hashtagSchema,                                                                              // 181
				questionIndex: _collection4.questionIndexSchema                                                                   // 182
			}).validate({ hashtag: hashtag, questionIndex: questionIndex });                                                   //
                                                                                                                      //
			var startTime = new Date();                                                                                        // 185
                                                                                                                      //
			var query = {};                                                                                                    // 187
			if (_meteor.Meteor.isServer) {                                                                                     // 188
				query.hashtag = hashtag;                                                                                          // 189
			}                                                                                                                  //
			var questionGroup = _collection3.QuestionGroupCollection.findOne(query);                                           // 191
			if (!questionGroup) {                                                                                              // 192
				throw new _meteor.Meteor.Error('Question.startTimer', 'hashtag_not_found');                                       // 193
			}                                                                                                                  //
			questionGroup.questionList[questionIndex].startTime = startTime.getTime();                                         // 195
			_collection3.QuestionGroupCollection.update(questionGroup._id, { $set: { questionList: questionGroup.questionList } });
			_collection4.EventManagerCollection.update({ hashtag: hashtag }, {                                                 // 197
				$push: {                                                                                                          // 198
					eventStack: {                                                                                                    // 199
						key: "QuestionGroupCollection.setTimer",                                                                        // 200
						value: { questionIndex: questionIndex }                                                                         // 201
					}                                                                                                                //
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return QuestionStartTimer;                                                                                          //
	}()                                                                                                                  //
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"responses.js":["meteor/meteor","meteor/aldeed:simple-schema","/lib/answeroptions/collection.js","/lib/responses/collection.js","/lib/questions/collection.js","/lib/member_list/collection.js","/lib/hashtags/collection.js","/lib/eventmanager/collection.js",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// shared/responses.js                                                                                                //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _meteor = require('meteor/meteor');                                                                               // 18
                                                                                                                      //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                     // 19
                                                                                                                      //
var _collection = require('/lib/answeroptions/collection.js');                                                        // 20
                                                                                                                      //
var _collection2 = require('/lib/responses/collection.js');                                                           // 21
                                                                                                                      //
var _collection3 = require('/lib/questions/collection.js');                                                           // 22
                                                                                                                      //
var _collection4 = require('/lib/member_list/collection.js');                                                         // 23
                                                                                                                      //
var _collection5 = require('/lib/hashtags/collection.js');                                                            // 24
                                                                                                                      //
var _collection6 = require('/lib/eventmanager/collection.js');                                                        // 25
                                                                                                                      //
/*                                                                                                                    //
 * This file is part of ARSnova Click.                                                                                //
 * Copyright (C) 2016 The ARSnova Team                                                                                //
 *                                                                                                                    //
 * ARSnova Click is free software: you can redistribute it and/or modify                                              //
 * it under the terms of the GNU General Public License as published by                                               //
 * the Free Software Foundation, either version 3 of the License, or                                                  //
 * (at your option) any later version.                                                                                //
 *                                                                                                                    //
 * ARSnova Click is distributed in the hope that it will be useful,                                                   //
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                     //
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                      //
 * GNU General Public License for more details.                                                                       //
 *                                                                                                                    //
 * You should have received a copy of the GNU General Public License                                                  //
 * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                           //
                                                                                                                      //
_meteor.Meteor.methods({                                                                                              // 27
	'ResponsesCollection.addResponse': function () {                                                                     // 28
		function ResponsesCollectionAddResponse(responseDoc) {                                                              // 28
			new _aldeedSimpleSchema.SimpleSchema({                                                                             // 29
				hashtag: _collection5.hashtagSchema,                                                                              // 30
				questionIndex: _collection6.questionIndexSchema,                                                                  // 31
				answerOptionNumber: _collection.answerOptionNumberSchema,                                                         // 32
				userNick: _collection4.userNickSchema                                                                             // 33
			}).validate({ hashtag: responseDoc.hashtag, questionIndex: responseDoc.questionIndex, answerOptionNumber: responseDoc.answerOptionNumber, userNick: responseDoc.userNick });
                                                                                                                      //
			var timestamp = new Date().getTime();                                                                              // 36
			var hashtag = responseDoc.hashtag;                                                                                 // 37
			var dupDoc = _collection2.ResponsesCollection.findOne({                                                            // 38
				hashtag: responseDoc.hashtag,                                                                                     // 39
				questionIndex: responseDoc.questionIndex,                                                                         // 40
				answerOptionNumber: responseDoc.answerOptionNumber,                                                               // 41
				userNick: responseDoc.userNick                                                                                    // 42
			});                                                                                                                //
			if (dupDoc) {                                                                                                      // 44
				throw new _meteor.Meteor.Error('ResponsesCollection.addResponse', 'duplicate_response');                          // 45
			}                                                                                                                  //
			var query = {};                                                                                                    // 47
			if (_meteor.Meteor.isServer) {                                                                                     // 48
				query.hashtag = responseDoc.hashtag;                                                                              // 49
			}                                                                                                                  //
			var questionGroupDoc = _collection3.QuestionGroupCollection.findOne(query);                                        // 51
			if (!questionGroupDoc) {                                                                                           // 52
				throw new _meteor.Meteor.Error('ResponsesCollection.addResponse', 'hashtag_not_found');                           // 53
			}                                                                                                                  //
			var responseTime = Number(timestamp) - Number(questionGroupDoc.questionList[responseDoc.questionIndex].startTime);
                                                                                                                      //
			if (responseTime > questionGroupDoc.questionList[responseDoc.questionIndex].timer * 1000) {                        // 57
				throw new _meteor.Meteor.Error('ResponsesCollection.addResponse', 'response_timeout');                            // 58
			}                                                                                                                  //
			responseDoc.responseTime = responseTime;                                                                           // 60
			var answerOptionDoc = _collection.AnswerOptionCollection.findOne({                                                 // 61
				hashtag: hashtag,                                                                                                 // 62
				questionIndex: responseDoc.questionIndex,                                                                         // 63
				answerOptionNumber: responseDoc.answerOptionNumber                                                                // 64
			});                                                                                                                //
			if (!answerOptionDoc) {                                                                                            // 66
				throw new _meteor.Meteor.Error('ResponsesCollection.addResponse', 'answeroption_not_found');                      // 67
			}                                                                                                                  //
                                                                                                                      //
			_collection2.ResponsesCollection.insert(responseDoc);                                                              // 70
                                                                                                                      //
			_meteor.Meteor.call('LeaderBoardCollection.addResponseSet', {                                                      // 72
				hashtag: responseDoc.hashtag,                                                                                     // 73
				questionIndex: responseDoc.questionIndex,                                                                         // 74
				nick: responseDoc.userNick,                                                                                       // 75
				responseTime: responseDoc.responseTime                                                                            // 76
			});                                                                                                                //
			_collection6.EventManagerCollection.update({ hashtag: hashtag }, {                                                 // 78
				$push: {                                                                                                          // 79
					eventStack: {                                                                                                    // 80
						key: "ResponsesCollection.addResponse",                                                                         // 81
						value: {                                                                                                        // 82
							questionIndex: responseDoc.questionIndex,                                                                      // 83
							answerOptionNumber: responseDoc.answerOptionNumber,                                                            // 84
							userNick: responseDoc.userNick                                                                                 // 85
						}                                                                                                               //
					}                                                                                                                //
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return ResponsesCollectionAddResponse;                                                                              //
	}(),                                                                                                                 //
	'ResponsesCollection.clearAll': function () {                                                                        // 91
		function ResponsesCollectionClearAll(hashtag) {                                                                     // 91
			new _aldeedSimpleSchema.SimpleSchema({ hashtag: _collection5.hashtagSchema }).validate({ hashtag: hashtag });      // 92
                                                                                                                      //
			_collection2.ResponsesCollection.remove({ hashtag: hashtag });                                                     // 94
			_collection6.EventManagerCollection.update({ hashtag: hashtag }, {                                                 // 95
				$push: {                                                                                                          // 96
					eventStack: {                                                                                                    // 97
						key: "ResponsesCollection.clearAll",                                                                            // 98
						value: {}                                                                                                       // 99
					}                                                                                                                //
				}                                                                                                                 //
			});                                                                                                                //
		}                                                                                                                   //
                                                                                                                      //
		return ResponsesCollectionClearAll;                                                                                 //
	}()                                                                                                                  //
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"main.js":["meteor/meteor","meteor/aldeed:simple-schema","/lib/eventmanager/collection.js","/lib/answeroptions/collection.js","/lib/member_list/collection.js","/lib/responses/collection.js","/lib/questions/collection.js","/lib/hashtags/collection.js",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// shared/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _meteor = require('meteor/meteor');                                                                               // 18
                                                                                                                      //
var _aldeedSimpleSchema = require('meteor/aldeed:simple-schema');                                                     // 19
                                                                                                                      //
var _collection = require('/lib/eventmanager/collection.js');                                                         // 20
                                                                                                                      //
var _collection2 = require('/lib/answeroptions/collection.js');                                                       // 21
                                                                                                                      //
var _collection3 = require('/lib/member_list/collection.js');                                                         // 22
                                                                                                                      //
var _collection4 = require('/lib/responses/collection.js');                                                           // 23
                                                                                                                      //
var _collection5 = require('/lib/questions/collection.js');                                                           // 24
                                                                                                                      //
var _collection6 = require('/lib/hashtags/collection.js');                                                            // 25
                                                                                                                      //
/*                                                                                                                    //
 * This file is part of ARSnova Click.                                                                                //
 * Copyright (C) 2016 The ARSnova Team                                                                                //
 *                                                                                                                    //
 * ARSnova Click is free software: you can redistribute it and/or modify                                              //
 * it under the terms of the GNU General Public License as published by                                               //
 * the Free Software Foundation, either version 3 of the License, or                                                  //
 * (at your option) any later version.                                                                                //
 *                                                                                                                    //
 * ARSnova Click is distributed in the hope that it will be useful,                                                   //
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                                     //
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                                      //
 * GNU General Public License for more details.                                                                       //
 *                                                                                                                    //
 * You should have received a copy of the GNU General Public License                                                  //
 * along with ARSnova Click.  If not, see <http://www.gnu.org/licenses/>.*/                                           //
                                                                                                                      //
_meteor.Meteor.methods({                                                                                              // 27
	'Main.killAll': function () {                                                                                        // 28
		function MainKillAll(hashtag) {                                                                                     // 28
			new _aldeedSimpleSchema.SimpleSchema({ hashtag: _collection6.hashtagSchema }).validate({ hashtag: hashtag });      // 29
                                                                                                                      //
			_collection2.AnswerOptionCollection.remove({ hashtag: hashtag });                                                  // 31
			_collection3.MemberListCollection.remove({ hashtag: hashtag });                                                    // 32
			_collection4.ResponsesCollection.remove({ hashtag: hashtag });                                                     // 33
			_collection5.QuestionGroupCollection.remove({ hashtag: hashtag });                                                 // 34
			_meteor.Meteor.call("EventManagerCollection.beforeClear", hashtag);                                                // 35
		}                                                                                                                   //
                                                                                                                      //
		return MainKillAll;                                                                                                 //
	}(),                                                                                                                 //
	'Main.deleteEverything': function () {                                                                               // 37
		function MainDeleteEverything(_ref) {                                                                               // 37
			var hashtag = _ref.hashtag;                                                                                        //
                                                                                                                      //
			new _aldeedSimpleSchema.SimpleSchema({ hashtag: _collection6.hashtagSchema }).validate({ hashtag: hashtag });      // 38
                                                                                                                      //
			_collection6.HashtagsCollection.remove({ hashtag: hashtag });                                                      // 40
			_collection2.AnswerOptionCollection.remove({ hashtag: hashtag });                                                  // 41
			_collection3.MemberListCollection.remove({ hashtag: hashtag });                                                    // 42
			_collection4.ResponsesCollection.remove({ hashtag: hashtag });                                                     // 43
			_collection5.QuestionGroupCollection.remove({ hashtag: hashtag });                                                 // 44
			_collection.EventManagerCollection.remove({ hashtag: hashtag });                                                   // 45
		}                                                                                                                   //
                                                                                                                      //
		return MainDeleteEverything;                                                                                        //
	}()                                                                                                                  //
});                                                                                                                   //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./lib/answeroptions/answeroption_abstract.js");
require("./lib/answeroptions/answeroption_default.js");
require("./lib/answeroptions/collection.js");
require("./lib/banned_nicks/collection.js");
require("./lib/eventmanager/collection.js");
require("./lib/hashtags/collection.js");
require("./lib/leader_board/collection.js");
require("./lib/member_list/collection.js");
require("./lib/questions/collection.js");
require("./lib/questions/question_abstract.js");
require("./lib/questions/question_choice_abstract.js");
require("./lib/questions/question_choice_multiple.js");
require("./lib/questions/question_choice_single.js");
require("./lib/questions/question_ranged.js");
require("./lib/questions/question_reflection.js");
require("./lib/questions/question_survey.js");
require("./lib/questions/questiongroup_abstract.js");
require("./lib/questions/questiongroup_default.js");
require("./lib/responses/collection.js");
require("./lib/local_storage.js");
require("./server/publications/answeroptions.js");
require("./server/publications/banned_nicks.js");
require("./server/publications/eventmanager.js");
require("./server/publications/hashtags.js");
require("./server/publications/leaderBoard.js");
require("./server/publications/memberlist.js");
require("./server/publications/questions.js");
require("./server/publications/responses.js");
require("./i18n/de.i18n.json");
require("./i18n/en.i18n.json");
require("./i18n/es.i18n.json");
require("./i18n/fr.i18n.json");
require("./server/connection.js");
require("./server/forbiddenNicks.js");
require("./server/startup.js");
require("./shared/answeroptions.js");
require("./shared/banned_nicks.js");
require("./shared/eventmanager.js");
require("./shared/hashtags.js");
require("./shared/leaderboard.js");
require("./shared/memberlist.js");
require("./shared/questions.js");
require("./shared/responses.js");
require("./shared/main.js");
//# sourceMappingURL=app.js.map

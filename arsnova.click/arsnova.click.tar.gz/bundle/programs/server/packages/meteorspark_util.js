(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

/* Package-scope variables */
var Util;

(function(){

/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// packages/meteorspark_util/packages/meteorspark_util.js                  //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
                                                                           //
(function () {

////////////////////////////////////////////////////////////////////////
//                                                                    //
// packages/meteorspark:util/lib/util-server.js                       //
//                                                                    //
////////////////////////////////////////////////////////////////////////
                                                                      //
// https://github.com/isaacs/inherits/blob/master/inherits_browser.js // 1
Util = Npm.require("util")                                            // 2
                                                                      // 3
////////////////////////////////////////////////////////////////////////

}).call(this);

/////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['meteorspark:util'] = {}, {
  Util: Util
});

})();

//# sourceMappingURL=meteorspark_util.js.map
